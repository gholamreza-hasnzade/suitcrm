<?php
// created: 2023-12-03 12:52:06
$dictionary["bi_requestKinds"]["fields"]["bi_requestkinds_bi_allowedstatus"] = array (
  'name' => 'bi_requestkinds_bi_allowedstatus',
  'type' => 'link',
  'relationship' => 'bi_requestkinds_bi_allowedstatus',
  'source' => 'non-db',
  'module' => 'bi_allowedStatus',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BI_REQUESTKINDS_BI_ALLOWEDSTATUS_FROM_BI_ALLOWEDSTATUS_TITLE',
);
