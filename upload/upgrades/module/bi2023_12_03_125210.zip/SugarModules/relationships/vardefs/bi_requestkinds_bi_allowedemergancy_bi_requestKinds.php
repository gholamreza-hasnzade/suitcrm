<?php
// created: 2023-12-03 12:52:07
$dictionary["bi_requestKinds"]["fields"]["bi_requestkinds_bi_allowedemergancy"] = array (
  'name' => 'bi_requestkinds_bi_allowedemergancy',
  'type' => 'link',
  'relationship' => 'bi_requestkinds_bi_allowedemergancy',
  'source' => 'non-db',
  'module' => 'bi_allowedEmergancy',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BI_REQUESTKINDS_BI_ALLOWEDEMERGANCY_FROM_BI_ALLOWEDEMERGANCY_TITLE',
);
