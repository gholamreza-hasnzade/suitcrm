<?php
// created: 2023-12-03 12:52:05
$dictionary["bi_requestKinds"]["fields"]["bi_requestkinds_bi_defaultdescriptions"] = array (
  'name' => 'bi_requestkinds_bi_defaultdescriptions',
  'type' => 'link',
  'relationship' => 'bi_requestkinds_bi_defaultdescriptions',
  'source' => 'non-db',
  'module' => 'bi_defaultDescriptions',
  'bean_name' => false,
  'vname' => 'LBL_BI_REQUESTKINDS_BI_DEFAULTDESCRIPTIONS_FROM_BI_DEFAULTDESCRIPTIONS_TITLE',
);
