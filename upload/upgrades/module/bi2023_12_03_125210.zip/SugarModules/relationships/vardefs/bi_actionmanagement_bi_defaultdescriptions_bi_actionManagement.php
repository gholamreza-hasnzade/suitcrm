<?php
// created: 2023-12-03 12:51:58
$dictionary["bi_actionManagement"]["fields"]["bi_actionmanagement_bi_defaultdescriptions"] = array (
  'name' => 'bi_actionmanagement_bi_defaultdescriptions',
  'type' => 'link',
  'relationship' => 'bi_actionmanagement_bi_defaultdescriptions',
  'source' => 'non-db',
  'module' => 'bi_defaultDescriptions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BI_ACTIONMANAGEMENT_BI_DEFAULTDESCRIPTIONS_FROM_BI_DEFAULTDESCRIPTIONS_TITLE',
);
