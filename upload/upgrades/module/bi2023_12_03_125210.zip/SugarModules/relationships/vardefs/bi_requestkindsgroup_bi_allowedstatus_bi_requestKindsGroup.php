<?php
// created: 2023-12-03 12:52:09
$dictionary["bi_requestKindsGroup"]["fields"]["bi_requestkindsgroup_bi_allowedstatus"] = array (
  'name' => 'bi_requestkindsgroup_bi_allowedstatus',
  'type' => 'link',
  'relationship' => 'bi_requestkindsgroup_bi_allowedstatus',
  'source' => 'non-db',
  'module' => 'bi_allowedStatus',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BI_REQUESTKINDSGROUP_BI_ALLOWEDSTATUS_FROM_BI_ALLOWEDSTATUS_TITLE',
);
