<?php
// created: 2023-12-03 12:51:59
$dictionary["bi_actionManagement"]["fields"]["bi_actionmanagement_users"] = array (
  'name' => 'bi_actionmanagement_users',
  'type' => 'link',
  'relationship' => 'bi_actionmanagement_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_BI_ACTIONMANAGEMENT_USERS_FROM_USERS_TITLE',
);
