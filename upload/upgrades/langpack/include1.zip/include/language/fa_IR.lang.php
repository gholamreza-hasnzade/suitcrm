<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */


if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

//the left value is the key stored in the db and the right value is ie display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
    'language_pack_name' => 'fa-IR - Persian',
    'moduleList' => array(
        'Home' => 'خانه',
        'ResourceCalendar' => 'تقویم منابع',
        'Contacts' => 'مخاطب‌ها',
        'Accounts' => 'مراکز',
        'Alerts' => 'هشدارها',
        'Opportunities' => 'فرصت‌ها',
        'Cases' => 'خدمات',
        'Notes' => 'یادداشت‌ها',
        'Calls' => 'تماس‌ها',
        'TemplateSectionLine' => 'Template Section Line',
        'Calls_Reschedule' => 'برنامه ریزی مجدد تماس ها',
        'Emails' => 'ایمیل‌ها',
        'EAPM' => 'EAPM',
        'Meetings' => 'جلسات',
        'Tasks' => 'وظایف',
        'Calendar' => 'تقویم',
        'Leads' => 'سرنخ‌ها',
        'Currencies' => 'واحدهای پول',
        'Activities' => 'فعالیت‌ها',
        'Bugs' => 'اشکالات',
        'Feeds' => 'خبرخوان',
        'iFrames' => 'سایت‌های من',
        'TimePeriods' => 'دوره‌های زمانی',
        'ContractTypes' => 'انواع قرارداد',
        'Schedulers' => 'برنامه‌ریز',
        'Project' => 'پروژه‌ها',
        'ProjectTask' => 'وظایف پروژه',
        'Campaigns' => 'کمپین‌ها',
        'CampaignLog' => 'گزارش وضعیت کمپین',
        'Documents' => 'اسناد',
        'DocumentRevisions' => 'اصلاحیه‌های اسناد',
        'Connectors' => 'متصل‌کننده‌ها',
        'Roles' => 'نقش‌ها',
        'Notifications' => 'اعلان‌ها',
        'Sync' => 'همگام‌سازی',
        'Users' => 'کاربرها',
        'Employees' => 'کارمندها',
        'Administration' => 'مدیریت',
        'ACLRoles' => 'نقش‌ها',
        'InboundEmail' => 'ایمیل ورودی',
        'Releases' => 'نسخه‌ها',
        'Prospects' => 'اهداف',
        'Queues' => 'صف‌ها',
        'EmailMarketing' => 'بازاریابی ایمیلی',
        'EmailTemplates' => 'قالب‌های ایمیل',
        'ProspectLists' => 'فهرست - اهداف',
        'SavedSearch' => 'جستجوهای ذخیره شده',
        'UpgradeWizard' => 'ارتقا راهنما',
        'Trackers' => 'ردیاب',
        'TrackerSessions' => 'جلسات ردیاب',
        'TrackerQueries' => 'کوئری‌های ردیاب',
        'FAQ' => 'سوالات متداول',
        'Newsletters' => 'خبرنامه',
        'SugarFeed' => 'خوراک SuiteCRM',
        'SugarFavorites' => 'برگزیده‌های SuiteCRM',

        'OAuthKeys' => 'کلید های مصرفی OAuth',
        'OAuthTokens' => 'توکن OAuth',
        'OAuth2Clients' => 'OAuth کاربر',
        'OAuth2Tokens' => 'توکن OAuth',
    ),

    'moduleListSingular' => array(
        'Home' => 'خانه',
        'Dashboard' => 'پیشخوان',
        'Contacts' => 'مخاطب',
        'Accounts' => 'مرکز',
        'Opportunities' => 'فرصت',
        'Cases' => 'خدمات',
        'Notes' => 'یادداشت',
        'Calls' => 'تماس',
        'Emails' => 'ایمیل',
        'EmailTemplates' => 'قالب ایمیل',
        'Meetings' => 'جلسه',
        'Tasks' => 'وظیفه',
        'Calendar' => 'تقویم',
        'Leads' => 'سرنخ',
        'Activities' => 'فعالیت',
        'Bugs' => 'اشکال',
        'KBDocuments' => 'اسناد دانش محور',
        'Feeds' => 'خبر‌خوان',
        'iFrames' => 'سایت‌های من',
        'TimePeriods' => 'دوره زمانی',
        'Project' => 'پروژه',
        'ProjectTask' => 'وظیفه‌ی پروژه',
        'Prospects' => 'هدف',
        'Campaigns' => 'کمپین',
        'Documents' => 'سند',
        'Sync' => 'همگام‌سازی',
        'Users' => 'کاربر',
        'SugarFavorites' => 'برگزیده‌های SuiteCRM',

    ),

    'checkbox_dom' => array(
        '' => '',
        '1' => 'بله',
        '2' => 'خير',
    ),

    //e.g. en français 'Analyst'=>'Analyste',
    'account_type_dom' => array(
        '' => '',
        'Analyst' => 'تحلیل‌گر',
        'Competitor' => 'رقیب',
        'Customer' => 'مشتری',
        'Integrator' => 'تلفیق کننده',
        'Investor' => 'سرمایه‌گذار',
        'Partner' => 'شریک',
        'Press' => 'مطبوعات',
        'Prospect' => 'مشتری بالقوه',
        'Reseller' => 'نماینده‌ی فروش',
        'Other' => 'سایر',
    ),
    //e.g. en español 'Apparel'=>'Ropa',
    'industry_dom' => array(
        '' => '',
        'Apparel' => 'پوشاک',
        'Banking' => 'بانک‌داری',
        'Biotechnology' => 'بیوتکنولوژی',
        'Chemicals' => 'مواد شیمیایی',
        'Communications' => 'ارتباطات',
        'Construction' => 'ساخت و ساز',
        'Consulting' => 'مشاوره',
        'Education' => 'آموزش',
        'Electronics' => 'الکترونیک',
        'Energy' => 'انرژی',
        'Engineering' => 'مهندسی',
        'Entertainment' => 'سرگرمی',
        'Environmental' => 'محیط زیست',
        'Finance' => 'امور مالی',
        'Government' => 'دولت',
        'Healthcare' => 'بهداشت و درمان',
        'Hospitality' => 'مهمان‌داری',
        'Insurance' => 'بیمه',
        'Machinery' => 'ماشین آلات',
        'Manufacturing' => 'تولیدی',
        'Media' => 'رسانه',
        'Not For Profit' => 'غیرانتفاعی',
        'Recreation' => 'تفریح و سرگرمی',
        'Retail' => 'خرده فروشی',
        'Shipping' => 'حمل و نقل',
        'Technology' => 'فن‌آوری',
        'Telecommunications' => 'ارتباطات راه دور',
        'Transportation' => 'حمل و نقل',
        'Utilities' => 'صنایع همگانی',
        'Other' => 'سایر',
    ),
    'lead_source_default_key' => 'Self Generated',
    'lead_source_dom' => array(
        '' => '',
        'Cold Call' => 'تماس های تبلیغاتی',
        'Existing Customer' => 'مشتری‌های موجود',
        'Self Generated' => 'تولیدشده به صورت خودکار',
        'Employee' => 'کارمند',
        'Partner' => 'شریک',
        'Public Relations' => 'روابط عمومی',
        'Direct Mail' => 'پست مستقیم',
        'Conference' => 'کنفرانس',
        'Trade Show' => 'نمایشگاه تجاری',
        'Web Site' => 'وب سایت',
        'Word of mouth' => 'تبلیغات کلامی',
        'Email' => 'ایمیل',
        'Campaign' => 'کمپین',
        'Other' => 'سایر',
    ),
    'opportunity_type_dom' => array(
        '' => '',
        'Existing Business' => 'تجارت موجود',
        'New Business' => 'تجارت جدید',
    ),
    'roi_type_dom' => array(
        'Revenue' => 'درآمد',
        'Investment' => 'سرمایه‌گذاری',
        'Expected_Revenue' => 'درآمد مورد انتظار',
        'Budget' => 'بودجه',

    ),
    'subpanel_pagination_type' => [
        'pagination' => 'صفحات',
        'load-more' => 'نمایش بیشتر'
    ],
    'listview_pagination_type' => [
        'pagination' => 'صفحات',
        'load-more' => 'نمایش بیشتر'
    ],
    'record_modal_pagination_type' => [
        'pagination' => 'صفحات',
        'load-more' => 'نمایش بیشتر'
    ],
    //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
    'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
    'opportunity_relationship_type_dom' => array(
        '' => '',
        'Primary Decision Maker' => 'تصمیم‌گیرنده‌ی اولیه',
        'Business Decision Maker' => 'تصمیم‌گیرنده‌ی کسب و کار',
        'Business Evaluator' => 'ارزیاب کسب و کار',
        'Technical Decision Maker' => 'تصمیم‌گیرنده‌ی فنی',
        'Technical Evaluator' => 'ارزیاب فنی',
        'Executive Sponsor' => 'حامی اجرایی',
        'Influencer' => 'تاثیرگذار',
        'Other' => 'سایر',
    ),
    //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
    'case_relationship_type_default_key' => 'Primary Contact',
    'case_relationship_type_dom' => array(
        '' => '',
        'Primary Contact' => 'مخاطب اولیه',
        'Alternate Contact' => 'مخاطب جایگزین',
    ),
    'payment_terms' => array(
        '' => '',
        'Net 15' => 'نقدی 15 روزه',
        'Net 30' => 'نقدی 30 روزه',
    ),
    'sales_stage_default_key' => 'Prospecting',
    'sales_stage_dom' => array(
        'Prospecting' => 'بالقوه سازی',
        'Qualification' => 'صلاحیت سنجی',
        'Needs Analysis' => 'نیاز به بررسی',
        'Value Proposition' => 'مقایسه ارزش',
        'Id. Decision Makers' => 'شناسایی تصمیم گیرندگان',
        'Perception Analysis' => 'تحلیل ادراک',
        'Proposal/Price Quote' => 'پیشنهاد قیمت',
        'Negotiation/Review' => 'مذاکره/مرور',
        'Closed Won' => 'قرارداد بسته شد',
        'Closed Lost' => 'قرارداد فسخ شده',
    ),
    'sales_probability_dom' => // keys must be the same as sales_stage_dom
        array(
            'Prospecting' => '10',
            'Qualification' => '20',
            'Needs Analysis' => '25',
            'Value Proposition' => '30',
            'Id. Decision Makers' => '40',
            'Perception Analysis' => '50',
            'Proposal/Price Quote' => '65',
            'Negotiation/Review' => '80',
            'Closed Won' => '100',
            'Closed Lost' => '0',
        ),
    'activity_dom' => array(
        'Call' => 'تماس',
        'Meeting' => 'جلسه',
        'Task' => 'وظیفه',
        'Email' => 'ایمیل',
        'Note' => 'یادداشت',
    ),
    'salutation_dom' => array(
        '' => '',
        'Mr.' => 'آقای',
        'Ms.' => 'خانم',
        'Mrs.' => 'خانم.',
        'Miss' => 'خانم',
        'Dr.' => 'دکتر',
        'Prof.' => 'پروفسور',
    ),
    //time is in seconds; the greater the time the longer it takes;
    'reminder_max_time' => 90000,
    'reminder_time_options' => array(
        60 => '1 دقیقه قبل',
        300 => '5 دقیقه قبل',
        600 => '10 دقیقه قبل',
        900 => '15 دقیقه قبل',
        1800 => '30 دقیقه قبل',
        3600 => '1 ساعت قبل',
        7200 => '2 ساعت قبل',
        10800 => '3 ساعت قبل',
        18000 => '5 ساعت قبل',
        86400 => '1 روز قبل',
    ),

    // snooze for alerts
    'snooze_alert_timer' => array(
        60 => 'هشدار برای 1 دقیقه',
        300 => 'هشدار برای 5 دقیقه',
        600 => 'هشدار برای 10 دقیقه',
        900 => 'هشدار برای 15 دقیقه',
        1800 => 'هشدار برای 30 دقیقه',
        3600 => 'هشدار برای 1 ساعت',
        7200 => 'هشدار برای 2 ساعت',
        10800 => 'هشدار برای 3 ساعت',
        18000 => 'هشدار برای 5 ساعت',
        86400 => 'هشدار برای 1 روز',
    ),

    'snooze_alert_timer_simple' => array(
        60 => '1 دقیقه',
        300 => '5 دقیقه',
        600 => '10 دقیقه',
        900 => '15 دقیقه',
        1800 => '30 دقیقه',
        3600 => '1 ساعت',
        7200 => '2 ساعت',
        10800 => '3 ساعت',
        18000 => '5 ساعت',
        86400 => '1 روز',
    ),

    'task_priority_default' => 'متوسط',
    'task_priority_dom' => array(
        'High' => 'بالا',
        'Medium' => 'متوسط',
        'Low' => 'پایین',
    ),
    'task_status_default' => 'شروع نشده',
    'task_status_dom' => array(
        'Not Started' => 'شروع نشده',
        'In Progress' => 'در حال انجام',
        'Completed' => 'تکمیل شده',
        'Pending Input' => 'منتظر ورودی',
        'Deferred' => 'معوق',
    ),
    'meeting_status_default' => 'Planned',
    'meeting_status_dom' => array(
        'Planned' => 'برنامه‌ریزی شده',
        'Held' => 'برقرار شد',
        'Not Held' => 'برقرار نشد',
    ),
    'extapi_meeting_password' => array(
        'WebEx' => 'WebEx',
    ),
    'meeting_type_dom' => array(
        'Other' => 'سایر',
        'Sugar' => 'SuiteCRM',
    ),
    'call_status_default' => 'Planned',
    'call_status_dom' => array(
        'Planned' => 'برنامه‌ریزی شده',
        'Held' => 'برقرار شد',
        'Not Held' => 'برقرار نشد',
    ),
    'call_direction_default' => 'Outbound',
    'call_direction_dom' => array(
        'Inbound' => 'ورودی',
        'Outbound' => 'خروجی',
    ),
    'lead_status_dom' => array(
        '' => '',
        'New' => 'جدید',
        'Assigned' => 'محول شده',
        'In Process' => 'در حال پردازش',
        'Converted' => 'تبدیل شده',
        'Recycled' => 'بازیابی شده',
        'Dead' => 'از بین رفته',
    ),
    'case_priority_default_key' => 'P2',
    'case_priority_dom' => array(
        'P1' => 'بالا',
        'P2' => 'متوسط',
        'P3' => 'پایین',
    ),
    'user_type_dom' => array(
        'RegularUser' => 'کاربر عادی',
        'Administrator' => 'مدیر کل',
    ),
    'user_status_dom' => array(
        'Active' => 'فعال',
        'Inactive' => 'غیر فعال',
    ),
    'user_factor_auth_interface_dom' => array(
        'FactorAuthEmailCode' => 'کد ایمیل',
    ),
    'employee_status_dom' => array(
        'Active' => 'فعال',
        'Terminated' => 'فسخ شده',
        'Leave of Absence' => 'مرخصی',
    ),
    'messenger_type_dom' => array(
        '' => '',
        'MSN' => 'MSN',
        'Yahoo!' => 'Yahoo!',
        'AOL' => 'AOL',
    ),
    'project_task_priority_options' => array(
        'High' => 'بالا',
        'Medium' => 'متوسط',
        'Low' => 'پایین',
    ),
    'project_task_priority_default' => 'متوسط',

    'project_task_status_options' => array(
        'Not Started' => 'شروع نشده',
        'In Progress' => 'در حال انجام',
        'Completed' => 'تکمیل شده',
        'Pending Input' => 'منتظر ورودی',
        'Deferred' => 'معوق',
    ),
    'project_task_utilization_options' => array(
        '0' => 'هیچ‌کدام',
        '25' => '25',
        '50' => '50',
        '75' => '75',
        '100' => '100',
    ),

    'project_status_dom' => array(
        'Draft' => 'پیش نویس',
        'In Review' => 'در حال بررسی',
        'Underway' => 'در حال انجام',
        'On_Hold' => 'در انتظار',
        'Completed' => 'تکمیل شده',
    ),
    'project_status_default' => 'پیش نویس',

    'project_duration_units_dom' => array(
        'Days' => 'روز',
        'Hours' => 'ساعت',
    ),

    'activity_status_type_dom' => array(
        '' => '--هیچ--',
        'active' => 'فعال',
        'inactive' => 'غیرفعال',
    ),

    // Note:  do not translate record_type_default_key
    //        it is the key for the default record_type_module value
    'record_type_default_key' => 'حساب ها',
    'record_type_display' => array(
        '' => '',
        'Accounts' => 'مرکز',
        'Opportunities' => 'فرصت',
        'Cases' => 'خدمات',
        'Leads' => 'سرنخ',
        'Contacts' => 'مخاطب', // cn (11/22/2005) added to support Emails

        'Bugs' => 'اشکال',
        'Project' => 'پروژه',

        'Prospects' => 'هدف',
        'ProjectTask' => 'وظیفه‌ی پروژه',

        'Tasks' => 'وظیفه',

        'AOS_Contracts' => 'قرارداد',
        'AOS_Invoices' => 'فاکتور',
        'AOS_Quotes' => 'پیش‌فاکتور',
        'AOS_Products' => 'محصول',

    ),

    'record_type_display_notes' => array(
        'Accounts' => 'مرکز',
        'Contacts' => 'مخاطب',
        'Opportunities' => 'فرصت',
        'Campaigns' => 'کمپین',
        'Tasks' => 'وظیفه',
        'Emails' => 'ایمیل',

        'Bugs' => 'اشکال',
        'Project' => 'پروژه',
        'ProjectTask' => 'وظیفه‌ی پروژه',
        'Prospects' => 'هدف',
        'Cases' => 'خدمات',
        'Leads' => 'سرنخ',

        'Meetings' => 'جلسه',
        'Calls' => 'تماس',

        'AOS_Contracts' => 'قرارداد',
        'AOS_Invoices' => 'فاکتور',
        'AOS_Quotes' => 'پیش‌فاکتور',
        'AOS_Products' => 'محصول',
    ),

    'parent_type_display' => array(
        'Accounts' => 'مرکز',
        'Contacts' => 'مخاطب',
        'Tasks' => 'وظیفه',
        'Opportunities' => 'فرصت',

        'Bugs' => 'اشکال',
        'Cases' => 'خدمات',
        'Leads' => 'سرنخ',

        'Project' => 'پروژه',
        'ProjectTask' => 'وظیفه‌ی پروژه',

        'Prospects' => 'هدف',

        'AOS_Contracts' => 'قرارداد',
        'AOS_Invoices' => 'فاکتور',
        'AOS_Quotes' => 'پیش‌فاکتور',
        'AOS_Products' => 'محصول',

    ),
    'parent_line_items' => array(
        'AOS_Quotes' => 'پیش‌فاکتورها',
        'AOS_Invoices' => 'صورت‌حساب‌ها',
        'AOS_Contracts' => 'قراردادها',
    ),
    'issue_priority_default_key' => 'متوسط',
    'issue_priority_dom' => array(
        'Urgent' => 'فوری',
        'High' => 'بالا',
        'Medium' => 'متوسط',
        'Low' => 'پایین',
    ),
    'issue_resolution_default_key' => '',
    'issue_resolution_dom' => array(
        '' => '',
        'Accepted' => 'پذیرفته شده',
        'Duplicate' => 'تکراری',
        'Closed' => 'بسته',
        'Out of Date' => 'تاریخ گذشته',
        'Invalid' => 'نامعتبر',
    ),

    'issue_status_default_key' => 'جدید',
    'issue_status_dom' => array(
        'New' => 'جدید',
        'Assigned' => 'محول شده',
        'Closed' => 'بسته',
        'Pending' => 'انتظار',
        'Rejected' => 'رد شده',
    ),

    'bug_priority_default_key' => 'متوسط',
    'bug_priority_dom' => array(
        'Urgent' => 'فوری',
        'High' => 'بالا',
        'Medium' => 'متوسط',
        'Low' => 'پایین',
    ),
    'bug_resolution_default_key' => '',
    'bug_resolution_dom' => array(
        '' => '',
        'Accepted' => 'پذیرفته شده',
        'Duplicate' => 'تکراری',
        'Fixed' => 'برطرف شده',
        'Out of Date' => 'تاریخ گذشته',
        'Invalid' => 'نامعتبر',
        'Later' => 'بعداً',
    ),
    'bug_status_default_key' => 'جدید',
    'bug_status_dom' => array(
        'New' => 'جدید',
        'Assigned' => 'محول شده',
        'Closed' => 'بسته',
        'Pending' => 'در انتظار',
        'Rejected' => 'رد شده',
    ),
    'bug_type_default_key' => 'اشکال',
    'bug_type_dom' => array(
        'Defect' => 'نقص',
        'Feature' => 'ویژگی',
    ),
    'case_type_dom' => array(
        'Administration' => 'مدیریت',
        'Product' => 'مجصول',
        'User' => 'کاربر',
    ),

    'source_default_key' => '',
    'source_dom' => array(
        '' => '',
        'Internal' => 'داخلی',
        'Forum' => 'انجمن',
        'Web' => 'وب',
        'InboundEmail' => 'ایمیل',
    ),

    'product_category_default_key' => '',
    'product_category_dom' => array(
        '' => '',
        'Accounts' => 'مراکز',
        'Activities' => 'فعالیت‌ها',
        'Bugs' => 'اشکالات',
        'Calendar' => 'تقویم',
        'Calls' => 'تماس‌ها',
        'Campaigns' => 'کمپین‌ها',
        'Cases' => 'خدمات',
        'Contacts' => 'مخاطب‌ها',
        'Currencies' => 'واحدهای پول',
        'Dashboard' => 'پیشخوان',
        'Documents' => 'اسناد',
        'Emails' => 'ایمیل‌ها',
        'Feeds' => 'خوراک‌ها',
        'Forecasts' => 'پیش‌بینی‌ها',
        'Help' => 'کمک',
        'Home' => 'خانه',
        'Leads' => 'سرنخ‌ها',
        'Meetings' => 'جلسات',
        'Notes' => 'یادداشت‌ها',
        'Opportunities' => 'فرصت‌ها',
        'Outlook Plugin' => 'افزونه Outlook',
        'Projects' => 'پروژه‌ها',
        'Quotes' => 'پیش‌فاکتورها',
        'Releases' => 'نسخه‌ها',
        'RSS' => 'RSS',
        'Studio' => 'استودیو',
        'Upgrade' => 'ارتقاء',
        'Users' => 'کاربرها',
    ),
    /*Added entries 'Queued' and 'Sending' for 4.0 release..*/
    'campaign_status_dom' => array(
        '' => '',
        'Planning' => 'در حال برنامه‌ریزی',
        'Active' => 'فعال',
        'Inactive' => 'غیر فعال',
        'Complete' => 'تکمیل',
        //'In Queue' => 'In Queue',
        //'Sending' => 'Sending',
    ),
    'campaign_type_dom' => array(
        '' => '',
        'Telesales' => 'فروش تلفنی',
        'Mail' => 'پست',
        'Email' => 'ایمیل',
        'Print' => 'چاپی',
        'Web' => 'وب',
        'Radio' => 'رادیو',
        'Television' => 'تلویزیون',
        'NewsLetter' => 'خبرنامه',
        'Survey' => 'نظر سنجی',
    ),

    'newsletter_frequency_dom' => array(
        '' => '',
        'Weekly' => 'هفتگی',
        'Monthly' => 'ماهیانه',
        'Quarterly' => 'فصلی',
        'Annually' => 'سالانه',
    ),

    'notifymail_sendtype' => array(
        'SMTP' => 'SMTP',
    ),
    'dom_cal_month_long' => array(
        '0' => '',
        '1' => 'ژانویه',
        '2' => 'فوریه',
        '3' => 'مارس',
        '4' => 'آوریل',
        '5' => 'می',
        '6' => 'ژوئن',
        '7' => 'جولای',
        '8' => 'آگوست',
        '9' => 'سپتامبر',
        '10' => 'اکتبر',
        '11' => 'نوامبر',
        '12' => 'دسامبر',
    ),
    'dom_cal_month_short' => array(
        '0' => '',
        '1' => 'ژانویه',
        '2' => 'فوریه',
        '3' => 'مارس',
        '4' => 'آوریل',
        '5' => 'می',
        '6' => 'ژوئن',
        '7' => 'جولای',
        '8' => 'آگوست',
        '9' => 'سپتامبر',
        '10' => 'اکتبر',
        '11' => 'نوامبر',
        '12' => 'دسامبر',
    ),
    'dom_cal_day_long' => array(
        '0' => '',
        '1' => 'یکشنبه',
        '2' => 'دوشنبه',
        '3' => 'سه‌شنبه',
        '4' => 'چهارشنبه',
        '5' => 'پنج‌شنبه',
        '6' => 'جمعه',
        '7' => 'شنبه',
    ),
    'dom_cal_day_short' => array(
        '0' => '',
        '1' => 'یکشنبه',
        '2' => 'دوشنبه',
        '3' => 'سه‌شنبه',
        '4' => 'چهارشنبه',
        '5' => 'پنج‌شنبه',
        '6' => 'جمعه',
        '7' => 'شنبه',
    ),
    'dom_meridiem_lowercase' => array(
        'am' => 'قبل از ظهر',
        'pm' => 'بعد از ظهر',
    ),
    'dom_meridiem_uppercase' => array(
        'AM' => 'قبل از ظهر',
        'PM' => 'بعد از ظهر',
    ),

    'dom_inbound_email_account_types' => [
        'personal' => 'شخصی',
        'group' => 'گروه',
        'bounce' => 'Bounce',
    ],

    'dom_inbound_email_auth_types' => [
        'basic' => 'پایه Auth',
        'oauth' => 'OAuth',
    ],

    'dom_external_oauth_connection_types' => [
        'personal' => 'شخصی',
        'group' => 'گروه',
    ],

    'dom_external_oauth_provider_types' => [
        'personal' => 'شخصی',
        'group' => 'گروه',
    ],

    'dom_outbound_email_account_types' => [
        'user' => 'شخصی',
        'group' => 'گروه',
        'system' => 'سیستم',
        'system-override' => 'لغو سیستم',
    ],

    'dom_inbound_email_account_status' => [
        'Active' => 'فعال',
        'Inactive' => 'غیر فعال',
    ],

    'dom_email_types' => array(
        'out' => 'ارسال شده',
        'archived' => 'آرشیو شده',
        'draft' => 'پیش‌نویس',
        'inbound' => 'ورودی',
        'campaign' => 'کمپین',
    ),
    'dom_email_status' => array(
        'archived' => 'آرشیو شده',
        'closed' => 'بسته',
        'draft' => 'در پیش‌نویس',
        'read' => 'خوانده‌شده',
        'replied' => 'پاسخ داده‌شده',
        'sent' => 'ارسال شده',
        'send_error' => 'خطای ارسال',
        'unread' => 'خوانده نشده',
    ),
    'dom_email_archived_status' => array(
        'archived' => 'آرشیو شده',
    ),

    'dom_email_server_type' => array(
        '' => '--هیچ--',
        'imap' => 'IMAP',
    ),
    'dom_mailbox_type' => array(/*''           => '--None Specified--',*/
        'pick' => '--هیچ--',
        'createcase' => 'ایجاد خدمات',
        'bounce' => 'Bounce Handling',
    ),
    'dom_email_distribution' => array(
        '' => '--هیچ--',
        'direct' => 'اختصاص مستقیم',
        'roundRobin' => 'Round-Robin',
        'leastBusy' => 'کم مشغله‌ترین',
    ),
    'dom_email_errors' => array(
        1 => 'در هنگام اختصاص مستقیم آیتم ها تنها انتخاب یک کاربر مجاز است.',
        2 => 'در زمان اختصاص مستقیم ، باید فقط موارد تأیید شده را اختصاص دهید.',
    ),
    'dom_email_bool' => array(
        'bool_true' => 'بله',
        'bool_false' => 'خير',
    ),
    'dom_int_bool' => array(
        1 => 'بله',
        0 => 'خير',
    ),
    'dom_switch_bool' => array(
        'on' => 'بله',
        'off' => 'خير',
        '' => 'خير',
    ),

    'dom_email_link_type' => array(
        'sugar' => 'کلاینت ایمیل SuiteCRM',
        'mailto' => 'کلاینت ایمیل خارجی',
    ),

    'dom_editor_type' => array(
        'none' => 'HTML مستقیم',
        'tinymce' => 'TinyMCE',
        'mozaik' => 'موزاییک',
    ),

    'dom_email_editor_option' => array(
        '' => 'فرمت ایمیل پیش‌فرض',
        'html' => 'ایمیل‌ HTML',
        'plain' => 'ایمیل‌ متنی ساده',
    ),

    'schedulers_times_dom' => array(
        'not run' => 'از زمان اجرا گذشته، اجرا نشده',
        'ready' => 'آماده',
        'in progress' => 'در حال انجام',
        'failed' => 'انجام نشد',
        'completed' => 'تکمیل شده',
        'no curl' => 'اجرا نشده: cURL در دسترس نیست',
    ),

    'scheduler_status_dom' => array(
        'Active' => 'فعال',
        'Inactive' => 'غیر فعال',
    ),

    'scheduler_period_dom' => array(
        'min' => 'دقیقه',
        'hour' => 'ساعت',
    ),
    'document_category_dom' => array(
        '' => '',
        'Marketing' => 'بازاریابی',
        'Knowledege Base' => 'دانش بنیان',
        'Sales' => 'فروش',
    ),

    'email_category_dom' => array(
        '' => '',
        'Archived' => 'آرشیو شده',
        // TODO: add more categories here...
    ),

    'document_subcategory_dom' => array(
        '' => '',
        'Marketing Collateral' => 'تضمین بازاریابی',
        'Product Brochures' => 'بروشور محصولات',
        'FAQ' => 'سوالات متداول',
    ),

    'document_status_dom' => array(
        'Active' => 'فعال',
        'Draft' => 'پیش‌نویس',
        'FAQ' => 'سوالات متداول',
        'Expired' => 'منقضی شده',
        'Under Review' => 'تحت بررسی',
        'Pending' => 'در انتظار',
    ),
    'document_template_type_dom' => array(
        '' => '',
        'mailmerge' => 'ادغام پست',
        'eula' => 'EULA',
        'nda' => 'NDA',
        'license' => 'مجوز توافقنامه',
    ),
    'dom_meeting_accept_options' => array(
        'accept' => 'پذیرش',
        'decline' => 'رد',
        'tentative' => 'آزمایشی',
    ),
    'dom_meeting_accept_status' => array(
        'accept' => 'قبول شده',
        'decline' => 'رد شده',
        'tentative' => 'آزمایشی',
        'none' => 'هیچ‌کدام',
    ),
    'duration_intervals' => array(
        '0' => '00',
        '15' => '15',
        '30' => '30',
        '45' => '45',
    ),
    'repeat_type_dom' => array(
        '' => '--None--',
        'Daily' => 'روزانه',
        'Weekly' => 'هفتگی',
        'Monthly' => 'ماهیانه',
        'Yearly' => 'سالانه',
    ),

    'repeat_intervals' => array(
        '' => '',
        'Daily' => 'روز',
        'Weekly' => 'هفته',
        'Monthly' => 'ماه',
        'Yearly' => 'سال',
    ),

    'duration_dom' => array(
        '' => '--None--',
        '900' => '15 دقیقه',
        '1800' => '30 دقیقه',
        '2700' => '45 دقیقه',
        '3600' => '1 ساعت',
        '5400' => '1.5 ساعت',
        '7200' => '2 ساعت',
        '10800' => '3 ساعت',
        '21600' => '6 ساعت',
        '86400' => '1 روز',
        '172800' => '2 روز',
        '259200' => '3 روز',
        '604800' => '1 هفته',
    ),


//prospect list type dom
    'prospect_list_type_dom' => array(
        'default' => 'پیش‌فرض',
        'seed' => 'دانه',
        'exempt_domain' => 'لیست توقیف - توسط دامنه',
        'exempt_address' => 'لیست توقیف - توسط آدرس ایمیل',
        'exempt' => 'لیست توقیف - توسط شناسه',
        'test' => 'تست',
    ),

    'email_settings_num_dom' => array(
        '10' => '10',
        '20' => '20',
        '50' => '50',
    ),
    'email_marketing_status_dom' => array(
        '' => '',
        'active' => 'فعال',
        'inactive' => 'غیر فعال',
    ),

    'campainglog_activity_type_dom' => array(
        '' => '',
        'targeted' => 'پیام ارسال شد/به ارسال پیام اقدام شد',
        'send error' => 'ارسال ناموفق، سایر',
        'invalid email' => 'ارسال ناموفق، ایمیل نامعتبر',
        'link' => 'لینک قابل کلیک',
        'viewed' => 'پیام مشاهده‌شده',
        'removed' => 'انصراف داده',
        'lead' => 'سرنخ‌های ایجاد شده',
        'contact' => 'مخاطب‌های ایجاد شده',
        'blocked' => 'توسط آدرس یا دامنه متوقف شده',
        'Survey' => 'نظرسنجی پاسخ داده شده',
    ),

    'campainglog_target_type_dom' => array(
        'Contacts' => 'مخاطب‌ها',
        'Users' => 'کاربرها',
        'Prospects' => 'اهداف',
        'Leads' => 'سرنخ‌ها',
        'Accounts' => 'مراکز',
    ),
    'merge_operators_dom' => array(
        'like' => 'شامل',
        'exact' => 'دقیقاً',
        'start' => 'شروع می‌شود با',
    ),

    'custom_fields_importable_dom' => array(
        'true' => 'بله',
        'false' => 'خير',
        'required' => 'ضروری',
    ),

    'custom_fields_merge_dup_dom' => array(
        0 => 'غیرفعال شده',
        1 => 'فعال شده',
        2 => 'فیلتر',
        3 => 'Default selected filter',
        4 => 'Only filter',
    ),

    'projects_priority_options' => array(
        'high' => 'بالا',
        'medium' => 'متوسط',
        'low' => 'پایین',
    ),

    'projects_status_options' => array(
        'notstarted' => 'شروع نشده',
        'inprogress' => 'در حال انجام',
        'completed' => 'تکمیل شده',
    ),
    // strings to pass to Flash charts
    'chart_strings' => array(
        'expandlegend' => ' گسترش علائم اختصاری',
        'collapselegend' => 'بستن علائم اختصاری',
        'clickfordrilldown' => 'برای بررسی دقیق کلیک کنید',
        'detailview' => 'جزئیات بیشتر...',
        'piechart' => 'نمودار دایره‌ای',
        'groupchart' => 'نمودار گروهی',
        'stackedchart' => 'نمودار پشته‌ای',
        'barchart' => 'نمودار میله‌ای',
        'horizontalbarchart' => 'نمودار میله‌ای افقی',
        'linechart' => 'نمودار خطی',
        'noData' => 'داده در دسترس نیست',
        'print' => 'چاپ',
        'pieWedgeName' => 'بخش‌ها',
    ),
    'release_status_dom' => array(
        'Active' => 'فعال',
        'Inactive' => 'غیر فعال',
    ),
    'email_settings_for_ssl' => array(
        '0' => '',
        '1' => 'SSL',
        '2' => 'TLS',
    ),
    'import_enclosure_options' => array(
        '\'' => 'کوتیشن تکی (\')',
        '"' => 'کوتیشن دوتایی (")',
        '' => 'هیچ‌کدام',
        'other' => 'سایر:',
    ),
    'import_delimeter_options' => array(
        ',' => ',',
        ';' => ';',
        '\t' => '\t',
        '.' => '.',
        ':' => ':',
        '|' => '|',
        'other' => 'سایر:',
    ),
    'link_target_dom' => array(
        '_blank' => 'پنجره جديد',
        '_self' => 'همان پنجره',
    ),
    'dashlet_auto_refresh_options' => array(
        '-1' => 'خودکار ریفرش نشود',
        '30' => 'هر 30 ثانیه',
        '60' => 'هر 1 دقیقه',
        '180' => 'هر 3 دقیقه',
        '300' => 'هر 5 دقیقه',
        '600' => 'هر 10 دقیقه',
    ),
    'dashlet_auto_refresh_options_admin' => array(
        '-1' => 'هرگز',
        '30' => 'هر 30 ثانیه',
        '60' => 'هر 1 دقیقه',
        '180' => 'هر 3 دقیقه',
        '300' => 'هر 5 دقیقه',
        '600' => 'هر 10 دقیقه',
    ),
    'date_range_search_dom' => array(
        '=' => 'برابراست با',
        'not_equal' => 'نه در',
        'greater_than' => 'بعد از',
        'less_than' => 'قبل از',
        'last_7_days' => '7 روز گذشته',
        'next_7_days' => '7 روز آینده',
        'last_30_days' => '30 روز گذشته',
        'next_30_days' => '30 روز آینده',
        'last_month' => 'ماه گذشته',
        'this_month' => 'این ماه',
        'next_month' => 'ماه آینده',
        'last_year' => 'سال گذشته',
        'this_year' => 'امسال',
        'next_year' => 'سال آینده',
        'between' => 'هست بین',
    ),
    'numeric_range_search_dom' => array(
        '=' => 'برابراست با',
        'not_equal' => 'برابر نیست با',
        'greater_than' => 'بزرگ‌تر از',
        'greater_than_equals' => 'بزرگ‌تر یا برابر با',
        'less_than' => 'کوچک‌تر از',
        'less_than_equals' => 'کوچک‌تر یا برابر با',
        'between' => 'هست بین',
    ),
    'lead_conv_activity_opt' => array(
        'copy' => 'کپی',
        'move' => 'جابجا',
        'donothing' => 'هیچ کاری انجام نده',
    ),
);

$app_strings = array(
    'LBL_SEARCH_REAULTS_TITLE' => 'نتایج',
    'ERR_SEARCH_INVALID_QUERY' => 'در هنگام جستجو خطایی رخ داده است. ممکن است متن جستجوی شما معتبر نباشد.',
    'ERR_SEARCH_NO_RESULTS' => 'هیچ نتیجه ای مطابق با معیارهای جستجوی شما یافت نشد. جستجوی خود را کلی تر کنید.',
    'LBL_SEARCH_PERFORMED_IN' => 'جستجوی انجام شده',
    'LBL_EMAIL_CODE' => 'کد ایمیل:',
    'LBL_SEND' => 'ارسال',
    'LBL_LOGOUT' => 'خروج',
    'LBL_LOGOUT_SUCCESS' => 'خروج موفق',
    'LBL_LOGGED_OUT_MESSAGE' => 'شما خارج شده اید',
    'LBL_LOGIN_AGAIN' => 'ورود مجدد ',
    'LBL_TOUR_NEXT' => 'ادامه',
    'LBL_TOUR_SKIP' => 'صرف‌نظر',
    'LBL_TOUR_BACK' => 'بازگشت',
    'LBL_TOUR_TAKE_TOUR' => 'تور آشنایی با سیستم را ببین',
    'LBL_MOREDETAIL' => 'جزئیات بیشتر' /*for 508 compliance fix*/,
    'LBL_EDIT_INLINE' => 'ویرایش درون‌خطی' /*for 508 compliance fix*/,
    'LBL_VIEW_INLINE' => 'مشاهده' /*for 508 compliance fix*/,
    'LBL_BASIC_SEARCH' => 'فیلتر' /*for 508 compliance fix*/,
    'LBL_Blank' => ' ' /*for 508 compliance fix*/,
    'LBL_ID_FF_ADD' => 'ﺍﻓﺰﻭﺩﻥ' /*for 508 compliance fix*/,
    'LBL_ID_FF_ADD_EMAIL' => 'افزودن آدرس ایمیل' /*for 508 compliance fix*/,
    'LBL_HIDE_SHOW' => 'مخفی کردن/نمایش' /*for 508 compliance fix*/,
    'LBL_DELETE_INLINE' => 'حذف' /*for 508 compliance fix*/,
    'LBL_ID_FF_CLEAR' => 'پاکسازی' /*for 508 compliance fix*/,
    'LBL_ID_FF_VCARD' => 'vCard' /*for 508 compliance fix*/,
    'LBL_ID_FF_REMOVE' => 'حذف' /*for 508 compliance fix*/,
    'LBL_ID_FF_REMOVE_EMAIL' => 'حذف آدرس ایمیل' /*for 508 compliance fix*/,
    'LBL_ID_FF_OPT_OUT' => 'انصراف',
    'LBL_ID_FF_INVALID' => 'Make Invalid',
    'LBL_ADD' => 'ﺍﻓﺰﻭﺩﻥ' /*for 508 compliance fix*/,
    'LBL_COMPANY_LOGO' => 'لوگوی شرکت' /*for 508 compliance fix*/,
    'LBL_CONNECTORS_POPUPS' => 'پاپ-آپ اتصالگرها',
    'LBL_CLOSEINLINE' => 'بستن',
    'LBL_VIEWINLINE' => 'مشاهده',
    'LBL_INFOINLINE' => 'اطلاعات',
    'LBL_PRINT' => 'چاپ',
    'LBL_HELP' => 'کمک',
    'LBL_ID_FF_SELECT' => 'انتخاب',
    'DEFAULT' => 'ساده',
    'LBL_SORT' => 'مرتب‌سازی',
    'LBL_EMAIL_SMTP_SSL_OR_TLS' => 'SMTP براساس SSL فعال شود یا TLS؟',
    'LBL_NO_ACTION' => 'هیچ عملیاتی با این نام وجود ندارد: %s',
    'LBL_NO_SHORTCUT_MENU' => 'هیچ اقدامی در دسترس نیست.',
    'LBL_NO_DATA' => 'بدون داده',

    'LBL_ROUTING_FLAGGED' => 'پرچم‌گذاری شد',
    'LBL_ROUTING_TO' => 'به',
    'LBL_ROUTING_TO_ADDRESS' => 'به آدرس',
    'LBL_ROUTING_WITH_TEMPLATE' => 'با الگو',

    'NTC_OVERWRITE_ADDRESS_PHONE_CONFIRM' => 'در حال حاضر این رکورد شامل مقادیر در فیلد دفتر تلفن و آدرس می باشد. برای بازنویسی این مقادیر براساس تلفن و آدرس حسابی که شما انتخاب نموده اید، روی "تایید" کلیک نمایید در غیر این صورت برای حفظ مقادیر فعلی، روی "لغو" کلیک نمایید.',
    'LBL_DROP_HERE' => '[در اینجا رها کنید]',
    'LBL_EMAIL_ACCOUNTS_GMAIL_DEFAULTS' => 'با پیش فرض &#153; پرکنید',
    'LBL_EMAIL_ACCOUNTS_NAME' => 'نام',
    'LBL_EMAIL_ACCOUNTS_OUTBOUND' => 'ویژگی‌های سرور ایمیل خروجی',
    'LBL_EMAIL_ACCOUNTS_SMTPPASS' => 'گذرواژه SMTP',
    'LBL_EMAIL_ACCOUNTS_SMTPPORT' => 'پورت SMTP',
    'LBL_EMAIL_ACCOUNTS_SMTPSERVER' => 'سرور SMTP',
    'LBL_EMAIL_ACCOUNTS_SMTPUSER' => 'نام کاربری SMTP',
    'LBL_EMAIL_ACCOUNTS_SMTPDEFAULT' => 'پیش‌فرض',
    'LBL_EMAIL_WARNING_MISSING_USER_CREDS' => 'هشدار: نام کاربری و گذرواژه برای حساب ایمیل خروجی وجود ندارد.',
    'LBL_OAUTH_CONNECTION_NOT_SET' => 'لطفاً یک اتصال OAuth خارجی تنظیم کنید.',
    'LBL_EMAIL_PASSWORD_NOT_SET' => 'هشدار: رمز عبور تنظیم نشده است.',
    'LBL_EMAIL_WARNING_MISSING_CREDS' => 'اخطار: اعتبارنامه وجود ندارد',
    'LBL_EMAIL_ACCOUNTS_SUBTITLE' => '"حساب‌های پست الکترونیک" را برای مشاهده پست الکترونیک های ورودی (از حساب پست الکترونیک خودتان) تنظیم نمایید.',
    'LBL_EMAIL_ACCOUNTS_OUTBOUND_SUBTITLE' => 'اطلاعات سرور پست الکترونیک SMTP را برای استفاده از پست الکترونیک خروجی در حساب‌های پست الکترونیک ارائه دهید.',

    'LBL_EMAIL_ADDRESS_BOOK_ADD' => 'ﺍﻧﺠﺎﻡ شد',
    'LBL_EMAIL_ADDRESS_BOOK_CLEAR' => 'پاکسازی',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_TO' => 'به:',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_CC' => 'رونوشت:',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_BCC' => 'رونوشت مخفی:',
    'LBL_EMAIL_ADDRESS_BOOK_ADRRESS_TYPE' => 'To/Cc/Bcc',
    'LBL_EMAIL_ADDRESS_BOOK_EMAIL_ADDR' => 'آدرس ایمیل',
    'LBL_EMAIL_ADDRESS_BOOK_FILTER' => 'فیلتر',
    'LBL_EMAIL_ADDRESS_BOOK_NAME' => 'نام',
    'LBL_EMAIL_ADDRESS_BOOK_NOT_FOUND' => 'هیچ آدرسی یافت نشد',
    'LBL_EMAIL_ADDRESS_BOOK_SAVE_AND_ADD' => 'ذخیره و افزودن به دفترچه آدرس',
    'LBL_EMAIL_ADDRESS_BOOK_SELECT_TITLE' => 'انتخاب دریافت کنندگان ایمیل',
    'LBL_EMAIL_ADDRESS_BOOK_TITLE' => 'دفترچه‌ آدرس',
    'LBL_EMAIL_REMOVE_SMTP_WARNING' => 'هشدار! این حساب کاربری خروجی که شما سعی در حذف آن دارید، مربوط به یک حساب کاربری وردوی موجود است. آیا از ادامه اطمینان دارید؟',
    'LBL_EMAIL_ADDRESSES' => 'ایمیل',
    'LBL_EMAIL_ADDRESS_PRIMARY' => 'آدرس ایمیل',
    'LBL_EMAIL_ADDRESS_OPT_IN' => 'شما تأیید کرده اید که آدرس ایمیل شما انتخاب شده است: ',
    'LBL_EMAIL_ADDRESS_OPT_IN_ERR' => 'تایید آدرس ایمیل امکان‌پذیر نیست',
    'LBL_EMAIL_ARCHIVE_TO_SUITE' => 'درون‌ریزی به SuiteCRM',
    'LBL_EMAIL_ASSIGNMENT' => 'تکلیف',
    'LBL_EMAIL_ATTACH_FILE_TO_EMAIL' => 'پیوست',
    'LBL_EMAIL_ATTACHMENT' => 'پیوست',
    'LBL_EMAIL_ATTACHMENTS' => 'از سیستم محلی',
    'LBL_EMAIL_ATTACHMENTS2' => 'از اسناد SuiteCRM',
    'LBL_EMAIL_ATTACHMENTS3' => 'پیوست‌های قالب',
    'LBL_EMAIL_ATTACHMENTS_FILE' => 'فایل',
    'LBL_EMAIL_ATTACHMENTS_DOCUMENT' => 'سند',
    'LBL_EMAIL_BCC' => 'رونوشت پنهان',
    'LBL_EMAIL_CANCEL' => 'لغو',
    'LBL_EMAIL_CC' => 'رونوشت',
    'LBL_EMAIL_CHARSET' => 'مجموعه کاراکترها',
    'LBL_EMAIL_CHECK' => 'بررسی ایمیل',
    'LBL_EMAIL_CHECKING_NEW' => 'بررسی برای ایمیل جدید',
    'LBL_EMAIL_CHECKING_DESC' => 'لطفا یک لحظه صبر کنید...<br><br>اگر این اولین بررسی حساب ایمیل است، احتمال دارد کمی طول بکشد.',
    'LBL_EMAIL_CLOSE' => 'بستن',
    'LBL_EMAIL_COFFEE_BREAK' => 'بررسی ایمیل‌ جدید. <br><br>برای حساب‌های ایمیل حجیم ممکن است خیلی طول بکشد.',

    'LBL_EMAIL_COMPOSE' => 'ایمیل',
    'LBL_EMAIL_COMPOSE_ERR_NO_RECIPIENTS' => 'لطفاً گیرند(گان) این ایمیل را وارد کنید.',
    'LBL_EMAIL_COMPOSE_NO_BODY' => 'متن ایمیل خالی است. با این حال ارسال شود؟',
    'LBL_EMAIL_COMPOSE_NO_SUBJECT' => 'این ایمیل عنوان ندارد. با این حال ارسال شود؟',
    'LBL_EMAIL_COMPOSE_NO_SUBJECT_LITERAL' => '(بدون موضوع)',
    'LBL_EMAIL_COMPOSE_INVALID_ADDRESS' => 'لطفاً برای کادرهای To/CC/BCC آدرس ایمیل معتبر وارد کنید',

    'LBL_EMAIL_CONFIRM_CLOSE' => 'از بین بردن این ایمیل؟',
    'LBL_EMAIL_CONFIRM_DELETE_SIGNATURE' => 'آیا از حذف این امضا اطمینان دارید؟',

    'LBL_EMAIL_SENT_SUCCESS' => 'ایمیل فرستاده شد',

    'LBL_EMAIL_CREATE_NEW' => '--ایجاد در ذخیره--',
    'LBL_EMAIL_MULT_GROUP_FOLDER_ACCOUNTS' => 'چندگانه',
    'LBL_EMAIL_MULT_GROUP_FOLDER_ACCOUNTS_EMPTY' => 'خالی',
    'LBL_EMAIL_DATE_SENT_BY_SENDER' => 'تاریخ ارسال توسط فرستنده',
    'LBL_EMAIL_DATE_TODAY' => 'امروز',
    'LBL_EMAIL_DELETE' => 'حذف',
    'LBL_EMAIL_DELETE_CONFIRM' => 'حذف پیام‌های انتخاب شده؟',
    'LBL_EMAIL_DELETE_SUCCESS' => 'ایمیل با موفقیت حذف شد.',
    'LBL_EMAIL_DELETING_MESSAGE' => 'در حال حذف پیام',
    'LBL_EMAIL_DETAILS' => 'جزئيات',

    'LBL_EMAIL_EDIT_CONTACT_WARN' => 'تنها آدرس‌ اصلی در زمان کار کردن با مخاطب‌ها استفاده می‌شود.',

    'LBL_EMAIL_EMPTYING_TRASH' => 'خالی کردن سطل زباله',
    'LBL_EMAIL_DELETING_OUTBOUND' => 'در حال حذف سرور خروجی',
    'LBL_EMAIL_CLEARING_CACHE_FILES' => 'پاک کردن فایل‌های کش',
    'LBL_EMAIL_EMPTY_MSG' => 'هیچ ایمیلی برای نمایش وجود ندارد.',
    'LBL_EMAIL_EMPTY_ADDR_MSG' => 'هیچ آدرس ایمیلی برای نمایش وجود ندارد.',

    'LBL_EMAIL_ERROR_ADD_GROUP_FOLDER' => 'نام پوشه باید یکتا بوده و خالی نباشد. لطفا دوباره تلاش کنید.',
    'LBL_EMAIL_ERROR_DELETE_GROUP_FOLDER' => 'یک پوشه قابل حذف نیست. این پوشه یا زیرمجموعه‌هایش با ایمیل‌ها یا یک صندوق پستی مرتبط هستند.',
    'LBL_EMAIL_ERROR_CANNOT_FIND_NODE' => 'نمی توان پوشه‌ی مورد نظر در این زمینه را مشخص کرد. لطفا دوباره سعی کنید.',
    'LBL_EMAIL_ERROR_CHECK_IE_SETTINGS' => 'لطفا تنظیمات را بررسی کنید.',
    'LBL_EMAIL_ERROR_DESC' => 'خطاهایی یافت شد: ',
    'LBL_EMAIL_DELETE_ERROR_DESC' => 'شما به این بخش دسترسی ندارید. جهت بدست آوردن دسترسی با مدیر سایت خود تماس بگیرید.',
    'LBL_EMAIL_ERROR_DUPE_FOLDER_NAME' => 'نام پوشه SuiteCRM باید یکتا باشد.',
    'LBL_EMAIL_ERROR_EMPTY' => 'لطفاً چند معیار جستجو وارد کنید.',
    'LBL_EMAIL_ERROR_GENERAL_TITLE' => 'یک خطا رخ داده است',
    'LBL_EMAIL_ERROR_MESSAGE_DELETED' => 'پیام از سرور حذف شد',
    'LBL_EMAIL_ERROR_IMAP_MESSAGE_DELETED' => 'پیام مورد نظر حذف شده یا به پوشه‌ی دیگری منتقل شده است',
    'LBL_EMAIL_ERROR_MAILSERVERCONNECTION' => 'عدم موفقیت در اتصال به سرور ایمیل. لطفا با مدیر تماس بگیرید',
    'LBL_EMAIL_ERROR_MOVE' => 'در حال حاضر از جابجا کردن ایمیل بین سرورها و/یا بین حساب‌های ایمیل، پشتیبانی نمی‌شود.',
    'LBL_EMAIL_ERROR_MOVE_TITLE' => 'خطا در جابجایی',
    'LBL_EMAIL_ERROR_NAME' => 'یک نام مورد نیاز است.',
    'LBL_EMAIL_ERROR_FROM_ADDRESS' => 'آدرس فرستنده مورد نیاز است. لطفا یک آدرس ایمیل معتبر وارد کنید.',
    'LBL_EMAIL_ERROR_NO_FILE' => 'لطفا یک فایل فراهم کنید.',
    'LBL_EMAIL_ERROR_SERVER' => 'آدرس سرور ایمیل مورد نیاز است.',
    'LBL_EMAIL_ERROR_SAVE_ACCOUNT' => 'حساب ایمیل احتمالا ذخیره نشده است.',
    'LBL_EMAIL_ERROR_TIMEOUT' => 'در برقراری ارتباط با سرور ایمیل خطایی رخ داده است.',
    'LBL_EMAIL_ERROR_USER' => 'نام ورود به سیستم مورد نیاز است.',
    'LBL_EMAIL_ERROR_PORT' => 'پورت سرور ایمیل مورد نیاز است.',
    'LBL_EMAIL_ERROR_PROTOCOL' => 'پروتکل سرور مورد نیاز است.',
    'LBL_EMAIL_ERROR_MONITORED_FOLDER' => 'پوشه های تحت نظارت مورد نیاز است.',
    'LBL_EMAIL_ERROR_TRASH_FOLDER' => 'پوشه سطل زباله مورد نیاز است.',
    'LBL_EMAIL_ERROR_VIEW_RAW_SOURCE' => 'این اطلاعات در دسترس نیست',
    'LBL_EMAIL_ERROR_NO_OUTBOUND' => 'هیچ سرور خروجی ایمیلی مشخص نشده است.',
    'LBL_EMAIL_ERROR_SENDING' => 'خطا در ارسال ایمیل. لطفا برای رسیدگی با مدیر تماس حاصل نمایید.',
    'LBL_EMAIL_FOLDERS' => SugarThemeRegistry::current()->getImage('icon_email_folder', 'align=absmiddle border=0', null, null, '.gif', '') . 'پوشه‌ها',
    'LBL_EMAIL_FOLDERS_SHORT' => SugarThemeRegistry::current()->getImage('icon_email_folder', 'align=absmiddle border=0', null, null, '.gif', ''),
    'LBL_EMAIL_FOLDERS_ADD' => 'ﺍﻓﺰﻭﺩﻥ',
    'LBL_EMAIL_FOLDERS_ADD_DIALOG_TITLE' => 'افزودن پوشه جدید',
    'LBL_EMAIL_FOLDERS_RENAME_DIALOG_TITLE' => 'تغییر نام پوشه',
    'LBL_EMAIL_FOLDERS_ADD_NEW_FOLDER' => 'ذخيره',
    'LBL_EMAIL_FOLDERS_ADD_THIS_TO' => 'افزودن این پوشه به',
    'LBL_EMAIL_FOLDERS_CHANGE_HOME' => 'این پوشه را نمی‌توان تغییر داد',
    'LBL_EMAIL_FOLDERS_DELETE_CONFIRM' => 'آیا از حذف این پوشه مطمئن هستید؟\nاین فرآیند برگشت پذیر نیست.\nبا حذف این پوشه، تمام پوشه‌های درون آن نیز خذف خواهند شد.',
    'LBL_EMAIL_FOLDERS_NEW_FOLDER' => 'نام پوشه جدید',
    'LBL_EMAIL_FOLDERS_NO_VALID_NODE' => 'لطفا قبل از انجام این کار یک پوشه را انتخاب کنید.',
    'LBL_EMAIL_FOLDERS_TITLE' => 'مدیریت پوشه‌ها',

    'LBL_EMAIL_FORWARD' => 'ارسال',
    'LBL_EMAIL_DELIMITER' => '::;::',
    'LBL_EMAIL_DOWNLOAD_STATUS' => '[count] از [total] ایمیل دانلود شد',
    'LBL_EMAIL_FROM' => 'فرستنده',
    'LBL_EMAIL_GROUP' => 'گروه',
    'LBL_EMAIL_UPPER_CASE_GROUP' => 'گروه',
    'LBL_EMAIL_HOME_FOLDER' => 'خانه',
    'LBL_EMAIL_IE_DELETE' => 'در حال حذف حساب ایمیل',
    'LBL_EMAIL_IE_DELETE_SIGNATURE' => 'در حال حذف امضا',
    'LBL_EMAIL_IE_DELETE_CONFIRM' => 'آیا از حذف این حساب ایمیل مطمئن هستید؟',
    'LBL_EMAIL_IE_DELETE_SUCCESSFUL' => 'حذف موفق.',
    'LBL_EMAIL_IE_SAVE' => 'در حال ذخیره‌ی اطلاعات حساب ایمیل',
    'LBL_EMAIL_IMPORTING_EMAIL' => 'درون‌ریزی ایمیل',
    'LBL_EMAIL_IMPORT_EMAIL' => 'درون‌ریزی به SuiteCRM',
    'LBL_EMAIL_IMPORT_SETTINGS' => 'درون‌ریزی تنظیمات',
    'LBL_EMAIL_INVALID' => 'نامعتبر',
    'LBL_EMAIL_LOADING' => 'در حال بارگذاری...',
    'LBL_EMAIL_MARK' => 'علامت‌گذاری',
    'LBL_EMAIL_MARK_FLAGGED' => 'نشانه دار',
    'LBL_EMAIL_MARK_READ' => 'به عنوان خوانده‌شده',
    'LBL_EMAIL_MARK_UNFLAGGED' => 'به عنوان علامتگذاری نشده',
    'LBL_EMAIL_MARK_UNREAD' => 'به عنوان خوانده‌نشده',
    'LBL_EMAIL_ASSIGN_TO' => 'اختصاص به',

    'LBL_EMAIL_MENU_ADD_FOLDER' => 'ایجاد پوشه',
    'LBL_EMAIL_MENU_COMPOSE' => 'ارسال به',
    'LBL_EMAIL_MENU_DELETE_FOLDER' => 'حذف پوشه',
    'LBL_EMAIL_MENU_EMPTY_TRASH' => 'خالی کردن زباله‌دان',
    'LBL_EMAIL_MENU_SYNCHRONIZE' => 'همگام‌سازی',
    'LBL_EMAIL_MENU_CLEAR_CACHE' => 'خالی کردن حافظه موقت',
    'LBL_EMAIL_MENU_REMOVE' => 'حذف',
    'LBL_EMAIL_MENU_RENAME_FOLDER' => 'تغییر نام پوشه',
    'LBL_EMAIL_MENU_RENAMING_FOLDER' => 'در حال تغییر نام پوشه',
    'LBL_EMAIL_MENU_MAKE_SELECTION' => 'لطفا پیش از انجام این عملیات، بخشی را انتخاب کنید.',

    'LBL_EMAIL_MENU_HELP_ADD_FOLDER' => 'ایجاد پوشه (از راه دور و یا در SuiteCRM)',
    'LBL_EMAIL_MENU_HELP_DELETE_FOLDER' => 'حذف یک پوشه (از راه دور و یا در SuiteCRM)',
    'LBL_EMAIL_MENU_HELP_EMPTY_TRASH' => 'تمام پوشه‌های زباله‌دان در حساب‌های ایمیل شما را خالی خواهد کرد',
    'LBL_EMAIL_MENU_HELP_MARK_READ' => 'این ایمیل(ها) را به عنوان خوانده شده علامت‌گذاری کن',
    'LBL_EMAIL_MENU_HELP_MARK_UNFLAGGED' => 'علامت گذاری ایمیل(ها) به عنوان نشان گذاری نشده',
    'LBL_EMAIL_MENU_HELP_RENAME_FOLDER' => 'تغییر نام پوشه (از راه دور و یا در SuiteCRM)',

    'LBL_EMAIL_MESSAGES' => 'پیام‌ها',

    'LBL_EMAIL_ML_NAME' => 'نام لیست',
    'LBL_EMAIL_ML_ADDRESSES_1' => 'آدرس‌های لیست انتخاب شده',
    'LBL_EMAIL_ML_ADDRESSES_2' => 'آدرس‌های لیست موجود',

    'LBL_EMAIL_MULTISELECT' => 'برای انتخاب چند گزینه با نگهداشتن دکمه کنترل کلیک نمایید<br/>
(کاربران مک از دکمه کامند و کلیک استفاده نمایند)',

    'LBL_EMAIL_NO' => 'خير',
    'LBL_EMAIL_NOT_SENT' => 'سیستم قادر به پردازش درخواست شما نیست. لطفاً با مدیر سیستم تماس بگیرید.',

    'LBL_EMAIL_OK' => 'باشه',
    'LBL_EMAIL_ONE_MOMENT' => 'یک لحظه لطفاً...',
    'LBL_EMAIL_OPEN_ALL' => 'باز کردن چندین پیام',
    'LBL_EMAIL_OPTIONS' => 'گزینه ها',
    'LBL_EMAIL_QUICK_COMPOSE' => 'نوشتن سریع',
    'LBL_EMAIL_OPT_OUT' => 'انصراف داده',
    'LBL_EMAIL_OPT_OUT_AND_INVALID' => 'رد شد و غیر معتبر است',
    'LBL_EMAIL_PERFORMING_TASK' => 'در حال انجام وظیفه',
    'LBL_EMAIL_PRIMARY' => 'اصلی',
    'LBL_EMAIL_PRINT' => 'چاپ',

    'LBL_EMAIL_QC_BUGS' => 'اشکال',
    'LBL_EMAIL_QC_CASES' => 'مورد',
    'LBL_EMAIL_QC_LEADS' => 'شخص آگاه',
    'LBL_EMAIL_QC_CONTACTS' => 'مخاطب',
    'LBL_EMAIL_QC_TASKS' => 'وظیفه',
    'LBL_EMAIL_QC_OPPORTUNITIES' => 'فرصت',
    'LBL_EMAIL_QUICK_CREATE' => 'ایجاد سریع',

    'LBL_EMAIL_REBUILDING_FOLDERS' => 'در حال بازسازی پوشه‌ها',
    'LBL_EMAIL_RELATE_TO' => 'مربوط',
    'LBL_EMAIL_VIEW_RELATIONSHIPS' => 'مشاهده روابط',
    'LBL_EMAIL_RECORD' => 'رکورد ایمیل',
    'LBL_EMAIL_REMOVE' => 'حذف',
    'LBL_EMAIL_REPLY' => 'پاسخ',
    'LBL_EMAIL_REPLY_ALL' => 'پاسخ به همه',
    'LBL_EMAIL_REPLY_TO' => 'پاسخ به',
    'LBL_EMAIL_RETRIEVING_MESSAGE' => 'بازیابی پیام',
    'LBL_EMAIL_RETRIEVING_RECORD' => 'بازیابی رکورد ایمیل',
    'LBL_EMAIL_SELECT_ONE_RECORD' => 'لطفا فقط یک رکورد ایمیل را انتخاب کنید',
    'LBL_EMAIL_RETURN_TO_VIEW' => 'بازگشت به ماژول قبلی؟',
    'LBL_EMAIL_REVERT' => 'برگرداندن',
    'LBL_EMAIL_RELATE_EMAIL' => 'ایمیل مربوط',

    'LBL_EMAIL_RULES_TITLE' => 'مدیریت قوانین',

    'LBL_EMAIL_SAVE' => 'ذخيره',
    'LBL_EMAIL_SAVE_AND_REPLY' => 'ذخیره و پاسخ',
    'LBL_EMAIL_SAVE_DRAFT' => 'ذخیره‌ی پیش‌نویس',
    'LBL_EMAIL_DRAFT_SAVED' => 'پیش‌نویس ذخیره شده است',

    'LBL_EMAIL_SEARCH' => SugarThemeRegistry::current()->getImage('Search', 'align=absmiddle border=0', null, null,    '.gif', ''),
    'LBL_EMAIL_SEARCH_SHORT' => SugarThemeRegistry::current()->getImage('Search', 'align=absmiddle border=0', null,        null, '.gif', ''),
    'LBL_EMAIL_SEARCH_DATE_FROM' => 'از تاریخ',
    'LBL_EMAIL_SEARCH_DATE_UNTIL' => 'تا تاریخ',
    'LBL_EMAIL_SEARCH_NO_RESULTS' => 'هیچ نتیجه‌ای مطابق جستجوی شما وجود ندارد.',
    'LBL_EMAIL_SEARCH_RESULTS_TITLE' => 'نتایج جستجو',

    'LBL_EMAIL_SELECT' => 'انتخاب',

    'LBL_EMAIL_SEND' => 'ارسال',
    'LBL_EMAIL_SENDING_EMAIL' => 'در حال ارسال ایمیل',

    'LBL_EMAIL_SETTINGS' => 'تنطیمات',
    'LBL_EMAIL_SETTINGS_ACCOUNTS' => 'حساب ایمیل',
    'LBL_EMAIL_SETTINGS_ADD_ACCOUNT' => 'پاک کردن فرم',
    'LBL_EMAIL_SETTINGS_CHECK_INTERVAL' => 'بررسی برای ایمیل جدید',
    'LBL_EMAIL_SETTINGS_FROM_ADDR' => 'آدرس فرستنده',
    'LBL_EMAIL_SETTINGS_FROM_TO_EMAIL_ADDR' => 'آدرس ایمیل برای آزمودن اعلان:',
    'LBL_EMAIL_SETTINGS_FROM_NAME' => 'نام فرستنده',
    'LBL_EMAIL_SETTINGS_REPLY_TO_ADDR' => 'پاسخ به آدرس',
    'LBL_EMAIL_SETTINGS_FULL_SYNC' => 'همگام‌سازی حساب‌های ایمیل',
    'LBL_EMAIL_TEST_NOTIFICATION_SENT' => 'یک ایمیل به آدرس مشخص شده، با استفاده از تنظیمات ثبت شده برای نامه ی خروجی، ارسال شد. لطفا برای آنکه از صحت تنظیمات مطمئن شوید، بررسی نمایید که ایمیل دریافت شده باشد.',
    'LBL_EMAIL_TEST_SEE_FULL_SMTP_LOG' => 'مشاهده لاگ کامل SMTP',
    'LBL_EMAIL_SETTINGS_FULL_SYNC_WARN' => 'انجام همگام‌سازی کامل\nبرای ایمیل‌هایی با حجم زیاد ممکن است چند دقیقه زمان ببرد.',
    'LBL_EMAIL_SUBSCRIPTION_FOLDER_HELP' => 'برای انتخاب چند پوشه دکمه Ctrl یا Shift را نگه دارید.',
    'LBL_EMAIL_SETTINGS_GENERAL' => 'عمومی',
    'LBL_EMAIL_SETTINGS_GROUP_FOLDERS_CREATE' => 'ایجاد گروه پوشه‌ها',

    'LBL_EMAIL_SETTINGS_GROUP_FOLDERS_EDIT' => 'ویرایش گروه پوشه',

    'LBL_EMAIL_SETTINGS_NAME' => 'نام حساب ایمیل',
    'LBL_EMAIL_SETTINGS_REQUIRE_REFRESH' => 'تعداد ایمیل در هر صفحه در صندوق ورودی را انتخاب کنید. ممکن است برای اعمال تغییرات نیاز به بروزرسانی صقحه باشد.',
    'LBL_EMAIL_SETTINGS_RETRIEVING_ACCOUNT' => 'در حال بازیابی حساب ایمیل',
    'LBL_EMAIL_SETTINGS_SAVED' => 'تنظیمات ذخیره شد.',
    'LBL_EMAIL_SETTINGS_SEND_EMAIL_AS' => 'فقط ایمیل با متن ساده ارسال کنید',
    'LBL_EMAIL_SETTINGS_SHOW_NUM_IN_LIST' => 'ایمیل در هر صفحه',
    'LBL_EMAIL_SETTINGS_TITLE_LAYOUT' => 'تنظیمات مربوط به نمایش',
    'LBL_EMAIL_SETTINGS_TITLE_PREFERENCES' => 'تنظیمات دلخواه',
    'LBL_EMAIL_SETTINGS_USER_FOLDERS' => 'پوشه‌های در دسترس کاربر',
    'LBL_EMAIL_ERROR_PREPEND' => 'خطایی در ایمیل رخ داد:',
    'LBL_EMAIL_INVALID_PERSONAL_OUTBOUND' => 'سرور ایمیل خروجی انتخاب شده برای حساب ایمیلی که استفاده می کنید نامعتبر است. تنظیمات را بررسی کنید یا سرور ایمیل دیگری را برای حساب ایمیل انتخاب کنید.',
    'LBL_EMAIL_INVALID_SYSTEM_OUTBOUND' => 'سرور ایمیل خروجی برای ارسال ایمیل پیکربندی نشده است. لطفاً یک سرور ایمیل خروجی را پیکربندی کنید یا یک سرور ایمیل خروجی را برای حساب ایمیلی که در تنظیمات >> حساب ایمیل استفاده می کنید، انتخاب کنید.',
    'LBL_DEFAULT_EMAIL_SIGNATURES' => 'امضای پیش‌فرض',
    'LBL_EMAIL_SIGNATURES' => 'امضاها',
    'LBL_SMTPTYPE_GMAIL' => 'Gmail',
    'LBL_SMTPTYPE_YAHOO' => 'Yahoo! Mail',
    'LBL_SMTPTYPE_EXCHANGE' => 'Microsoft Exchange',
    'LBL_SMTPTYPE_OTHER' => 'دیگر',
    'LBL_EMAIL_SPACER_MAIL_SERVER' => '[ Remote Folders ]',
    'LBL_EMAIL_SPACER_LOCAL_FOLDER' => '[پوشه های SuiteCRM ]',
    'LBL_EMAIL_SUBJECT' => 'موضوع',
    'LBL_EMAIL_SUCCESS' => 'موفق',
    'LBL_EMAIL_SUITE_FOLDER' => 'پوشه SuiteCRM',
    'LBL_EMAIL_TEMPLATE_EDIT_PLAIN_TEXT' => 'متن body قالب ایمیل خالی است',
    'LBL_EMAIL_TEMPLATES' => 'قالب‌ها',
    'LBL_EMAIL_TO' => 'به',
    'LBL_EMAIL_VIEW' => 'مشاهده',
    'LBL_EMAIL_VIEW_HEADERS' => 'نمایش سرصفحه',
    'LBL_EMAIL_VIEW_RAW' => 'نمایش ایمیل‌های خام',
    'LBL_EMAIL_VIEW_UNSUPPORTED' => 'این ویژگی در صورت استفاده با POP3 پشتیبانی نمی شود.',
    'LBL_DEFAULT_LINK_TEXT' => 'متن پیش‌فرض لینک.',
    'LBL_EMAIL_YES' => 'بله',
    'LBL_EMAIL_TEST_OUTBOUND_SETTINGS' => 'ارسال ایمیل آزمایشی',
    'LBL_EMAIL_TEST_OUTBOUND_SETTINGS_SENT' => 'ایمیل آزمایشی ارسال شد',
    'LBL_EMAIL_MESSAGE_NO' => 'شماره پیام',
    'LBL_EMAIL_IMPORT_SUCCESS' => 'درون‌ریزی سپری شد',
    'LBL_EMAIL_IMPORT_FAIL' => 'بارگذاری انجام نشد زیرا پیام قبلاً وارد شده یا از سرور حذف شده است',

    'LBL_LINK_NONE' => 'هیچ‌کدام',
    'LBL_LINK_ALL' => 'همه',
    'LBL_LINK_RECORDS' => 'سوابق',
    'LBL_LINK_SELECT' => 'انتخاب',
    'LBL_LINK_ACTIONS' => 'اقدامات',
    'LBL_CLOSE_ACTIVITY_HEADER' => 'تایید',
    'LBL_CLOSE_ACTIVITY_CONFIRM' => 'آیا می خواهید این #module# را ببندید؟',
    'LBL_INVALID_FILE_EXTENSION' => 'پسوند فایل نامعتبر',

    'ERR_AJAX_LOAD' => 'یک خطا رخ داده است:',
    'ERR_AJAX_LOAD_FAILURE' => 'مشکلی هنگام پردازش درخواست شما وجود دارد. لطفا بعداً مجددا تلاش کنید.',
    'ERR_AJAX_LOAD_FOOTER' => 'اگر این خطا ادامه داشت، لطفاً از سرپرست خود بخواهید Ajax را برای این ماژول غیرفعال کند',
    'ERR_DECIMAL_SEP_EQ_THOUSANDS_SEP' => 'جداکننده اعشاری نمی تواند از همان کاراکتر جداکننده چندین بار استفاده کند.\n\n  لطفا مقادیر را تغییر دهید.',
    'ERR_DELETE_RECORD' => 'برای حذف این مخاطب یک شماره سابقه باید مشخص شود.',
    'ERR_EXPORT_DISABLED' => 'برون‌بری غیر فعال گردید.',
    'ERR_EXPORT_TYPE' => 'خطا هنگام خروجی گرفتن ',
    'ERR_INVALID_EMAIL_ADDRESS' => 'آدرس ایمیل معتبر نیست.',
    'ERR_INVALID_FILE_REFERENCE' => 'مرجع فایل نامعتبر است',
    'ERR_NO_HEADER_ID' => 'این ویژگی در این قالب در دسترس نیست.',
    'ERR_NOT_ADMIN' => 'دسترسی های غیر مجاز به مدیر.',
    'ERR_UNAUTHORIZED_PAGE_ACCESS' => 'شما مجاز به دیدن این صفحه نمیباشید. لطفا با سرپرست سیستم خود تماس بگیرید.',
    'ERR_UNAUTHORIZED_PAGE_ACCESS_TO_HOME_PAGE' => 'شما مجاز به دیدن این صفحه نمیباشید. بازگشت به صفحه اصلی...',
    'ERR_MISSING_REQUIRED_FIELDS' => 'فیلدهای مورد نیاز تکمیل نشده:',
    'ERR_INVALID_REQUIRED_FIELDS' => 'فیلدهای مورد نیاز با مقادیر نامعتبر:',
    'ERR_INVALID_VALUE' => 'مقدار نامعتبر:',
    'ERR_NO_SUCH_FILE' => 'فایل در سیستم وجود ندارد',
    'ERR_NO_SINGLE_QUOTE' => 'نمی توان از علامت نقل قول استفاده کرد ',
    'ERR_NOTHING_SELECTED' => 'لطفا قبل از ادامه انتخاب کنید.',
    'ERR_SELF_REPORTING' => 'کاربر نمی تواند به خودش گزارش دهد.',
    'ERR_SQS_NO_MATCH_FIELD' => 'بدون تطابق زمینه: ',
    'ERR_SQS_NO_MATCH' => 'مطابق نیست',
    'ERR_ADDRESS_KEY_NOT_SPECIFIED' => 'لطفا \'کلید\' شاخص را در ویژگی displayParams برای تعریف متا-دیتا مشخص کنید',
    'ERR_EXISTING_PORTAL_USERNAME' => 'خطا: نام پورتال در حال حاضر به مخاطب دیگری اختصاص یافته است.',
    'ERR_COMPATIBLE_PRECISION_VALUE' => 'مقدار فیلد با مقدار دقیق سازگار نیست',
    'ERR_EXTERNAL_API_SAVE_FAIL' => 'هنگام ذخیره در حساب خارجی خطایی روی داد.',
    'ERR_NO_DB' => 'امکان اتصال به پایگاه داده وجود ندارد. لطفا برای جزئیات بیشتر به سایت suitecrm.log رجوع کنید (0).',
    'ERR_DB_FAIL' => 'خرابی پایگاه داده. لطفاً برای جزئیات به سایت suitecrm.log مراجعه کنید.',
    'ERR_DB_VERSION' => 'SuiteCRM {0} Files May Only Be Used With A SuiteCRM {1} Database.',

    'LBL_ACCOUNT' => 'حساب',
    'LBL_ACCOUNTS' => 'حساب ها',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'فعالیت‌ها',
    'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
    'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'مشاهده خلاصه',
    'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'مشاهده خلاصه',
    'LBL_ADD_BUTTON' => 'ﺍﻓﺰﻭﺩﻥ',
    'LBL_ADD_DOCUMENT' => 'افزودن پرونده',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'افزودن به ليست هدف',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL_ACCOUNTS_CONTACTS' => 'مخاطبین را به لیست اهداف اضافه کنید',
    'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'برای بستن کلیک کنید',
    'LBL_ADDITIONAL_DETAILS' => 'جزئیات بیشتر',
    'LBL_ADMIN' => 'مدیر سیستم',
    'LBL_ALT_HOT_KEY' => '',
    'LBL_ARCHIVE' => 'بایگانی',
    'LBL_ASSIGNED_TO_USER' => 'اختصاص یافته به کاربر',
    'LBL_ASSIGNED_TO' => 'اختصاص داده شده به:',
    'LBL_BACK' => 'بازگشت',
    'LBL_BILLING_ADDRESS' => 'آدرس صورت‌حساب',
    'LBL_QUICK_CREATE' => 'ایجاد ',
    'LBL_BROWSER_TITLE' => 'SuiteCRM - Open Source CRM',
    'LBL_BUGS' => 'اشکالات',
    'LBL_BY' => 'توسط',
    'LBL_CALLS' => 'تماس ها',
    'LBL_CAMPAIGNS_SEND_QUEUED' => 'ارسال ایمیل های کمپین',
    'LBL_SUBMIT_BUTTON_LABEL' => 'ثبت',
    'LBL_CASE' => 'مورد',
    'LBL_CASES' => 'موارد',
    'LBL_CHANGE_PASSWORD' => 'تغییر گذرواژه',
    'LBL_CHARSET' => 'UTF-8',
    'LBL_CHARTS' => 'نمودارها',
    'LBL_QUICK_CHARTS' => 'نمودارها',
    'LBL_QUICK_HISTORY' => 'نوار زمان',
    'LBL_CHECKALL' => 'انتخاب همه',
    'LBL_CITY' => 'شهر',
    'LBL_CLEAR_BUTTON_LABEL' => 'پاکسازی',
    'LBL_CLEAR_BUTTON_TITLE' => 'پاکسازی',
    'LBL_CLEARALL' => 'پاک کردن همه',
    'LBL_CLOSE_BUTTON_TITLE' => 'بستن',
    'LBL_CLOSE_AND_CREATE_BUTTON_LABEL' => 'بستن و ایجاد جدید',
    'LBL_CLOSE_AND_CREATE_BUTTON_TITLE' => 'بستن و ایجاد جدید',
    'LBL_CLOSE_AND_CREATE_BUTTON_KEY' => 'C',
    'LBL_OPEN_ITEMS' => 'Open Items',
    'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
    'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'نوشتن ایمیل',
    'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'نوشتن ایمیل',
    'LBL_SEARCH_DROPDOWN_YES' => 'بله',
    'LBL_SEARCH_DROPDOWN_NO' => 'خير',
    'LBL_CONTACT_LIST' => 'لیست مخاطب‌ها',
    'LBL_CONTACT' => 'مخاطب',
    'LBL_CONTACTS' => 'مخاطب‌ها',
    'LBL_CONTRACT' => 'قرارداد',
    'LBL_CONTRACTS' => 'قراردادها',
    'LBL_COUNTRY' => 'کشور:',
    'LBL_CREATE_BUTTON_LABEL' => 'ایجاد',
    'LBL_CREATED_BY_USER' => 'ایجاد شده توسط کاربر',
    'LBL_CREATED_USER' => 'ایجاد شده توسط کاربر',
    'LBL_CREATED' => 'ایجاد کننده',
    'LBL_CURRENT_USER_FILTER' => 'آیتم‌های من',
    'LBL_CURRENCY' => 'واحد پول:',
    'LBL_DOCUMENTS' => 'اسناد',
    'LBL_DATE_ENTERED' => 'تاریخ ایجاد:',
    'LBL_DATE_MODIFIED' => 'تاریخ ویرایش:',
    'LBL_EDIT_BUTTON' => 'ویرایش',
    'LBL_DUPLICATE_BUTTON' => 'متناظر',
    'LBL_DELETE_BUTTON' => 'حذف',
    'LBL_DELETE' => 'حذف',
    'LBL_DELETED' => 'حذف شده',
    'LBL_DIRECT_REPORTS' => 'گزارش‌های مستقیم',
    'LBL_DONE_BUTTON_LABEL' => 'ﺍﻧﺠﺎﻡ شد',
    'LBL_DONE_BUTTON_TITLE' => 'ﺍﻧﺠﺎﻡ شد',
    'LBL_FAVORITES' => 'علاقمندی‌ها',
    'LBL_VCARD' => 'vCard',
    'LBL_EMPTY_VCARD' => 'لطفا یک فایل vCard انتخاب کنید',
    'LBL_EMPTY_REQUIRED_VCARD' => 'vCard تمام فیلدهای مورد نیاز برای این ماژول را ندارد. برای اطلاعات بیشتر به suitecrm.log مراجعه کنید.',
    'LBL_VCARD_ERROR_FILESIZE' => 'فایل آپلود شده از محدودیت اندازه 30000 بایت که در فرم HTML مشخص شده است بیشتر است.',
    'LBL_VCARD_ERROR_DEFAULT' => 'هنگام بارگذاری فایل کارت مجازی خطایی روی داد. لطفاً برای جزئیات به سایت suitecrm.log مراجعه کنید.',
    'LBL_IMPORT_VCARD' => 'وارد‌سازی vCard:',
    'LBL_IMPORT_VCARD_BUTTON_LABEL' => 'وارد‌سازی vCard',
    'LBL_IMPORT_VCARD_BUTTON_TITLE' => 'وارد‌سازی vCard',
    'LBL_VIEW_BUTTON' => 'نمايش',
    'LBL_EMAIL_PDF_BUTTON_LABEL' => 'ایمیل به عنوان PDF',
    'LBL_EMAIL_PDF_BUTTON_TITLE' => 'ایمیل به عنوان PDF',
    'LBL_EMAILS' => 'ایمیل‌ها',
    'LBL_EMPLOYEES' => 'کارمندها',
    'LBL_ENTER_DATE' => 'تاریخ را وارد کنید',
    'LBL_EXPORT' => 'خروجي گرفتن',
    'LBL_FAVORITES_FILTER' => 'موارد دلخواه',
    'LBL_GO_BUTTON_LABEL' => 'برو',
    'LBL_HIDE' => 'پنهان کن',
    'LBL_HISTORY' => 'سوابق',
    'LBL_NEW' => 'جدید',
    'LBL_ID' => 'شناسه',
    'LBL_IMPORT' => 'واردسازی',
    'LBL_IMPORT_STARTED' => 'وارد‌سازی آغاز شد: ',
    'LBL_LAST_VIEWED' => 'مشاهده‌های اخیر',
    'LBL_LEADS' => 'سرنخ‌ها',
    'LBL_LESS' => 'کمتر',
    'LBL_CAMPAIGN' => 'کمپین:',
    'LBL_CAMPAIGNS' => 'کمپین‌ها',
    'LBL_CAMPAIGNLOG' => 'گزارش وضعیت کمپین',
    'LBL_CAMPAIGN_CONTACT' => 'کمپین‌ها',
    'LBL_CAMPAIGN_ID' => 'campaign_id',
    'LBL_CAMPAIGN_NONE' => 'هیچ‌کدام',
    'LBL_THEME' => 'قالب:',
    'LBL_FOUND_IN_RELEASE' => 'یافت شده در انتشار یافته ها',
    'LBL_FIXED_IN_RELEASE' => 'رفع شده در انتشار',
    'LBL_IN_EVERYWHERE' => 'همه جا',
    'LBL_LIST_ACCOUNT_NAME' => 'نام حساب',
    'LBL_LIST_ASSIGNED_USER' => 'کاربر',
    'LBL_LIST_CONTACT_NAME' => 'نام مخاطب',
    'LBL_LIST_CONTACT_ROLE' => 'نقش مخاطب',
    'LBL_LIST_DATE_ENTERED' => 'تاریخ ایجاد',
    'LBL_LIST_EMAIL' => 'ایمیل',
    'LBL_LIST_NAME' => 'نام',
    'LBL_LIST_OF' => 'از',
    'LBL_LIST_PHONE' => 'تلفن',
    'LBL_LIST_RELATED_TO' => 'مربوط به',
    'LBL_LIST_USER_NAME' => 'نام کاربر',
    'LBL_LISTVIEW_NO_SELECTED' => 'لطفا برای ادامه ی عملیات حداقل 1 ردیف را انتخاب کنید.',
    'LBL_LISTVIEW_TWO_REQUIRED' => 'لطفا برای ادامه ی عملیات حداقل 2 ردیف را انتخاب کنید.',
    'LBL_LISTVIEW_OPTION_SELECTED' => 'سوابق انتخاب شده',
    'LBL_LISTVIEW_SELECTED_OBJECTS' => 'انتخاب شده: ',

    'LBL_LOCALE_NAME_EXAMPLE_FIRST' => 'سیاوش',
    'LBL_LOCALE_NAME_EXAMPLE_LAST' => 'Livingstone',
    'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'دکتر',
    'LBL_LOCALE_NAME_EXAMPLE_TITLE' => 'Code Monkey Extraordinaire',
    'LBL_CANCEL' => 'لغو',
    'LBL_SNOOZE' => 'هشدار',
    'LBL_SNOOZE_INLINE_CONFIRM' => 'هشدار? ({{preferences.snooze_alert_timer|enum:snooze_alert_timer_simple}})',
    'LBL_DISMISS' => 'Dismiss',
    'LBL_DISMISS_INLINE_CONFIRM' => 'رد کردن؟',
    'LBL_DISMISS_ALL_INLINE_CONFIRM' => 'رد کردن همه؟',
    'NTC_DISMISS_CONFIRMATION' => 'آیا مطمئنید که می‌خواهید این هشدار را رد کنید؟',
    'NTC_DISMISS_ALL_CONFIRMATION' => 'آیا مطمئنید که می‌خواهید همه هشدارها را رد کنید؟',
    'LBL_ALERT_DISMISS_SUCCESS' => 'هشدار با موفقیت رد شد',
    'LBL_ALERT_DISMISS_ERROR' => 'خطا هنگام تلاش برای رد هشدار',
    'LBL_ALERT_DISMISS_ALL_SUCCESS' => 'هشدارها با موفقیت رد شدند',
    'LBL_DISMISS_ALL' => 'رد کردن همه',
    'LBL_VERIFY' => 'تایید',
    'LBL_RESEND' => 'ارسال مجدد',
    'LBL_RECORD_DOES_NOT_EXIST' => 'خطا در بازیابی رکورد. این رکورد ممکن است حذف شود یا شما مجاز به مشاهده آن نباشید.',
    'LBL_PROFILE' => 'پروفایل',
    'LBL_PROFILE_EDIT' => 'ویرایش پروفایل',
    'LBL_MAILMERGE' => 'ادغام ایمیل',
    'LBL_MASS_UPDATE' => 'به‌روز‌رسانی جمعی',
    'LBL_NO_MASS_UPDATE_FIELDS_AVAILABLE' => 'هیچ فیلدی برای عملیات به‌روز‌رسانی جمعی در دسترس نیست',
    'LBL_OPT_OUT_FLAG_PRIMARY' => 'انصراف از ایمیل اصلی',
    'LBL_OPT_IN_FLAG_PRIMARY' => 'ایمیل اصلی را انتخاب کنید',
    'LBL_MEETINGS' => 'جلسات',
    'LBL_MEETING_GO_BACK' => 'بازگشت به جلسه',
    'LBL_MEMBERS' => 'اعضای',
    'LBL_MEMBER_OF' => 'عضوی از',
    'LBL_MODIFIED_BY_USER' => 'کاربر ویرایش کننده',
    'LBL_MODIFIED_USER' => 'کاربر ویرایش کننده',
    'LBL_MODIFIED' => 'ویرایش کننده',
    'LBL_MODIFIED_NAME' => 'نام ویرایش کننده',
    'LBL_MORE' => 'بيشتر',
    'LBL_MY_ACCOUNT' => 'تنظیمات من',
    'LBL_NAME' => 'نام',
    'LBL_NEW_BUTTON_KEY' => 'شمال',
    'LBL_NEW_BUTTON_LABEL' => 'ایجاد',
    'LBL_NEW_BUTTON_TITLE' => 'ایجاد',
    'LBL_EDIT' => 'ویرایش',
    'LBL_NEXT_BUTTON_LABEL' => 'بعدی',
    'LBL_NONE' => '--هیچ--',
    'LBL_NOTES' => 'یادداشت‌ها',
    'LBL_OPPORTUNITIES' => 'فرصت ها',
    'LBL_OPPORTUNITY_NAME' => 'نام فرصت',
    'LBL_OPPORTUNITY' => 'فرصت',
    'LBL_OR' => 'یا',
    'LBL_PANEL_OVERVIEW' => 'خلاصه',
    'LBL_PANEL_ASSIGNMENT' => 'دیگر',
    'LBL_PANEL_ADVANCED' => 'اطلاعات بیشتر',
    'LBL_PARENT_TYPE' => 'نوع والد',
    'LBL_PERCENTAGE_SYMBOL' => '%',
    'LBL_POSTAL_CODE' => 'کد پستی:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'شهر آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'کشور آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'کد پستی آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_STATE' => 'استان آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_STREET_2' => 'ادامه آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_STREET_3' => 'ادامه آدرس اولیه:',
    'LBL_PRIMARY_ADDRESS_STREET' => 'آدرس خیابان اصلی:',
    'LBL_PRIMARY_ADDRESS' => 'آدرس اصلی:',

    'LBL_PROSPECTS' => 'چشم انداز',
    'LBL_PRODUCTS' => 'محصولات',
    'LBL_PROJECT_TASKS' => 'وظایف پروژه',
    'LBL_PROJECTS' => 'پروژه ها',
    'LBL_QUOTES' => 'پیش‌فاکتورها',

    'LBL_RELATED' => 'مربوط',
    'LBL_RELATED_RECORDS' => 'سوابق مرتبط',
    'LBL_REMOVE' => 'حذف',
    'LBL_REPORTS_TO' => 'گزارش به',
    'LBL_REQUIRED_SYMBOL' => '*',
    'LBL_REQUIRED_TITLE' => 'فیلد های مورد نیاز را نشان می دهد',
    'LBL_EMAIL_DONE_BUTTON_LABEL' => 'ﺍﻧﺠﺎﻡ شد',
    'LBL_FULL_FORM_BUTTON_KEY' => 'L',
    'LBL_FULL_FORM_BUTTON_LABEL' => 'فرم کامل',
    'LBL_FULL_FORM_BUTTON_TITLE' => 'فرم کامل',
    'LBL_SAVE_NEW_BUTTON_LABEL' => 'ذخیره و ایجاد جدید',
    'LBL_SAVE_NEW_BUTTON_TITLE' => 'ذخیره و ایجاد جدید',
    'LBL_SAVE_OBJECT' => 'ذخیره {0}',
    'LBL_SEARCH_BUTTON_KEY' => 'Q',
    'LBL_SEARCH_BUTTON_LABEL' => 'جستجو',
    'LBL_SEARCH_BUTTON_TITLE' => 'جستجو',
    'LBL_FILTER' => 'فیلتر',
    'LBL_CLEAR_FILTER' => 'Clear Filter',
    'LBL_SEARCH' => 'جستجو',
    'LBL_SEARCH_ALT' => '',
    'LBL_SEARCH_MORE' => 'بیشتر',
    'LBL_UPLOAD_IMAGE_FILE_INVALID' => 'فرمت فایل معتبر نیست، تنها فایل های از نوع عکس می توانند بارگذاری شوند.',
    'LBL_SELECT_BUTTON_KEY' => 'T',
    'LBL_SELECT_BUTTON_LABEL' => 'انتخاب',
    'LBL_SELECT_BUTTON_TITLE' => 'انتخاب',
    'LBL_BROWSE_DOCUMENTS_BUTTON_LABEL' => 'مرور اسناد',
    'LBL_BROWSE_DOCUMENTS_BUTTON_TITLE' => 'مرور اسناد',
    'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
    'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'انتخاب مخاطب',
    'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'انتخاب مخاطب',
    'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'از میان گزارش ها انتخاب کنید',
    'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'گزارش ها را انتخاب کنید.',
    'LBL_SELECT_USER_BUTTON_KEY' => 'U',
    'LBL_SELECT_USER_BUTTON_LABEL' => 'انتخاب کاربر',
    'LBL_SELECT_USER_BUTTON_TITLE' => 'انتخاب کاربر',
    // Clear buttons take up too many keys, lets default the relate and collection ones to be empty
    'LBL_ACCESSKEY_CLEAR_RELATE_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_RELATE_TITLE' => 'لغو انتخاب شده‌ها',
    'LBL_ACCESSKEY_CLEAR_RELATE_LABEL' => 'لغو انتخاب شده‌ها',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_TITLE' => 'لغو انتخاب شده‌ها',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_LABEL' => 'لغو انتخاب شده‌ها',
    'LBL_ACCESSKEY_SELECT_FILE_KEY' => 'F',
    'LBL_ACCESSKEY_SELECT_FILE_TITLE' => 'فایل را انتخاب کنید',
    'LBL_ACCESSKEY_SELECT_FILE_LABEL' => 'فایل را انتخاب کنید',
    'LBL_ACCESSKEY_CLEAR_FILE_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_FILE_TITLE' => 'پاک کردن فایل',
    'LBL_ACCESSKEY_CLEAR_FILE_LABEL' => 'پاک کردن فایل',

    'LBL_ACCESSKEY_SELECT_USERS_KEY' => 'U',
    'LBL_ACCESSKEY_SELECT_USERS_TITLE' => 'انتخاب کاربر',
    'LBL_ACCESSKEY_SELECT_USERS_LABEL' => 'انتخاب کاربر',
    'LBL_ACCESSKEY_CLEAR_USERS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_USERS_TITLE' => 'پاک کردن کاربر ',
    'LBL_ACCESSKEY_CLEAR_USERS_LABEL' => 'پاک کردن کاربر',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_KEY' => 'A',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_TITLE' => 'انتخاب مرکز',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_LABEL' => 'انتخاب مرکز',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_TITLE' => 'پاک کردن اکانت',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_LABEL' => 'پاک کردن اکانت',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_KEY' => 'M',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_TITLE' => 'انتخاب کمپین',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_LABEL' => 'انتخاب کمپین',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_TITLE' => 'پاک کردن کمپین',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_LABEL' => 'پاک کردن کمپین',
    'LBL_ACCESSKEY_SELECT_CONTACTS_KEY' => 'C',
    'LBL_ACCESSKEY_SELECT_CONTACTS_TITLE' => 'انتخاب مخاطب',
    'LBL_ACCESSKEY_SELECT_CONTACTS_LABEL' => 'انتخاب مخاطب',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_TITLE' => 'پاک کردن مخاطبین',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_LABEL' => 'پاک کردن مخاطبین',
    'LBL_ACCESSKEY_SELECT_TEAMSET_KEY' => 'Z',
    'LBL_ACCESSKEY_SELECT_TEAMSET_TITLE' => 'انتخاب تیم',
    'LBL_ACCESSKEY_SELECT_TEAMSET_LABEL' => 'انتخاب تیم',
    'LBL_ACCESSKEY_CLEAR_TEAMS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_TEAMS_TITLE' => 'پاک کردن تیم',
    'LBL_ACCESSKEY_CLEAR_TEAMS_LABEL' => 'پاک کردن تیم',
    'LBL_SERVER_RESPONSE_RESOURCES' => 'منابع مورد استفاده برای ساخت این صفحه (کوئری ها ، فایل ها)',
    'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'ثانیه.',
    'LBL_SERVER_RESPONSE_TIME' => 'زمان پاسخ سرور:',
    'LBL_SERVER_MEMORY_BYTES' => 'بایت',
    'LBL_SERVER_MEMORY_USAGE' => 'استفاده از حافظه سرور: {0} ({1})',
    'LBL_SERVER_MEMORY_LOG_MESSAGE' => 'کاربرد:-ماژول: {0} - عمل: {1}',
    'LBL_SERVER_PEAK_MEMORY_USAGE' => 'Server Peak Memory Usage: {0} ({1})',
    'LBL_SHIPPING_ADDRESS' => 'آدرس ارسال کالا',
    'LBL_SHOW' => 'نمایش',
    'LBL_STATE' => 'وضعیت:',
    'LBL_STATUS_UPDATED' => 'وضعیت شما برای این رویداد به روز شده است!',
    'LBL_STATUS' => 'وضعیت',
    'LBL_STREET' => 'خیابان',
    'LBL_SUBJECT' => 'موضوع',

    'LBL_INBOUNDEMAIL_ID' => 'شناسه کاربری ایمیل‌های ورودی',

    'LBL_SCENARIO_SALES' => 'فروش',
    'LBL_SCENARIO_MARKETING' => 'بازاریابی',
    'LBL_SCENARIO_FINANCE' => 'امور مالی',
    'LBL_SCENARIO_SERVICE' => 'خدمات',
    'LBL_SCENARIO_PROJECT' => 'مدیریت پروژه',

    'LBL_SCENARIO_SALES_DESCRIPTION' => 'این سناریو مدیریت موارد فروش را تسهیل می کند',
    'LBL_SCENARIO_MAKETING_DESCRIPTION' => 'این سناریو مدیریت موارد بازاریابی را تسهیل می کند',
    'LBL_SCENARIO_FINANCE_DESCRIPTION' => 'این سناریو مدیریت موارد مربوط به امور مالی را تسهیل می کند',
    'LBL_SCENARIO_SERVICE_DESCRIPTION' => 'این سناریو مدیریت موارد مرتبط با خدمات را تسهیل می کند',
    'LBL_SCENARIO_PROJECT_DESCRIPTION' => 'این سناریو مدیریت موارد مرتبط با پروژه را تسهیل می کند',

    'LBL_SYNC' => 'همگام‌سازی',
    'LBL_TABGROUP_ALL' => 'همه',
    'LBL_TABGROUP_ACTIVITIES' => 'فعالیت‌ها',
    'LBL_TABGROUP_COLLABORATION' => 'همکاری',
    'LBL_TABGROUP_MARKETING' => 'بازاریابی',
    'LBL_TABGROUP_OTHER' => 'دیگر',
    'LBL_TABGROUP_SALES' => 'فروش',
    'LBL_TABGROUP_SUPPORT' => 'پشتیبانی',
    'LBL_TASKS' => 'وظایف',
    'LBL_THOUSANDS_SYMBOL' => 'K',
    'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'آرشیو ایمیل',
    'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'آرشیو ایمیل',
    'LBL_UNDELETE_BUTTON_LABEL' => 'بازگردانی',
    'LBL_UNDELETE_BUTTON_TITLE' => 'بازگردانی',
    'LBL_UNDELETE_BUTTON' => 'بازگردانی',
    'LBL_UNDELETE' => 'بازگردانی',
    'LBL_UNSYNC' => 'نا همگام',
    'LBL_UPDATE' => 'بروز رسانی',
    'LBL_USER_LIST' => 'لیست کاربران',
    'LBL_USERS' => 'کاربران',
    'LBL_VERIFY_EMAIL_ADDRESS' => 'در حال بررسی ایمیل ورودی...',
    'LBL_VERIFY_PORTAL_NAME' => 'در حال بررسی نام پورتال...',
    'LBL_VIEW_IMAGE' => 'مشاهده',

    'LNK_ABOUT' => 'درباره',
    'LNK_ADVANCED_FILTER' => 'فیلتر پیشرفته',
    'LNK_BASIC_FILTER' => 'فیلتر سریع',
    'LBL_ADVANCED_SEARCH' => 'فیلتر پیشرفته',
    'LBL_QUICK_FILTER' => 'فیلتر سریع',
    'LBL_BASIC_FILTER' => 'فیلتر پایه',
    'LBL_QUICK' => 'سریع',
    'LNK_SEARCH_NONFTS_VIEW_ALL' => 'نمایش همه',
    'LNK_CLOSE' => 'بستن',
    'LBL_MODIFY_CURRENT_FILTER' => 'فیلتر فعلی را اصلاح کنید',
    'LNK_SAVED_VIEWS' => 'تنظیمات چیدمان',
    'LNK_DELETE' => 'حذف',
    'LNK_EDIT' => 'ویرایش',
    'LNK_GET_LATEST' => 'مشاهده آخرین',
    'LNK_GET_LATEST_TOOLTIP' => 'جایگزینی با آخرین نسخه',
    'LNK_HELP' => 'کمک',
    'LNK_CREATE' => 'ایجاد',
    'LNK_LIST_END' => 'پايان',
    'LNK_LIST_NEXT' => 'بعدی',
    'LNK_LIST_PREVIOUS' => 'قبلی',
    'LNK_LIST_RETURN' => 'بازگشت به فهرست',
    'LNK_LIST_START' => 'شروع',
    'LNK_LOAD_SIGNED' => 'امضا',
    'LNK_LOAD_SIGNED_TOOLTIP' => 'جایگزینی بجای سند امضا شده',
    'LNK_PRINT' => 'چاپ',
    'LNK_BACKTOTOP' => 'بازگشت به بالا',
    'LNK_REMOVE' => 'حذف',
    'LNK_RESUME' => 'ادامه',
    'LNK_VIEW_CHANGE_LOG' => 'نمایش تغییرات',
    'LBL_CHANGE_LOG' => 'سوابق تغییرات',

    'NTC_CLICK_BACK' => 'لطفاً روی دکمه بازگشت مرورگر کلیک کنید و خطا را برطرف کنید.',
    'NTC_DATE_FORMAT' => '(سال-ماه-روز)',
    'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'آیا مطمئن هستید که می خواهید رکورد یا رکوردهای انتخابی را حذف کنید؟',
    'NTC_SNOOZE_CONFIRMATION' => 'آیا مطمئن هستید که هشدار را به تعویق بیانداید؟',
    'NTC_TEMPLATE_IS_USED' => 'این قالب حداقل در یک رکورد بازاریابی ایمیلی استفاده می شود. آیا مطمئن هستید که می خواهید آن را حذف کنید؟',
    'NTC_TEMPLATES_IS_USED' => 'از قالب های زیر در سوابق ایمیل مارکتینگ استفاده می شود. آیا مطمئن هستید که می خواهید آنها را حذف کنید؟' . PHP_EOL,
    'NTC_DELETE_CONFIRMATION' => 'آیا مطمئنید که می خواهید این رکورد را حذف کنید؟',
    'NTC_DELETE_CONFIRMATION_NUM' => 'آیا از حذف مطمئن هستید؟ ',
    'NTC_UPDATE_CONFIRMATION_NUM' => 'آیا میخواهید به روز رسانی کنید؟ ',
    'NTC_DELETE_SELECTED_RECORDS' => ' رکورد (های) انتخاب شده؟',
    'NTC_LOGIN_MESSAGE' => 'لطفا نام کاربری و رمز عبور خود را وارد کنید.',
    'NTC_NO_ITEMS_DISPLAY' => 'هیچ‌کدام',
    'NTC_REMOVE_CONFIRMATION' => 'آیا مطمئنید که می خواهید این رابطه را حذف کنید؟ فقط رابطه حذف خواهد شد. رکورد حذف نخواهد شد.',
    'NTC_REQUIRED' => 'فیلد مورد نیاز را نشان می دهد',
    'NTC_TIME_FORMAT' => '(24:00)',
    'NTC_WELCOME' => 'خوش آمدید',
    'NTC_YEAR_FORMAT' => '(yyyy)',
    'WARN_UNSAVED_CHANGES' => 'شما در شرف خروج از این رکورد هستید بدون اینکه تغییراتی که ممکن است در رکورد ایجاد کرده باشید ذخیره کنید. آیا مطمئنید که می خواهید از این رکورد فاصله بگیرید؟',
    'ERROR_NO_RECORD' => 'خطا در بازیابی رکورد. این رکورد ممکن است حذف شده باشد و یا شما مجاز به مشاهده آن نباشید',
    'WARN_BROWSER_VERSION_WARNING' => '<b>هشدار:</b> نسخه مرورگر شما دیگر پشتیبانی نمی شود یا از مرورگر پشتیبانی نشده استفاده می کنید.<p></p>نسخه های مرورگر زیر توصیه می شود:<p></p><ul><li>Internet Explorer 10 (compatibility view not supported)<li>Firefox 32.0<li>Safari 5.1<li>Chrome 37</ul>',
    'WARN_BROWSER_IE_COMPATIBILITY_MODE_WARNING' => '<b>هشدار:</b> مرورگر شما در نمای سازگاری IE است که پشتیبانی نمی شود.',
    'ERROR_TYPE_NOT_VALID' => 'خطا. این نوع معتبر نیست.',
    'ERROR_NO_BEAN' => 'Failed to get bean.',
    'LBL_DUP_MERGE' => 'یافتن موارد تکراری',
    'LBL_MANAGE_SUBSCRIPTIONS' => 'مدیریت اشتراک‌ها',
    'LBL_MANAGE_SUBSCRIPTIONS_FOR' => 'مدیریت اشتراک برای ',
    // Ajax status strings
    'LBL_LOADING' => 'در حال بارگذاری...',
    'LBL_SEARCHING' => 'در حال جستجو...',
    'LBL_SAVING_LAYOUT' => 'ذخیره سازی طرح ...',
    'LBL_SAVED_LAYOUT' => 'طرح ذخیره شد.',
    'LBL_SAVED' => 'ذخیره شده',
    'LBL_SAVING' => 'درحال ذخیره',
    'LBL_DISPLAY_COLUMNS' => 'نمایش ستون ها',
    'LBL_HIDE_COLUMNS' => 'مخفی کردن ستون ها',
    'LBL_COLUMNS' => 'ستون‌ها',
    'LBL_SEARCH_CRITERIA' => 'ضوابط جستجو',
    'LBL_SAVED_VIEWS' => 'نماهای ذخیره شده',
    'LBL_PROCESSING_REQUEST' => 'در حال پردازش...',
    'LBL_REQUEST_PROCESSED' => 'ﺍﻧﺠﺎﻡ شد',
    'LBL_AJAX_FAILURE' => 'شکست در آژاکس',
    'LBL_MERGE_DUPLICATES' => 'ادغام',
    'LBL_SAVED_FILTER_SHORTCUT' => 'فیلتر های من',
    'LBL_SEARCH_POPULATE_ONLY' => 'با استفاده از فرم جستجوی بالا جستجو را انجام دهید',
    'LBL_DETAILVIEW' => 'مشاهده جزئیات',
    'LBL_LISTVIEW' => 'نمای لیستی',
    'LBL_EDITVIEW' => 'نمای ویرایش',
    'LBL_BILLING_STREET' => 'خیابان:',
    'LBL_SHIPPING_STREET' => 'خیابان:',
    'LBL_SEARCHFORM' => 'فرم جستجو',
    'LBL_SAVED_SEARCH_ERROR' => 'لطفا یک نام برای این نما بنویسید.',
    'LBL_DISPLAY_LOG' => 'نمایش گزارش ',
    'ERROR_JS_ALERT_SYSTEM_CLASS' => 'سیستم',
    'ERROR_JS_ALERT_TIMEOUT_TITLE' => 'Session Timeout',
    'ERROR_JS_ALERT_TIMEOUT_MSG_1' => 'جلسه شما تا 2 دقیقه دیگر به پایان می رسد. لطفا کار خود را ذخیره کنید.',
    'ERROR_JS_ALERT_TIMEOUT_MSG_2' => 'جلسه شما را به اتمام رسیده است.',
    'MSG_JS_ALERT_MTG_REMINDER_AGENDA' => "\nAgenda: ",
    'MSG_JS_ALERT_MTG_REMINDER_MEETING' => 'جلسه',
    'MSG_JS_ALERT_MTG_REMINDER_CALL' => 'تماس',
    'MSG_JS_ALERT_MTG_REMINDER_TIME' => 'زمان: ',
    'MSG_JS_ALERT_MTG_REMINDER_LOC' => 'مکان: ',
    'MSG_JS_ALERT_MTG_REMINDER_DESC' => 'توضیحات: ',
    'MSG_JS_ALERT_MTG_REMINDER_STATUS' => 'وضعیت',
    'MSG_JS_ALERT_MTG_REMINDER_RELATED_TO' => 'مربوط به: ',
    'MSG_JS_ALERT_MTG_REMINDER_CALL_MSG' => "\nبرای مشاهده تماس روی تأیید و برای رد کردن تماس روی لغو کلیک کنید.",
    'MSG_JS_ALERT_MTG_REMINDER_MEETING_MSG' => "\nبرای مشاهده این جلسه روی تأیید و برای رد کردن روی لغو کلیک کنید.",
    'MSG_JS_ALERT_MTG_REMINDER_NO_EVENT_NAME' => 'رویداد',
    'MSG_JS_ALERT_MTG_REMINDER_NO_DESCRIPTION' => 'رویداد تنظیم نیست.',
    'MSG_JS_ALERT_MTG_REMINDER_NO_LOCATION' => 'قادر به تعیین مکان نیست.',
    'MSG_JS_ALERT_MTG_REMINDER_NO_START_DATE' => 'تاریخ شروع تعریف شده/نشده است.',
    'MSG_LIST_VIEW_NO_RESULTS_BASIC' => 'نتیجه ای یافت نشد.',
    'MSG_LIST_VIEW_NO_RESULTS_CHANGE_CRITERIA' => 'نتیجه ای یافت نشد... معیارهای جستجوی خود را تغییر دهید و دوباره امتحان کنید؟',
    'MSG_LIST_VIEW_NO_RESULTS' => 'نتیجه ای یافت نشد برای <item1>',
    'MSG_LIST_VIEW_NO_RESULTS_SUBMSG' => 'Create <item1> as a new <item2>',
    'MSG_LIST_VIEW_CHANGE_SEARCH' => 'یا معیارهای جستجوی خود را تغییر دهید',
    'MSG_EMPTY_LIST_VIEW_NO_RESULTS' => 'شما در حال حاضر هیچ رکورد ذخیره شده ای ندارید. <item2> or <item3> one now.',

    // contextMenu strings
    'LBL_ADD_TO_FAVORITES' => 'افزودن به مورد علاقه های شما',
    'LBL_CREATE_CONTACT' => 'ایجاد مخاطب',
    'LBL_CREATE_CASE' => 'ایجاد خدمات',
    'LBL_CREATE_NOTE' => 'ایجاد یادداشت',
    'LBL_CREATE_OPPORTUNITY' => 'ایجاد فرصت',
    'LBL_SCHEDULE_CALL' => 'ثبت تماس',
    'LBL_SCHEDULE_MEETING' => 'ثبت قرار ملاقات یا جلسه',
    'LBL_CREATE_TASK' => 'ساخت وظیفه',
    //web to lead
    'LBL_GENERATE_WEB_TO_LEAD_FORM' => 'تولید فرم',
    'LBL_SAVE_WEB_TO_LEAD_FORM' => 'ذخیره فرم وب',
    'LBL_AVAILABLE_FIELDS' => 'فیلدهای در دسترس',
    'LBL_FIRST_FORM_COLUMN' => 'ستون فرم اول',
    'LBL_SECOND_FORM_COLUMN' => 'ستون فرم دوم',
    'LBL_ASSIGNED_TO_REQUIRED' => 'فیلد الزامی وجود ندارد: اختصاص داده شده است',
    'LBL_RELATED_CAMPAIGN_REQUIRED' => 'فیلد الزامی وجود ندارد: کمپین مرتبط',
    'LBL_TYPE_OF_PERSON_FOR_FORM' => 'فرم وب برای ایجاد ',
    'LBL_TYPE_OF_PERSON_FOR_FORM_DESC' => 'با ارسال این فرم ایجاد خواهد شد ',

    'LBL_ADD_ALL_LEAD_FIELDS' => 'اضافه کردن همه فیلد ها',
    'LBL_RESET_ALL_LEAD_FIELDS' => 'بازنشانی همه فیلدها',
    'LBL_REMOVE_ALL_LEAD_FIELDS' => 'حذف همه فیلدها',
    'LBL_NEXT_BTN' => 'بعدی',
    'LBL_ONLY_IMAGE_ATTACHMENT' => 'فقط تصاویر با پسوندهای زیر را می توان جاسازی کرد: JPG، PNG.',
    'LBL_TRAINING' => 'انجمن',
    'ERR_MSSQL_DB_CONTEXT' => 'تغییر زمینه پایگاه داده به',
    'ERR_MSSQL_WARNING' => 'هشدار:',

    //Meta-Data framework
    'ERR_CANNOT_CREATE_METADATA_FILE' => 'خطا: فایل [[file]] وجود ندارد. ایجاد نشد زیرا فایل HTML مربوطه یافت نشد.',
    'ERR_CANNOT_FIND_MODULE' => 'خطا: ماژول [module] وجود ندارد.',
    'LBL_ALT_ADDRESS' => 'آدرس های دیگر:',
    'ERR_SMARTY_UNEQUAL_RELATED_FIELD_PARAMETERS' => 'خطا: تعداد نامساوی آرگومان برای این وجود دارد \'key\' and \'copy\' عناصر موجود در displayParams آرایه.',

    /* MySugar Framework (for Home and Dashboard) */
    'LBL_DASHLET_CONFIGURE_GENERAL' => 'عمومی',
    'LBL_DASHLET_CONFIGURE_FILTERS' => 'فیلترها',
    'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'فقط موارد من',
    'LBL_DASHLET_CONFIGURE_TITLE' => 'عنوان',
    'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'نمایش سطور',

    // MySugar status strings
    'LBL_MAX_DASHLETS_REACHED' => 'شما به حداکثر تعداد Dashlet های SuiteCRM که سرپرست شما تنظیم کرده است رسیده اید. لطفاً یک Dashlet SuiteCRM را برای افزودن موارد بیشتر حذف کنید.',
    'LBL_ADDING_DASHLET' => 'افزودن SuiteCRM Dashlet...',
    'LBL_ADDED_DASHLET' => 'SuiteCRM Dashlet اضافه شد',
    'LBL_REMOVE_DASHLET_CONFIRM' => 'آیا مطمئن هستید که می خواهید این Dashlet SuiteCRM را حذف کنید؟',
    'LBL_REMOVING_DASHLET' => ' در حال حذف SuiteCRMDashlet...',
    'LBL_REMOVED_DASHLET' => 'SuiteCRM Dashlet حذف شد',

    // MySugar Menu Options

    'LBL_LOADING_PAGE' => 'Loading page, please wait...',

    'LBL_RELOAD_PAGE' => 'لطفا <a href="javascript: window.location.reload()"> مجدد پنجره</a> برای استفاده از این SuiteCRM Dashlet.',
    'LBL_ADD_DASHLETS' => 'افزودن دشلت',
    'LBL_CLOSE_DASHLETS' => 'بستن',
    'LBL_OPTIONS' => 'گزینه ها',
    'LBL_1_COLUMN' => '1 ستون',
    'LBL_2_COLUMN' => '2 ستون',
    'LBL_3_COLUMN' => '3 ستون',
    'LBL_PAGE_NAME' => 'نام برگه',

    'LBL_SEARCH_RESULTS' => 'نتایج جستجو',
    'LBL_SEARCH_MODULES' => 'ماژولها',
    'LBL_SEARCH_TOOLS' => 'ابزار',
    'LBL_SEARCH_HELP_TITLE' => 'نکات جستجو',
    /* End MySugar Framework strings */

    'LBL_NO_IMAGE' => 'هیچ تصویری موجود نیست.',

    'LBL_MODULE' => 'ماژول',

    //adding a label for address copy from left
    'LBL_COPY_ADDRESS_FROM_LEFT' => 'آدرس را از سمت چپ کپی کنید:',
    'LBL_SAVE_AND_CONTINUE' => 'ذخیره و ادامه',

    'LBL_SEARCH_HELP_TEXT' => '<p><br /><strong>Multiselect controls</strong></p><ul><li>Click on the values to select an attribute.</li><li>Ctrl-click&nbsp;to&nbsp;select multiple. Mac users use CMD-click.</li><li>To select all values between two attributes,&nbsp; click first value&nbsp;and then shift-click last value.</li></ul><p><strong>Advanced Search & Layout Options</strong><br><br>Using the <b>Saved Search & Layout</b> option, you can save a set of search parameters and/or a custom List View layout in order to quickly obtain the desired search results in the future. You can save an unlimited number of custom searches and layouts. All saved searches appear by name in the Saved Searches list, with the last loaded saved search appearing at the top of the list.<br><br>To customize the List View layout, use the Hide Columns and Display Columns boxes to select which fields to display in the search results. For example, you can view or hide details such as the record name, and assigned user, and assigned team in the search results. To add a column to List View, select the field from the Hide Columns list and use the left arrow to move it to the Display Columns list. To remove a column from List View, select it from the Display Columns list and use the right arrow to move it to the Hide Columns list.<br><br>If you save layout settings, you will be able to load them at any time to view the search results in the custom layout.<br><br>To save and update a search and/or layout:<ol><li>Enter a name for the search results in the <b>Save this search as</b> field and click <b>Save</b>.The name now displays in the Saved Searches list adjacent to the <b>Clear</b> button.</li><li>To view a saved search, select it from the Saved Searches list. The search results are displayed in the List View.</li><li>To update the properties of a saved search, select the saved search from the list, enter the new search criteria and/or layout options in the Advanced Search area, and click <b>Update</b> next to <b>Modify Current Search</b>.</li><li>To delete a saved search, select it in the Saved Searches list, click <b>Delete</b> next to <b>Modify Current Search</b>, and then click <b>OK</b> to confirm the deletion.</li></ol><p><strong>Tips</strong><br><br>By using the % as a wildcard operator you can make your search more broad. For example instead of just searching for results that equal "Apples" you could change your search to "Apples%" which would match all results that start with the word Apples but could contain other characters as well.</p>',

    //resource management
    'ERR_QUERY_LIMIT' => 'Error: محدودیت درخواست $limit برای ماژول $module رسیده است.',
    'ERROR_NOTIFY_OVERRIDE' => 'Error: ResourceObserver->notify() باید نادیده گرفته شود.',

    //tracker labels
    'ERR_MONITOR_FILE_MISSING' => 'خطا: ایجاد مانیتور ممکن نیست زیرا فایل متادیتا خالی است یا وجود ندارد.',
    'ERR_MONITOR_NOT_CONFIGURED' => 'خطا: هیچ مانیتوری برای نام درخواستی پیکربندی نشده است',
    'ERR_UNDEFINED_METRIC' => 'خطا: تنظیم مقدار برای متریک تعریف نشده ممکن نیست',
    'ERR_STORE_FILE_MISSING' => 'خطا: فایل پیاده سازی Store پیدا نشد',

    'LBL_MONITOR_ID' => 'شناسه نظارت',
    'LBL_USER_ID' => 'شناسه کاربری',
    'LBL_MODULE_NAME' => 'نام ماژول',
    'LBL_ITEM_ID' => 'شناسه آیتم',
    'LBL_ITEM_SUMMARY' => 'خلاصه آیتم',
    'LBL_ACTION' => 'عملکرد',
    'LBL_SESSION_ID' => 'شناسه جلسه',
    'LBL_BREADCRUMBSTACK_CREATED' => 'BreadCrumbStack برای شناسه کاربر ایجاد شده است {0}',
    'LBL_VISIBLE' => 'رکورد قابل مشاهده',
    'LBL_DATE_LAST_ACTION' => 'تاریخ آخرین عملکرد',

    //jc:#12287 - For javascript validation messages
    'MSG_IS_NOT_BEFORE' => 'نیست قبل از',
    'MSG_IS_MORE_THAN' => 'بیشتر است از',
    'MSG_SHOULD_BE' => 'باید',
    'MSG_OR_GREATER' => 'یا بیشتر',

    'LBL_LIST' => 'لیست',
    'LBL_CREATE_BUG' => 'ایجاد اشکال',

    'LBL_OBJECT_IMAGE' => 'تصویر شی',
    //jchi #12300
    'LBL_MASSUPDATE_DATE' => 'انتخاب تاریخ',

    'LBL_VALIDATE_RANGE' => 'در محدوده مجاز نیست',
    'LBL_CHOOSE_START_AND_END_DATES' => 'لطفا هر دو محدوده تاریخ شروع و پایان را انتخاب کنید',
    'LBL_CHOOSE_START_AND_END_ENTRIES' => 'لطفا هر دو محدوده تاریخ شروع و پایان را انتخاب کنید',

    //jchi #  20776
    'LBL_DROPDOWN_LIST_ALL' => 'همه',

    //Connector
    'ERR_CONNECTOR_FILL_BEANS_SIZE_MISMATCH' => 'خطا: تعداد آرایه پارامتر bean با تعداد آرایه نتایج مطابقت ندارد.',
    'ERR_MISSING_MAPPING_ENTRY_FORM_MODULE' => 'Error: ورودی نقشه برداری برای ماژول وجود ندارد.',
    'ERROR_UNABLE_TO_RETRIEVE_DATA' => 'خطا: بازیابی اطلاعات برای {0} Connector. ممکن است سرویس در حال حاضر غیرقابل دسترسی باشد یا تنظیمات پیکربندی نامعتبر باشد. پیام خطای رابط: ({1}).',

    // fastcgi checks
    'LBL_FASTCGI_LOGGING' => 'برای اینکه در استفاده از IIS/FastCGI بهترین نتیجه حاصل شود، لازم است در پیکربندی php.ini، مقدار fastcgi.logging را عدد ۰ (صفر) تنظیم کنید.',

    //Collection Field
    'LBL_COLLECTION_NAME' => 'نام',
    'LBL_COLLECTION_PRIMARY' => 'اصلی',
    'ERROR_MISSING_COLLECTION_SELECTION' => 'خالی کردن فیلد الزامی',

    //MB -Fixed Bug #32812 -Max
    'LBL_ASSIGNED_TO_NAME' => 'اختصاص داده شده به',
    'LBL_DESCRIPTION' => 'توضیحات',

    'LBL_YESTERDAY' => 'دیروز',
    'LBL_TODAY' => 'امروز',
    'LBL_TOMORROW' => 'فردا',
    'LBL_NEXT_WEEK' => 'هفته‌ی بعد',
    'LBL_NEXT_MONDAY' => 'دوشنبه آینده',
    'LBL_NEXT_FRIDAY' => 'جمعه آینده',
    'LBL_TWO_WEEKS' => 'دو هفته',
    'LBL_NEXT_MONTH' => 'ماه بعد',
    'LBL_FIRST_DAY_OF_NEXT_MONTH' => 'اولین روز از ماه آینده',
    'LBL_THREE_MONTHS' => 'سه ماه',
    'LBL_SIXMONTHS' => 'شش ماه',
    'LBL_NEXT_YEAR' => 'سال آینده',

    //Datetimecombo fields
    'LBL_HOURS' => 'ساعت',
    'LBL_MINUTES' => 'دقیقه',
    'LBL_MERIDIEM' => 'Meridiem',
    'LBL_DATE' => 'تاریخ',
    'LBL_DASHLET_CONFIGURE_AUTOREFRESH' => 'تازه سازی خودکار',

    'LBL_DURATION_DAY' => 'روز',
    'LBL_DURATION_HOUR' => 'ساعت',
    'LBL_DURATION_MINUTE' => 'دقیقه',
    'LBL_DURATION_DAYS' => 'روز',
    'LBL_DURATION_HOURS' => 'مدت زمان ساعت',
    'LBL_DURATION_MINUTES' => 'مدت زمان دقیقه',

    //Calendar widget labels
    'LBL_CHOOSE_MONTH' => 'ماه مورد نظر را انتخاب کنید.',
    'LBL_ENTER_YEAR' => 'سال مورد نظر را انتخاب کنید.',
    'LBL_ENTER_VALID_YEAR' => 'لطفا یک سال معتبر را وارد کنید.',

    //File write error label
    'ERR_FILE_WRITE' => 'Error: نمی توان فایل نوشت {0}. لطفا مجوزهای سیستم و وب سرور را بررسی کنید.',
    'ERR_FILE_NOT_FOUND' => 'Error: فایل بارگیری نشد {0}. لطفا مجوزهای سیستم و وب سرور را بررسی کنید.',

    'LBL_AND' => 'و',

    // File fields
    'LBL_SEARCH_EXTERNAL_API' => 'فایل در منبع خارجی',
    'LBL_EXTERNAL_SECURITY_LEVEL' => 'امنیت',

    //IMPORT SAMPLE TEXT
    'LBL_IMPORT_SAMPLE_FILE_TEXT' => '
"This is a sample import file which provides an example of the expected contents of a file that is ready for import."
"The file is a comma-delimited .csv file, using double-quotes as the field qualifier."

"The header row is the top-most row in the file and contains the field labels as you would see them in the application."
"These labels are used for mapping the data in the file to the fields in the application."

"Notes: The database names could also be used in the header row. This is useful when you are using phpMyAdmin or another database tool to provide an exported list of data to import."
"The column order is not critical as the import process matches the data to the appropriate fields based on the header row."


"To use this file as a template, do the following:"
"1. Remove the sample rows of data"
"2. Remove the help text that you are reading right now"
"3. Input your own data into the appropriate rows and columns"
"4. Save the file to a known location on your system"
"5. Click on the Import option from the Actions menu in the application and choose the file to upload"
   ',
    //define labels to be used for overriding local values during import/export

    'LBL_NOTIFICATIONS_NONE' => 'هیچ اطلاعیه در جریانی موجود نیست',
    'ERR_NOTIFICATIONS_MARK_AS_READ' => 'خطا هنگام علامت‌گذاری اعلان‌ها به عنوان خوانده شده',
    'ERR_FIELD_LOGIC_BACKEND_CALCULATION' => 'خطا هنگام دریافت مقدار',
    'LBL_ALT_SORT_DESC' => 'مرتب شده نزولی',
    'LBL_ALT_SORT_ASC' => 'مرتب سازی صعودی',
    'LBL_ALT_SORT' => 'مرتب‌سازی',
    'LBL_ALT_SHOW_OPTIONS' => 'نمایش گزینه های',
    'LBL_ALT_HIDE_OPTIONS' => 'پنهان کردن گزینه ها',
    'LBL_ALT_MOVE_COLUMN_LEFT' => 'ورودی انتخاب شده را به لیست سمت چپ منتقل کنید',
    'LBL_ALT_MOVE_COLUMN_RIGHT' => 'ورودی انتخاب شده را به لیست سمت راست منتقل کنید',
    'LBL_ALT_MOVE_COLUMN_UP' => 'ورودی انتخابی را به ترتیب فهرست نمایش داده شده به بالا منتقل کنید',
        'LBL_ALT_MOVE_COLUMN_DOWN' => 'ورودی انتخاب شده را به ترتیب فهرست نمایش داده شده به پایین منتقل کنید',
    'LBL_ALT_INFO' => 'اطلاعات',
    'MSG_DUPLICATE' => 'رکورد {0} که قصد ایجاد آن را دارید ممکن است تکراری از یک رکورد {0} باشد که از قبل وجود دارد. {1} رکوردهای حاوی نام های مشابه در زیر فهرست شده اند.<br>برای ادامه ایجاد این {0} جدید، روی ایجاد {1} کلیک کنید، یا یک {0} موجود در فهرست زیر را انتخاب کنید.',
    'MSG_SHOW_DUPLICATES' => 'رکورد {0} که می‌خواهید ایجاد کنید ممکن است تکراری از یک رکورد {0} باشد که از قبل وجود دارد. {1} رکوردهای حاوی نام های مشابه در زیر فهرست شده اند. برای ادامه ایجاد این {0} جدید روی ذخیره کلیک کنید، یا برای بازگشت به ماژول بدون ایجاد {0}، روی لغو کلیک کنید.',
    'LBL_EMAIL_TITLE' => 'آدرس ایمیل',
    'LBL_EMAIL_OPT_TITLE' => 'صرف نظر کردن از ایمیل آدرس',
    'LBL_EMAIL_INV_TITLE' => 'آدرس ایمیل نامعتبر می باشد',
    'LBL_EMAIL_PRIM_TITLE' => 'ایجاد آدرس ایمیل اصلی',
    'LBL_SELECT_ALL_TITLE' => 'انتخاب همه',
    'LBL_SELECT_THIS_ROW_TITLE' => 'این سطر را انتخاب کنید',

    //for upload errors
    'UPLOAD_ERROR_TEXT' => 'خطا: هنگام بارگزاری خطایی روی داد. کد خطا: {0} - {1}',
    'UPLOAD_ERROR_TEXT_SIZEINFO' => 'خطا: هنگام بارگزاری خطایی روی داد. Error code: {0} - {1}. The upload_maxsize is {2} ',
    'UPLOAD_ERROR_HOME_TEXT' => 'خطا: هنگام بارگزاری خطایی روی داد، لطفاً برای راهنمایی با یک سرپرست تماس بگیرید.',
    'UPLOAD_MAXIMUM_EXCEEDED' => 'اندازه بارگذاری ({0} بایت) از حداکثر مجاز بیشتر شد: {1} bytes',
    'UPLOAD_REQUEST_ERROR' => 'خطایی رخ داده است. لطفاً صفحه خود را بازخوانی کنید و دوباره امتحان کنید.',

    //508 used Access Keys
    'LBL_EDIT_BUTTON_KEY' => 'i',
    'LBL_EDIT_BUTTON_LABEL' => 'ویرایش',
    'LBL_EDIT_BUTTON_TITLE' => 'ویرایش',
    'LBL_DUPLICATE_BUTTON_KEY' => 'u',
    'LBL_DUPLICATE_BUTTON_LABEL' => 'متناظر',
    'LBL_DUPLICATE_BUTTON_TITLE' => 'متناظر',
    'LBL_DELETE_BUTTON_KEY' => 'd',
    'LBL_DELETE_BUTTON_LABEL' => 'حذف',
    'LBL_DELETE_BUTTON_TITLE' => 'حذف',
    'LBL_BULK_ACTION_BUTTON_LABEL' => 'عملیات گروهی',
    'LBL_BULK_ACTION_BUTTON_LABEL_MOBILE' => 'عملکرد',
    'LBL_TOO_FEW_SELECTED' => 'تعداد رکوردهای انتخاب شده نامعتبر است. شما باید حداقل {min} رکورد را انتخاب کنید.',
    'LBL_TOO_MANY_SELECTED' => 'تعداد رکوردهای انتخاب شده نامعتبر است. شما باید حداکثر {max} رکورد را انتخاب کنید.',
    'LBL_SELECT_ALL_NOT_ALLOWED' => 'انتخاب همه رکوردها برای این عمل در دسترس نیست. لطفا سوابق فردی را انتخاب کنید.',
    'LBL_MISSING_HANDLER_DATA' => 'خطای غیرمنتظره. داده های کنترل کننده اقدام انبوه از پاسخ وجود ندارد',
    'LBL_MISSING_HANDLER' => 'خطای غیرمنتظره. هیچ کنترل کننده ای برای اقدام انتخابی انبوه تعریف نشده است',
    'LBL_MISSING_HANDLER_DATA_ROUTE' => 'خطای غیرمنتظره. مسیر اقدام انبوه وجود ندارد',
    'LBL_ACTION_ERROR' => 'خطای غیرمنتظره هنگام فراخوانی اقدام',
    'LBL_BULK_ACTION_ERROR' => 'خطای غیرمنتظره هنگام فراخوانی اقدام انبوه',
    'LBL_BULK_ACTION_DELETE_SUCCESS' => 'رکورد(های) با موفقیت حذف شد',
    'LBL_BULK_ACTION_MASS_UPDATE_CONFIRMATION' => 'آیا مطمئن هستید که می خواهید رکورد(های) انتخابی را به روز کنید؟',
    'LBL_BULK_ACTION_MASS_UPDATE_SUCCESS' => 'همه رکورد(های) با موفقیت به روز شد',
    'LBL_BULK_ACTION_MASS_UPDATE_PARTIAL_SUCCESS' => 'موفقیت نسبی. برخی از سوابق به روز نشدند. لطفا گزارشات را بررسی کنید',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_FIELDS' => 'فیلدی برای به روز رسانی وجود ندارد',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_RECORDS' => 'هیچ رکوردی برای به روز رسانی وجود ندارد',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_ACLS' => 'امتیاز ناکافی، عملیات ذخیره مجاز نیست',
    'LBL_UNEXPECTED_ERROR' => 'خطای غیرمنتظره. قادر به انجام عمل نیست.',
    'LBL_RECORD_DELETE_SUCCESS' => 'رکورد با موفقیت حذف شد',
    'LBL_RECORD_DELETE_ALL_SUCCESS' => 'رکورد با موفقیت حذف شد',
    'LBL_RECORD_SNOOZE_SUCCESS' => 'اعلان به تعویق افتاد',
    'LBL_ERROR_SAVING' => 'هنگام ذخیره رکورد خطایی روی داد',
    'LBL_SAVE_BUTTON_KEY' => 'a',
    'LBL_SAVE_BUTTON_LABEL' => 'ذخيره',
    'LBL_SAVE_BUTTON_TITLE' => 'ذخيره',
    'LBL_CANCEL_BUTTON_KEY' => 'l',
    'LBL_CANCEL_BUTTON_LABEL' => 'لغو',
    'LBL_CANCEL_BUTTON_TITLE' => 'لغو',
    'LBL_FIRST_INPUT_EDIT_VIEW_KEY' => '7',
    'LBL_ADV_SEARCH_LNK_KEY' => '8',
    'LBL_FIRST_INPUT_SEARCH_KEY' => '9',

    'ANNUAL_REVENUE_BY_ACCOUNTS' => 'درآمد سالانه بر اساس حساب',
    'PIPELINE_BY_SALES_STAGE' => 'خط لوله توسط مرحله فروش',
    'LEADS_BY_SOURCE' => 'بر اساس منبع',
    'LEADS_BY_STATUS' => 'بر اساس وضعیت',
    'ACCOUNT_TYPES_PER_MONTH' => 'حساب های جدید بر اساس ماه',

    'ERR_CONNECTOR_NOT_ARRAY' => 'آرایه رابط در {0} به اشتباه تعریف شده است یا خالی است و نمی توان از آن استفاده کرد.',
    'ERR_SUHOSIN' => 'Upload stream is blocked by Suhosin, please add &quot;upload&quot; to suhosin.executor.include.whitelist (See suitecrm.log for more information)',
    'ERR_BAD_RESPONSE_FROM_SERVER' => 'پاسخ بد از سمت سرور',
    'LBL_ACCOUNT_PRODUCT_QUOTE_LINK' => 'پیش‌فاکتور',
    'LBL_ACCOUNT_PRODUCT_SALE_PRICE' => 'قیمت فروش',
    'LBL_EMAIL_CHECK_INTERVAL_DOM' => array(
        '-1' => 'دستی',
        '5' => 'هر 5 دقیقه',
        '15' => 'هر 15 دقیقه',
        '30' => 'هر 30 دقیقه',
        '60' => 'هر ساعت',
    ),

    'ERR_A_REMINDER_IS_EMPTY_OR_INCORRECT' => 'یک یادآور خالی یا نادرست است.',
    'ERR_REMINDER_IS_NOT_SET_POPUP_OR_EMAIL' => 'یادآوری برای یک پاپ آپ یا ایمیل تنظیم نشده است.',
    'ERR_NO_INVITEES_FOR_REMINDER' => 'هیچ دعوت کننده ای برای یادآوری وجود ندارد.',
    'LBL_DELETE_REMINDER_CONFIRM' => 'یادآوری شامل هیچ دعوت‌شده‌ای نمی‌شود، آیا می‌خواهید یادآوری را حذف کنید؟',
    'LBL_DELETE_REMINDER' => 'حذف یادآوری',
    'LBL_OK' => 'باشه',
    'LBL_PROCEED' => 'ادامه دهید',

    'LBL_COLUMNS_FILTER_HEADER_TITLE' => 'ستون ها را انتخاب کنید',
    'LBL_COLUMN_CHOOSER' => 'انتخابگر ستون',
    'LBL_SAVE_CHANGES_BUTTON_TITLE' => 'ذخیره تغییرات',
    'LBL_DISPLAYED' => 'نمایش داده',
    'LBL_HIDDEN' => 'مخفی',
    'ERR_EMPTY_COLUMNS_LIST' => 'حداقل یک عنصر مورد نیاز است',

    'LBL_FILTER_HEADER_TITLE' => 'فیلتر',

    'LBL_CATEGORY' => 'دسته',
    'LBL_LIST_CATEGORY' => 'دسته',
    'ERR_FACTOR_TPL_INVALID' => 'پیام Factor اهراز هویت نامعتبر است، لطفاً با سرپرست خود تماس بگیرید.',
    'LBL_SUBTHEMES' => 'استایل',
    'LBL_SUBTHEME_OPTIONS_DAWN' => 'سحر',
    'LBL_SUBTHEME_OPTIONS_DAY' => 'روز',
    'LBL_SUBTHEME_OPTIONS_DUSK' => 'غروب',
    'LBL_SUBTHEME_OPTIONS_NIGHT' => 'شب',
    'LBL_SUBTHEME_OPTIONS_NOON' => 'ظهر',

    'LBL_CONFIRM_DISREGARD_DRAFT_TITLE' => 'نادیده گرفتن پیش نویس',
    'LBL_CONFIRM_DISREGARD_DRAFT_BODY' => 'این عملیات این ایمیل را حذف می کند، آیا می خواهید ادامه دهید؟',
    'LBL_CONFIRM_DISREGARD_EMAIL_TITLE' => 'خروج از گفتگو',
    'LBL_CONFIRM_DISREGARD_EMAIL_BODY' => 'با خروج از گفتگوی متنی، تمام اطلاعات وارد شده از بین می رود، آیا می خواهید ادامه دهید؟',
    'LBL_CONFIRM_APPLY_EMAIL_TEMPLATE_TITLE' => 'یک الگوی ایمیل را اعمال کنید',
    'LBL_CONFIRM_APPLY_EMAIL_TEMPLATE_BODY' => 'این عملیات فیلدهای Body و Subject ایمیل را لغو می کند، آیا می خواهید ادامه دهید؟',

    'LBL_CONFIRM_OPT_IN_TITLE' => 'شرکت تأیید شد',
    'LBL_OPT_IN_TITLE' => 'عضویت',
    'LBL_CONFIRM_OPT_IN_DATE' => 'تاریخ انتخاب تایید شد',
    'LBL_CONFIRM_OPT_IN_SENT_DATE' => 'تاریخ ارسال تایید شد',
    'LBL_CONFIRM_OPT_IN_FAIL_DATE' => 'تاریخ ناموفق تایید شد',
    'LBL_CONFIRM_OPT_IN_TOKEN' => 'تاریخ توکن تایید شد',
    'ERR_OPT_IN_TPL_NOT_SET' => 'انتخاب الگوی ایمیل پیکربندی نشده است. لطفا در تنظیمات ایمیل پیکربندی کنید.',
    'ERR_OPT_IN_RELATION_INCORRECT' => 'شرکت کردن نیاز دارد که ایمیل مربوط به حساب/تماس/سرب/هدف باشد',

    'LBL_SECURITYGROUP_NONINHERITABLE' => 'گروه غیز قابل انتقال',
    'LBL_PRIMARY_GROUP' => "گروه اولیه",

    // footer
    'LBL_SUITE_TOP' => 'بازگشت به بالا',
    'LBL_SUITE_SUPERCHARGED' => 'سوپرشارژ شده توسط SuiteCRM',
    'LBL_SUITE_POWERED_BY' => 'قدرت گرفته از SugarCRM',
    'LBL_SUITE_DESC1' => 'SuiteCRM نوشته شده است <a href="https://salesagility.com">SalesAgility</a>. برنامه همانطور که هست و بدون ضمانت ارائه می شود. تحت مجوز AGPLv3.',
    'LBL_SUITE_DESC2' => 'این برنامه یک نرم افزار رایگان است; می‌توانید آن را مجدداً توزیع کنید و/یا آن را تحت شرایط مجوز عمومی عمومی GNU Affero نسخه 3 که توسط بنیاد نرم‌افزار آزاد منتشر شده است، از جمله مجوز اضافی مندرج در سربرگ کد منبع، تغییر دهید.',
    'LBL_SUITE_DESC3' => 'SuiteCRM یک علامت تجاری SalesAgility Ltd است. همه نام‌های شرکت و محصولات دیگر ممکن است علائم تجاری شرکت‌های مربوطه باشند که با آنها مرتبط هستند.',
    'LBL_GENERATE_PASSWORD_BUTTON_TITLE' => 'تنظیم مجدد رمز عبور',
    'LBL_SEND_CONFIRM_OPT_IN_EMAIL' => 'ارسال ایمیل تایید شرکت کردن',
    'LBL_CONFIRM_OPT_IN_ONLY_FOR_PERSON' => 'تایید شرکت در ایمیل ارسال فقط برای حساب ها / مخاطبین / سرنخ / بالقوه',
    'LBL_CONFIRM_OPT_IN_IS_DISABLED' => 'تأیید شرکت در ارسال ایمیل غیرفعال است، گزینه Confirm Opt In را در تنظیمات ایمیل فعال کنید یا با سرپرست خود تماس بگیرید.',
    'LBL_CONTACT_HAS_NO_PRIMARY_EMAIL' => 'تایید شرکت در ارسال ایمیل امکان پذیر نیست زیرا مخاطب آدرس ایمیل اصلی ندارد',
    'LBL_CONFIRM_EMAIL_SENDING_FAILED' => 'تأیید شرکت در ارسال ایمیل انجام نشد',
    'LBL_CONFIRM_EMAIL_SENT' => 'تایید شرکت در ایمیل ارسال شده با موفقیت',

    //List View Column Selector Modal
    'LBL_COLUMN_SELECTOR_DISPLAYED_COLS' => 'نمایش داده',
    'LBL_COLUMN_SELECTOR_HIDDEN_COLS' => 'مخفی شده',
    'LBL_COLUMN_SELECTOR_CLOSE_BUTTON' => 'بستن',
    'LBL_COLUMN_SELECTOR_SAVE_BUTTON' => 'ذخیره تغییرات',
    'LBL_COLUMN_SELECTOR_MODAL_TITLE' => 'ستون ها را انتخاب کنید'

);

$app_list_strings['moduleList']['Library'] = 'کتابخانه';
$app_list_strings['moduleList']['EmailAddresses'] = 'آدرس ایمیل';
$app_list_strings['project_priority_default'] = 'متوسط';
$app_list_strings['project_priority_options'] = array(
    'High' => 'زیاد',
    'Medium' => 'متوسط',
    'Low' => 'پایین',
);

//GDPR lawful basis options
$app_list_strings['lawful_basis_dom'] = array(
    '' => '',
    'consent' => 'رضایت',
    'contract' => 'قرارداد',
    'legal_obligation' => 'تعهد قانونی',
    'protection_of_interest' => 'حفاظت از منافع',
    'public_interest' => 'منافع عمومی',
    'legitimate_interest' => 'منافع مشروع',
    'withdrawn' => 'برداشته شد',
);
//End GDPR lawful basis options

//GDPR lawful basis source options
$app_list_strings['lawful_basis_source_dom'] = array(
    '' => '',
    'website' => 'وب سایت',
    'phone' => 'تلفن',
    'given_to_user' => 'به کاربر داده می شود',
    'email' => 'ایمیل',
    'third_party' => 'شخص ثالث',
);
//End GDPR lawful basis source options

$app_list_strings['moduleList']['KBDocuments'] = 'دانش بنیان';

$app_list_strings['countries_dom'] = array(
    '' => '',
    'ABU DHABI' => 'ابوظبی',
    'ADEN' => 'عدن',
    'AFGHANISTAN' => 'افغانستان',
    'ALBANIA' => 'آلبانی',
    'ALGERIA' => 'الجزایر',
    'AMERICAN SAMOA' => 'ساموا آمریکایی',
    'ANDORRA' => 'آندورا',
    'ANGOLA' => 'آنگولا',
    'ANTARCTICA' => 'قطب جنوب',
    'ANTIGUA' => 'آنتیگوا',
    'ARGENTINA' => 'آرژانتین',
    'ARMENIA' => 'ارمنستان',
    'ARUBA' => 'آروبا',
    'AUSTRALIA' => 'استرالیا',
    'AUSTRIA' => 'اتریش',
    'AZERBAIJAN' => 'آذربایجان',
    'BAHAMAS' => 'باهاما',
    'BAHRAIN' => 'بحرین',
    'BANGLADESH' => 'بنگلادش',
    'BARBADOS' => 'باربادوس',
    'BELARUS' => 'بلاروس',
    'BELGIUM' => 'بلژیک',
    'BELIZE' => 'بلیز',
    'BENIN' => 'بنین',
    'BERMUDA' => 'برمودا',
    'BHUTAN' => 'بوتان',
    'BOLIVIA' => 'بولیوی',
    'BOSNIA' => 'بوسنی',
    'BOTSWANA' => 'بوتسوانا',
    'BOUVET ISLAND' => 'جزیره بووت',
    'BRAZIL' => 'برزیل',
    'BRITISH ANTARCTICA TERRITORY' => 'جنوبگان بریتانیایی',
    'BRITISH INDIAN OCEAN TERRITORY' => 'اقیانوس هند انگلیس',
    'BRITISH VIRGIN ISLANDS' => 'جزایر ویرجین بریتانیا',
    'BRITISH WEST INDIES' => 'کشورهای هند غربی بریتانیا',
    'BRUNEI' => 'برونئی',
    'BULGARIA' => 'بلغارستان',
    'BURKINA FASO' => 'بورکینا فاسو',
    'BURUNDI' => 'بوروندی',
    'CAMBODIA' => 'کامبوج',
    'CAMEROON' => 'کامرون',
    'CANADA' => 'کانادا',
    'CANAL ZONE' => 'منطقه کانال',
    'CANARY ISLAND' => 'جزیره قناری',
    'CAPE VERDI ISLANDS' => 'جزایر کیپ وردی',
    'CAYMAN ISLANDS' => 'جزایر کیمن',
    'CHAD' => 'چاد',
    'CHANNEL ISLAND UK' => 'کانال جزیره انگلستان',
    'CHILE' => 'شیلی',
    'CHINA' => 'چین',
    'CHRISTMAS ISLAND' => 'جزیره کریسمس',
    'COCOS (KEELING) ISLAND' => 'جزیره کوکوس',
    'COLOMBIA' => 'کلمبیا',
    'COMORO ISLANDS' => 'جزایر کومورو',
    'CONGO' => 'کنگو',
    'CONGO KINSHASA' => 'کنگو کینشاسا',
    'COOK ISLANDS' => 'جزایر کوک',
    'COSTA RICA' => 'کاستاریکا',
    'CROATIA' => 'کرواسی',
    'CUBA' => 'کوبا',
    'CURACAO' => 'کوراسائو',
    'CYPRUS' => 'قبرس',
    'CZECH REPUBLIC' => 'جمهوری چک',
    'DAHOMEY' => 'داهومی',
    'DENMARK' => 'دانمارک',
    'DJIBOUTI' => 'جیبوتی',
    'DOMINICA' => 'دومینیکا',
    'DOMINICAN REPUBLIC' => 'جمهوری دومینیکن',
    'DUBAI' => 'دبی',
    'ECUADOR' => 'اکوادور',
    'EGYPT' => 'مصر',
    'EL SALVADOR' => 'السالوادور',
    'EQUATORIAL GUINEA' => 'گینه استوایی',
    'ESTONIA' => 'استونی',
    'ETHIOPIA' => 'اتیوپی',
    'FAEROE ISLANDS' => 'جزایر FAEROE',
    'FALKLAND ISLANDS' => 'جزایر فالکلند',
    'FIJI' => 'فیجی',
    'FINLAND' => 'فنلاند',
    'FRANCE' => 'فرانسه',
    'FRENCH GUIANA' => 'گیانا فرانسه',
    'FRENCH POLYNESIA' => 'پلینزی فرانسه',
    'GABON' => 'گابن',
    'GAMBIA' => 'گامبیا',
    'GEORGIA' => 'گرجستان',
    'GERMANY' => 'آلمان',
    'GHANA' => 'غنا',
    'GIBRALTAR' => 'جبل الطارق',
    'GREECE' => 'یونان',
    'GREENLAND' => 'گرینلند',
    'GUADELOUPE' => 'گوادلوپ',
    'GUAM' => 'GUAM',
    'GUATEMALA' => 'گواتمالا',
    'GUINEA' => 'گینه',
    'GUYANA' => 'گویان',
    'HAITI' => 'هائیتی',
    'HONDURAS' => 'هندوراس',
    'HONG KONG' => 'هنگ کنگ',
    'HUNGARY' => 'مجارستان',
    'ICELAND' => 'ایسلند',
    'IFNI' => 'ایفنی',
    'INDIA' => 'هند',
    'INDONESIA' => 'اندونزی',
    'IRAN' => 'ایران',
    'IRAQ' => 'عراق',
    'IRELAND' => 'ایرلند',
    'ISRAEL' => 'اسرائیل',
    'ITALY' => 'ایتالیا',
    'IVORY COAST' => 'ساحل عاج',
    'JAMAICA' => 'جامائیکا',
    'JAPAN' => 'ژاپن',
    'JORDAN' => 'اردن',
    'KAZAKHSTAN' => 'قزاقستان',
    'KENYA' => 'کنیا',
    'KOREA' => 'کره',
    'KOREA, SOUTH' => 'کره جنوبی',
    'KUWAIT' => 'کویت',
    'KYRGYZSTAN' => 'قرقیزستان',
    'LAOS' => 'لائوس',
    'LATVIA' => 'لتونی',
    'LEBANON' => 'لبنان',
    'LEEWARD ISLANDS' => 'جزایر بادپناه',
    'LESOTHO' => 'لسوتو',
    'LIBYA' => 'لیبی',
    'LIECHTENSTEIN' => 'لیختن اشتاین',
    'LITHUANIA' => 'لیتوانی',
    'LUXEMBOURG' => 'لوکزامبورگ',
    'MACAO' => 'ماکائو',
    'MACEDONIA' => 'مقدونیه',
    'MADAGASCAR' => 'ماداگاسکار',
    'MALAWI' => 'مالاوی',
    'MALAYSIA' => 'مالزی',
    'MALDIVES' => 'مالدیو',
    'MALI' => 'مالی',
    'MALTA' => 'مالتا',
    'MARTINIQUE' => 'مارتینیک',
    'MAURITANIA' => 'موریتانی',
    'MAURITIUS' => 'موریس',
    'MELANESIA' => 'ملانزی',
    'MEXICO' => 'مکزیک',
    'MOLDOVIA' => 'مالدیو',
    'MONACO' => 'موناکو',
    'MONGOLIA' => 'مغولستان',
    'MOROCCO' => 'مراکش',
    'MOZAMBIQUE' => 'موزامبیک',
    'MYANAMAR' => 'میان مار',
    'NAMIBIA' => 'نامیبیا',
    'NEPAL' => 'نپال',
    'NETHERLANDS' => 'هلند',
    'NETHERLANDS ANTILLES' => 'آنتیل هلند',
    'NETHERLANDS ANTILLES NEUTRAL ZONE' => 'منطقه خنثی آنتیل هلند',
    'NEW CALADONIA' => 'کالدونیای جدید',
    'NEW HEBRIDES' => 'هبریدز نو',
    'NEW ZEALAND' => 'زلاند نو',
    'NICARAGUA' => 'نیکاراگوئه',
    'NIGER' => 'نیجر',
    'NIGERIA' => 'نیجریه',
    'NORFOLK ISLAND' => 'جزیره نورفولک',
    'NORWAY' => 'نروژ',
    'OMAN' => 'عمان',
    'OTHER' => 'دیگر',
    'PACIFIC ISLAND' => 'جزیره های اقیانوس آرام',
    'PAKISTAN' => 'پاکستان',
    'PANAMA' => 'پاناما',
    'PAPUA NEW GUINEA' => 'گینه نو',
    'PARAGUAY' => 'پاراگوئه',
    'PERU' => 'پرو',
    'PHILIPPINES' => 'فیلیپین',
    'POLAND' => 'لهستان',
    'PORTUGAL' => 'پرتغال',
    'PORTUGUESE TIMOR' => 'تیمور شرقی',
    'PUERTO RICO' => 'پورتوریکو',
    'QATAR' => 'قطر',
    'REPUBLIC OF BELARUS' => 'جمهوری بلاروس',
    'REPUBLIC OF SOUTH AFRICA' => 'افریقای جنوبی',
    'REUNION' => 'رئونیون',
    'ROMANIA' => 'رومانی',
    'RUSSIA' => 'روسیه',
    'RWANDA' => 'رواندا',
    'RYUKYU ISLANDS' => 'جزایر ریوکیو',
    'SABAH' => 'صباح',
    'SAN MARINO' => 'سن مارینو',
    'SAUDI ARABIA' => 'عربستان سعودی',
    'SENEGAL' => 'سنگال',
    'SERBIA' => 'صربستان',
    'SEYCHELLES' => 'سیشل',
    'SIERRA LEONE' => 'سیرالئون',
    'SINGAPORE' => 'سنگاپور',
    'SLOVAKIA' => 'اسلواکی',
    'SLOVENIA' => 'اسلوونی',
    'SOMALILIAND' => 'سومالی‌لند',
    'SOUTH AFRICA' => 'آفریقای جنوبی',
    'SOUTH YEMEN' => 'یمن جنوبی',
    'SPAIN' => 'اسپانیا',
    'SPANISH SAHARA' => 'صحرای اسپانیا',
    'SRI LANKA' => 'سری لانکا',
    'ST. KITTS AND NEVIS' => 'سنت کیتس و نویس',
    'ST. LUCIA' => 'سنت لوسیا',
    'SUDAN' => 'سودان',
    'SURINAM' => 'سورینام',
    'SW AFRICA' => 'جنوب غربی آفریقا',
    'SWAZILAND' => 'اسواتینی',
    'SWEDEN' => 'سوئد',
    'SWITZERLAND' => 'سوئیس',
    'SYRIA' => 'سوریه',
    'TAIWAN' => 'تایوان',
    'TAJIKISTAN' => 'تاجیکستان',
    'TANZANIA' => 'تانزانیا',
    'THAILAND' => 'تایلند',
    'TONGA' => 'تونگا',
    'TRINIDAD' => 'ترینیداد',
    'TUNISIA' => 'تونس',
    'TURKEY' => 'ترکیه',
    'UGANDA' => 'اوگاندا',
    'UKRAINE' => 'اوکراین',
    'UNITED ARAB EMIRATES' => 'امارات متحده عربی',
    'UNITED KINGDOM' => 'انگلستان',
    'URUGUAY' => 'اروگوئه',
    'US PACIFIC ISLAND' => 'قلمروهای ایالات متحده آمریکا',
    'US VIRGIN ISLANDS' => 'جزایر ویرجین ایالات متحده آمریکا',
    'USA' => 'ایالات متحده آمریکا',
    'UZBEKISTAN' => 'ازبکستان',
    'VANUATU' => 'وانواتو',
    'VATICAN CITY' => 'شهر واتیکان',
    'VENEZUELA' => 'ونزوئلا',
    'VIETNAM' => 'ویتنام',
    'WAKE ISLAND' => 'جزیره ویک',
    'WEST INDIES' => 'غرب هند',
    'WESTERN SAHARA' => 'صحرای غربی',
    'YEMEN' => 'یمن',
    'ZAIRE' => 'زئیر',
    'ZAMBIA' => 'زامبیا',
    'ZIMBABWE' => 'زیمبابوه',
);

$app_list_strings['charset_dom'] = array(
    'BIG-5' => 'BIG-5 (Taiwan and Hong Kong)',
    /*'CP866'     => 'CP866', // ms-dos Cyrillic */
    /*'CP949'     => 'CP949 (Microsoft Korean)', */
    'CP1251' => 'CP1251 (MS Cyrillic)',
    'CP1252' => 'CP1252 (MS Western European & US)',
    'EUC-CN' => 'EUC-CN (Simplified Chinese GB2312)',
    'EUC-JP' => 'EUC-JP (Unix Japanese)',
    'EUC-KR' => 'EUC-KR (Korean)',
    'EUC-TW' => 'EUC-TW (Taiwanese)',
    'ISO-2022-JP' => 'ISO-2022-JP (Japanese)',
    'ISO-2022-KR' => 'ISO-2022-KR (Korean)',
    'ISO-8859-1' => 'ISO-8859-1 (Western European and US)',
    'ISO-8859-2' => 'ISO-8859-2 (Central and Eastern European)',
    'ISO-8859-3' => 'ISO-8859-3 (Latin 3)',
    'ISO-8859-4' => 'ISO-8859-4 (Latin 4)',
    'ISO-8859-5' => 'ISO-8859-5 (Cyrillic)',
    'ISO-8859-6' => 'ISO-8859-6 (Arabic)',
    'ISO-8859-7' => 'ISO-8859-7 (Greek)',
    'ISO-8859-8' => 'ISO-8859-8 (Hebrew)',
    'ISO-8859-9' => 'ISO-8859-9 (Latin 5)',
    'ISO-8859-10' => 'ISO-8859-10 (Latin 6)',
    'ISO-8859-13' => 'ISO-8859-13 (Latin 7)',
    'ISO-8859-14' => 'ISO-8859-14 (Latin 8)',
    'ISO-8859-15' => 'ISO-8859-15 (Latin 9)',
    'KOI8-R' => 'KOI8-R (Cyrillic Russian)',
    'KOI8-U' => 'KOI8-U (Cyrillic Ukranian)',
    'SJIS' => 'SJIS (MS Japanese)',
    'UTF-8' => 'UTF-8',
);

$app_list_strings['timezone_dom'] = array(

    'Africa/Algiers' => 'آفریقا/الجزیره',
    'Africa/Luanda' => 'آفریقا/لواندا',
    'Africa/Porto-Novo' => 'آفریقا/پورتو نوو',
    'Africa/Gaborone' => 'آفریقا/گابورون',
    'Africa/Ouagadougou' => 'آفریقا/اوگادوگو',
    'Africa/Bujumbura' => 'آفریقا/بوجمبورا',
    'Africa/Douala' => 'آفریقا/دوآلا',
    'Atlantic/Cape_Verde' => 'اقیانوس اطلس/کیپ ورد',
    'Africa/Bangui' => 'آفریقا/بانگوئی',
    'Africa/Ndjamena' => 'آفریقا/نجامنا',
    'Indian/Comoro' => 'هند/کومورو',
    'Africa/Kinshasa' => 'آفریقا/کینشاسا',
    'Africa/Lubumbashi' => 'آفریقا/لوبوباشی',
    'Africa/Brazzaville' => 'آفریقا/برازاویل',
    'Africa/Abidjan' => 'آفریقا/ابیجان',
    'Africa/Djibouti' => 'آفریقا/جیبوتی',
    'Africa/Cairo' => 'آفریقا/قاهره',
    'Africa/Malabo' => 'آفریقا/مالابو',
    'Africa/Asmera' => 'آفریقا/آسمرا',
    'Africa/Addis_Ababa' => 'آفریقا/آدیس آبابا',
    'Africa/Libreville' => 'آفریقا/لیبرویل',
    'Africa/Banjul' => 'آفریقا/بانجول',
    'Africa/Accra' => 'آفریقا/آکرا',
    'Africa/Conakry' => 'آفریقا/کوناکری',
    'Africa/Bissau' => 'آفریقا/بیسائو',
    'Africa/Nairobi' => 'آفریقا/نایروبی',
    'Africa/Maseru' => 'آفریقا/ماسرو',
    'Africa/Monrovia' => 'آفریقا/مونروویا',
    'Africa/Tripoli' => 'آفریقا/طرابلس',
    'Indian/Antananarivo' => 'هند/آنتاناناریوو',
    'Africa/Blantyre' => 'آفریقا/بلانتایر',
    'Africa/Bamako' => 'آفریقا/باماکو',
    'Africa/Nouakchott' => 'آفریقا/نواکشوت',
    'Indian/Mauritius' => 'هند / موریس',
    'Indian/Mayotte' => 'هند/مایوت',
    'Africa/Casablanca' => 'آفریقا/کازابلانکا',
    'Africa/El_Aaiun' => 'آفریقا/العیون',
    'Africa/Maputo' => 'آفریقا/ماپوتو',
    'Africa/Windhoek' => 'آفریقا/ویندهوک',
    'Africa/Niamey' => 'آفریقا/نیامی',
    'Africa/Lagos' => 'آفریقا/لاگوس',
    'Indian/Reunion' => 'هند/یونیون',
    'Africa/Kigali' => 'آفریقا/کیگالی',
    'Atlantic/St_Helena' => 'آتلانتیک/سنت هلنا',
    'Africa/Sao_Tome' => 'آفریقا/سائوتومه',
    'Africa/Dakar' => 'آفریقا/داکار',
    'Indian/Mahe' => 'هند/ماهه',
    'Africa/Freetown' => 'آفریقا/فری تاون',
    'Africa/Mogadishu' => 'آفریقا/موگادیشو',
    'Africa/Johannesburg' => 'آفریقا/ژوهانسبورگ',
    'Africa/Khartoum' => 'آفریقا/ خارطوم',
    'Africa/Mbabane' => 'آفریقا/مباپه',
    'Africa/Dar_es_Salaam' => 'آفریقا/ دارالسلام',
    'Africa/Lome' => 'آفریقا/لومه',
    'Africa/Tunis' => 'آفریقا/تونس',
    'Africa/Kampala' => 'آفریقا/کامپالا',
    'Africa/Lusaka' => 'آفریقا/لوزاکا',
    'Africa/Harare' => 'آفریقا / حراره',
    'Antarctica/Casey' => 'قطب جنوب/کیسی',
    'Antarctica/Davis' => 'قطب جنوب/دیویس',
    'Antarctica/Mawson' => 'قطب جنوب / ماوسون',
    'Indian/Kerguelen' => 'هندی/کرگولن',
    'Antarctica/DumontDUrville' => 'قطب جنوب / DumontDUrville',
    'Antarctica/Syowa' => 'قطب جنوب/سیووا',
    'Antarctica/Vostok' => 'قطب جنوب / وستوک',
    'Antarctica/Rothera' => 'قطب جنوب/روترا',
    'Antarctica/Palmer' => 'قطب جنوب / پالمر',
    'Antarctica/McMurdo' => 'قطب جنوب/مک موردو',
    'Asia/Kabul' => 'آسیا/کابل',
    'Asia/Yerevan' => 'آسیا/ایروان',
    'Asia/Baku' => 'آسیا/باکو',
    'Asia/Bahrain' => 'آسیا/بحرین',
    'Asia/Dhaka' => 'آسیا/داکا',
    'Asia/Thimphu' => 'آسیا/تیمفو',
    'Indian/Chagos' => 'هندی/چاگوس',
    'Asia/Brunei' => 'آسیا/برونئی',
    'Asia/Rangoon' => 'آسیا/رانگون',
    'Asia/Phnom_Penh' => 'آسیا/پنوم پن',
    'Asia/Beijing' => 'آسیا/پکن',
    'Asia/Harbin' => 'آسیا/هاربین',
    'Asia/Shanghai' => 'آسیا/شانگهای',
    'Asia/Chongqing' => 'آسیا/چونگ کینگ',
    'Asia/Urumqi' => 'آسیا/اورومچی',
    'Asia/Kashgar' => 'آسیا/کاشگر',
    'Asia/Hong_Kong' => 'آسیا/هنگ کنگ',
    'Asia/Taipei' => 'آسیا/تایپه',
    'Asia/Macau' => 'آسیا/ماکائو',
    'Asia/Nicosia' => 'آسیا/ نیکوزیا',
    'Asia/Tbilisi' => 'آسیا/تفلیس',
    'Asia/Dili' => 'آسیا/دیلی',
    'Asia/Calcutta' => 'آسیا/کلکته',
    'Asia/Jakarta' => 'آسیا/جاکارتا',
    'Asia/Pontianak' => 'آسیا/پونتیاناک',
    'Asia/Makassar' => 'آسیا/ماکاسار',
    'Asia/Jayapura' => 'آسیا/جایاپورا',
    'Asia/Tehran' => 'آسیا/تهران',
    'Asia/Baghdad' => 'آسیا/بغداد',
    'Asia/Jerusalem' => 'آسیا/اورشلیم',
    'Asia/Tokyo' => 'آسیا/توکیو',
    'Asia/Amman' => 'آسیا/امان',
    'Asia/Almaty' => 'آسیا/آلماتی',
    'Asia/Qyzylorda' => 'آسیا/قیزیلوردا',
    'Asia/Aqtobe' => 'آسیا/آقتوبه',
    'Asia/Aqtau' => 'آسیا/آقتاو',
    'Asia/Oral' => 'آسیا / شفاهی',
    'Asia/Bishkek' => 'آسیا/بیشکک',
    'Asia/Seoul' => 'آسیا/سئول',
    'Asia/Pyongyang' => 'آسیا/پیونگ یانگ',
    'Asia/Kuwait' => 'آسیا/کویت',
    'Asia/Vientiane' => 'آسیا/وینتیان',
    'Asia/Beirut' => 'آسیا/بیروت',
    'Asia/Kuala_Lumpur' => 'آسیا/کوالالامپور',
    'Asia/Kuching' => 'آسیا/کوچینگ',
    'Indian/Maldives' => 'هند/مالدیو',
    'Asia/Hovd' => 'آسیا/Hovd',
    'Asia/Ulaanbaatar' => 'آسیا/اولان باتور',
    'Asia/Choibalsan' => 'آسیا/چویبالسان',
    'Asia/Katmandu' => 'آسیا/کاتماندو',
    'Asia/Muscat' => 'آسیا/مسقط',
    'Asia/Karachi' => 'آسیا/کراچی',
    'Asia/Gaza' => 'آسیا/غزه',
    'Asia/Manila' => 'آسیا/مانیل',
    'Asia/Qatar' => 'آسیا/قطر',
    'Asia/Riyadh' => 'آسیا/ریاض',
    'Asia/Singapore' => 'آسیا/سنگاپور',
    'Asia/Colombo' => 'آسیا/کلمبو',
    'Asia/Damascus' => 'آسیا/دمشق',
    'Asia/Dushanbe' => 'آسیا/دوشنبه',
    'Asia/Bangkok' => 'آسیا/بانکوک',
    'Asia/Ashgabat' => 'آسیا/عشق آباد',
    'Asia/Dubai' => 'آسیا/دبی',
    'Asia/Samarkand' => 'آسیا/سمرقند',
    'Asia/Tashkent' => 'آسیا/تاشکند',
    'Asia/Saigon' => 'آسیا/سایگون',
    'Asia/Aden' => 'آسیا/عدن',
    'Australia/Darwin' => 'استرالیا/داروین',
    'Australia/Perth' => 'استرالیا/پرت',
    'Australia/Brisbane' => 'استرالیا/بریزبن',
    'Australia/Lindeman' => 'استرالیا/لیندمن',
    'Australia/Adelaide' => 'استرالیا/آدلاید',
    'Australia/Hobart' => 'استرالیا/هوبارت',
    'Australia/Currie' => 'استرالیا / کوری',
    'Australia/Melbourne' => 'استرالیا/ملبورن',
    'Australia/Sydney' => 'استرالیا/سیدنی',
    'Australia/Broken_Hill' => 'استرالیا/بروکن هیل',
    'Indian/Christmas' => 'هندی / کریسمس',
    'Pacific/Rarotonga' => 'اقیانوس آرام/راروتونگا',
    'Indian/Cocos' => 'هندی/کوکوس',
    'Pacific/Fiji' => 'اقیانوس آرام/فیجی',
    'Pacific/Gambier' => 'اقیانوس آرام/گامبیر',
    'Pacific/Marquesas' => 'اقیانوس آرام/مارکزاس',
    'Pacific/Tahiti' => 'اقیانوس آرام/تاهیتی',
    'Pacific/Guam' => 'اقیانوس آرام/گوام',
    'Pacific/Tarawa' => 'اقیانوس آرام/تاراوا',
    'Pacific/Enderbury' => 'اقیانوس آرام/اندربوری',
    'Pacific/Kiritimati' => 'اقیانوس آرام/کریتیماتی',
    'Pacific/Saipan' => 'اقیانوس آرام/سایپان',
    'Pacific/Majuro' => 'اقیانوس آرام/ماجورو',
    'Pacific/Kwajalein' => 'اقیانوس آرام/کواجالین',
    'Pacific/Truk' => 'اقیانوس آرام / کامیون',
    'Pacific/Pohnpei' => 'اقیانوس آرام / پونپی',
    'Pacific/Kosrae' => 'اقیانوس آرام/کوسرایی',
    'Pacific/Nauru' => 'اقیانوس آرام/نائورو',
    'Pacific/Noumea' => 'اقیانوس آرام / نومئا',
    'Pacific/Auckland' => 'اقیانوس آرام / اوکلند',
    'Pacific/Chatham' => 'اقیانوس آرام/چاتام',
    'Pacific/Niue' => 'اقیانوس آرام/نیوئه',
    'Pacific/Norfolk' => 'اقیانوس آرام/نورفولک',
    'Pacific/Palau' => 'اقیانوس آرام/پالائو',
    'Pacific/Port_Moresby' => 'اقیانوس آرام/پورت مورسبی',
    'Pacific/Pitcairn' => 'اقیانوس آرام / پیتکرن',
    'Pacific/Pago_Pago' => 'اقیانوس آرام/پاگو پاگو',
    'Pacific/Apia' => 'اقیانوس آرام/آپیا',
    'Pacific/Guadalcanal' => 'اقیانوس آرام/گوادالکانال',
    'Pacific/Fakaofo' => 'اقیانوس آرام/فاکاوفو',
    'Pacific/Tongatapu' => 'اقیانوس آرام/تونگاتاپو',
    'Pacific/Funafuti' => 'اقیانوس آرام / فونافوتی',
    'Pacific/Johnston' => 'اقیانوس آرام/جانستون',
    'Pacific/Midway' => 'اقیانوس آرام/میدوی',
    'Pacific/Wake' => 'اقیانوس آرام/بیدار',
    'Pacific/Efate' => 'اقیانوس آرام/عفات',
    'Pacific/Wallis' => 'اقیانوس آرام/والیس',
    'Europe/London' => 'اروپا/لندن',
    'Europe/Dublin' => 'اروپا/دوبلین',
    'WET' => 'مرطوب',
    'CET' => 'CET',
    'MET' => 'MET',
    'EET' => 'EET',
    'Europe/Tirane' => 'اروپا/تیران',
    'Europe/Andorra' => 'اروپا/آندورا',
    'Europe/Vienna' => 'اروپا/وین',
    'Europe/Minsk' => 'اروپا/مینسک',
    'Europe/Brussels' => 'اروپا/بروکسل',
    'Europe/Sofia' => 'اروپا/صوفیه',
    'Europe/Prague' => 'اروپا/پراگ',
    'Europe/Copenhagen' => 'اروپا/کپنهاگ',
    'Atlantic/Faeroe' => 'اقیانوس اطلس/فارو',
    'America/Danmarkshavn' => 'آمریکا/دانمارکشان',
    'America/Scoresbysund' => 'آمریکا/اسکورزبیسوند',
    'America/Godthab' => 'آمریکا/Godthab',
    'America/Thule' => 'آمریکا/تول',
    'Europe/Tallinn' => 'اروپا/تالین',
    'Europe/Helsinki' => 'اروپا/هلسینکی',
    'Europe/Paris' => 'اروپا/پاریس',
    'Europe/Berlin' => 'اروپا/برلین',
    'Europe/Gibraltar' => 'اروپا/جبل الطارق',
    'Europe/Athens' => 'اروپا / آتن',
    'Europe/Budapest' => 'اروپا/بوداپست',
    'Atlantic/Reykjavik' => 'اقیانوس اطلس/ریکیاویک',
    'Europe/Rome' => 'اروپا/رم',
    'Europe/Riga' => 'اروپا/ریگا',
    'Europe/Vaduz' => 'اروپا/وادوز',
    'Europe/Vilnius' => 'اروپا/ویلنیوس',
    'Europe/Luxembourg' => 'اروپا / لوکزامبورگ',
    'Europe/Malta' => 'اروپا/مالتا',
    'Europe/Chisinau' => 'اروپا/کیسینو',
    'Europe/Monaco' => 'اروپا /موناکو',
    'Europe/Amsterdam' => 'اروپا/آمستردام',
    'Europe/Oslo' => 'اروپا/اسلو',
    'Europe/Warsaw' => 'اروپا/ورشو',
    'Europe/Lisbon' => 'اروپا/لیسبون',
    'Atlantic/Azores' => 'اقیانوس اطلس / آزور',
    'Atlantic/Madeira' => 'اقیانوس اطلس / مادیرا',
    'Europe/Bucharest' => 'اروپا/بخارست',
    'Europe/Kaliningrad' => 'اروپا/کالینینگراد',
    'Europe/Moscow' => 'اروپا / مسکو',
    'Europe/Samara' => 'اروپا/سامارا',
    'Asia/Yekaterinburg' => 'آسیا/یکاترینبورگ',
    'Asia/Omsk' => 'آسیا/امسک',
    'Asia/Novosibirsk' => 'آسیا/نووسیبیرسک',
    'Asia/Krasnoyarsk' => 'آسیا/کراسنویارسک',
    'Asia/Irkutsk' => 'آسیا/ایرکوتسک',
    'Asia/Yakutsk' => 'آسیا/یاکوتسک',
    'Asia/Vladivostok' => 'آسیا/ولادی وستوک',
    'Asia/Sakhalin' => 'آسیا/ساخالین',
    'Asia/Magadan' => 'آسیا/ماگادان',
    'Asia/Kamchatka' => 'آسیا/کامچاتکا',
    'Asia/Anadyr' => 'آسیا/آنادیر',
    'Europe/Belgrade' => 'اروپا/بلگراد',
    'Europe/Madrid' => 'اروپا/مادرید',
    'Africa/Ceuta' => 'آفریقا / سئوتا',
    'Atlantic/Canary' => 'اقیانوس اطلس / قناری',
    'Europe/Stockholm' => 'اروپا/استکهلم',
    'Europe/Zurich' => 'اروپا/زوریخ',
    'Europe/Istanbul' => 'اروپا/استانبول',
    'Europe/Kiev' => 'اروپا/کیف',
    'Europe/Uzhgorod' => 'اروپا/Uzhgorod',
    'Europe/Zaporozhye' => 'اروپا/زاپوروژیه',
    'Europe/Simferopol' => 'اروپا/سیمفروپل',
    'America/New_York' => 'آمریکا/نیویورک',
    'America/Chicago' => 'آمریکا/شیکاگو',
    'America/North_Dakota/Center' => 'آمریکا / داکوتای شمالی / مرکز',
    'America/Denver' => 'آمریکا/دنور',
    'America/Los_Angeles' => 'آمریکا / لس آنجلس',
    'America/Juneau' => 'آمریکا/ژون',
    'America/Yakutat' => 'آمریکا/یاکوتات',
    'America/Anchorage' => 'آمریکا/انکوریج',
    'America/Nome' => 'آمریکا / نام',
    'America/Adak' => 'آمریکا/آداک',
    'Pacific/Honolulu' => 'اقیانوس آرام/هونولولو',
    'America/Phoenix' => 'آمریکا/ققنوس',
    'America/Boise' => 'آمریکا/بویز',
    'America/Indiana/Indianapolis' => 'آمریکا / ایندیانا / ایندیاناپولیس',
    'America/Indiana/Marengo' => 'آمریکا/ایندیانا/مارنگو',
    'America/Indiana/Knox' => 'آمریکا / ایندیانا / ناکس',
    'America/Indiana/Vevay' => 'آمریکا / ایندیانا / ووی',
    'America/Kentucky/Louisville' => 'آمریکا / کنتاکی / لوئیزویل',
    'America/Kentucky/Monticello' => 'آمریکا/کنتاکی/مونتیچلو',
    'America/Detroit' => 'آمریکا/دیترویت',
    'America/Menominee' => 'آمریکا/منومین',
    'America/St_Johns' => 'آمریکا/سنت جانز',
    'America/Goose_Bay' => 'آمریکا/خلیج غاز',
    'America/Halifax' => 'آمریکا/هالیفاکس',
    'America/Glace_Bay' => 'آمریکا/ خلیج گلیس',
    'America/Montreal' => 'آمریکا/مونترال',
    'America/Toronto' => 'آمریکا/تورنتو',
    'America/Thunder_Bay' => 'آمریکا/ خلیج تندر',
    'America/Nipigon' => 'آمریکا/نیپیگون',
    'America/Rainy_River' => 'آمریکا/رود بارانی',
    'America/Winnipeg' => 'آمریکا/وینیپگ',
    'America/Regina' => 'آمریکا/رجینا ',
    'America/Swift_Current' => 'آمریکا/جریان سوئیفت',
    'America/Edmonton' => 'آمریکا/ادمونتون',
    'America/Vancouver' => 'آمریکا/ونکوور',
    'America/Dawson_Creek' => 'آمریکا/داوسون کریک',
    'America/Pangnirtung' => 'آمریکا/پانگنیرتانگ',
    'America/Iqaluit' => 'آمریکا/ایکالویت',
    'America/Coral_Harbour' => 'آمریکا / بندر کورال',
    'America/Rankin_Inlet' => 'آمریکا / ورودی رنکین',
    'America/Cambridge_Bay' => 'آمریکا / خلیج کمبریج',
    'America/Yellowknife' => 'آمریکا/زرد نایف',
    'America/Inuvik' => 'آمریکا/اینوویک',
    'America/Whitehorse' => 'آمریکا / وایت هورس',
    'America/Dawson' => 'آمریکا/داوسون',
    'America/Cancun' => 'آمریکا/کانکون',
    'America/Merida' => 'آمریکا/مریدا',
    'America/Monterrey' => 'آمریکا/مونتری',
    'America/Mexico_City' => 'آمریکا/مکزیکو سیتی',
    'America/Chihuahua' => 'آمریکا/چیهواهوا',
    'America/Hermosillo' => 'آمریکا/هرموسیلو',
    'America/Mazatlan' => 'آمریکا/مازاتلان',
    'America/Tijuana' => 'آمریکا/تیجوانا',
    'America/Anguilla' => 'آمریکا/آنگویلا',
    'America/Antigua' => 'آمریکا/آنتیگوا',
    'America/Nassau' => 'آمریکا/ناسائو',
    'America/Barbados' => 'آمریکا/باربادوس',
    'America/Belize' => 'آمریکا/بلیز',
    'Atlantic/Bermuda' => 'اقیانوس اطلس / برمودا',
    'America/Cayman' => 'آمریکا/کیمن',
    'America/Costa_Rica' => 'آمریکا / کاستاریکا',
    'America/Havana' => 'آمریکا/هاوانا',
    'America/Dominica' => 'آمریکا/دومینیکا',
    'America/Santo_Domingo' => 'آمریکا/سانتو دومینگو',
    'America/El_Salvador' => 'آمریکا/السالوادور',
    'America/Grenada' => 'آمریکا/گرنادا',
    'America/Guadeloupe' => 'آمریکا/گوادلوپ',
    'America/Guatemala' => 'آمریکا/گواتمالا',
    'America/Port-au-Prince' => 'آمریکا / پورت او پرنس',
    'America/Tegucigalpa' => 'آمریکا/تگوسیگالپا',
    'America/Jamaica' => 'آمریکا/جامائیکا',
    'America/Martinique' => 'آمریکا/مارتینیک',
    'America/Montserrat' => 'آمریکا/مونتسرات',
    'America/Managua' => 'آمریکا / ماناگوا',
    'America/Panama' => 'آمریکا / پاناما',
    'America/Puerto_Rico' => 'آمریکا/پورتوریکو',
    'America/St_Kitts' => 'آمریکا/سنت کیتس',
    'America/St_Lucia' => 'آمریکا/سنت لوسیا',
    'America/Miquelon' => 'آمریکا/میکلون',
    'America/St_Vincent' => 'آمریکا/سنت وینسنت',
    'America/Grand_Turk' => 'آمریکا/گرند ترک',
    'America/Tortola' => 'آمریکا/تورتولا',
    'America/St_Thomas' => 'آمریکا/سنت توماس',
    'America/Argentina/Buenos_Aires' => 'آمریکا/آرژانتین/بوئنوس آیرس',
    'America/Argentina/Cordoba' => 'آمریکا / آرژانتین / کوردوبا',
    'America/Argentina/Tucuman' => 'آمریکا/آرژانتین/توکومان',
    'America/Argentina/La_Rioja' => 'آمریکا/آرژانتین/لاریخا',
    'America/Argentina/San_Juan' => 'آمریکا/آرژانتین/سان_خوان',
    'America/Argentina/Jujuy' => 'آمریکا/آرژانتین/جوجوی',
    'America/Argentina/Catamarca' => 'آمریکا/آرژانتین/کاتامارکا',
    'America/Argentina/Mendoza' => 'آمریکا / آرژانتین / مندوزا',
    'America/Argentina/Rio_Gallegos' => 'آمریکا/آرژانتین/ریو گالگوس',
    'America/Argentina/Ushuaia' => 'آمریکا/آرژانتین/اوشوآیا',
    'America/Aruba' => 'آمریکا/آروبا',
    'America/La_Paz' => 'آمریکا/لاپاز',
    'America/Noronha' => 'آمریکا/نورونها',
    'America/Belem' => 'آمریکا/بلم',
    'America/Fortaleza' => 'آمریکا/فورتالزا',
    'America/Recife' => 'آمریکا/رسیف',
    'America/Araguaina' => 'آمریکا/آراگواینا',
    'America/Maceio' => 'آمریکا/ماکیو',
    'America/Bahia' => 'امریکا/باهیا',
    'America/Sao_Paulo' => 'آمریکا/سائوپائولو',
    'America/Campo_Grande' => 'آمریکا/کامپو گرانده',
    'America/Cuiaba' => 'آمریکا/کویابا',
    'America/Porto_Velho' => 'آمریکا/پورتو_ولهو',
    'America/Boa_Vista' => 'آمریکا/بوآ ویستا',
    'America/Manaus' => 'آمریکا/مانائوس',
    'America/Eirunepe' => 'آمریکا/ایرونپه',
    'America/Rio_Branco' => 'آمریکا/ریو برانکو',
    'America/Santiago' => 'آمریکا/سانتیاگو',
    'Pacific/Easter' => 'اقیانوس آرام / عید پاک',
    'America/Bogota' => 'آمریکا/بوگوتا',
    'America/Curacao' => 'آمریکا/کوراکائو',
    'America/Guayaquil' => 'آمریکا/گوایاکیل',
    'Pacific/Galapagos' => 'اقیانوس آرام/گالاپاگوس',
    'Atlantic/Stanley' => 'آتلانتیک/استنلی',
    'America/Cayenne' => 'آمریکا/کاین',
    'America/Guyana' => 'آمریکا/گویان',
    'America/Asuncion' => 'آمریکا/آسونسیون',
    'America/Lima' => 'آمریکا/لیما',
    'Atlantic/South_Georgia' => 'اقیانوس اطلس / جورجیا جنوبی',
    'America/Paramaribo' => 'آمریکا/پاراماریبو',
    'America/Port_of_Spain' => 'آمریکا / بندر اسپانیا',
    'America/Montevideo' => 'آمریکا/مونته ویدئو',
    'America/Caracas' => 'آمریکا/کاراکاس',
);

$app_list_strings['eapm_list'] = array(
    'Sugar' => 'SuiteCRM',
    'WebEx' => 'WebEx',
    'GoToMeeting' => 'برو به جلسه',
    'IBMSmartCloud' => 'IBM SmartCloud',
    'Google' => 'گوگل',
    'Box' => 'Box.net',
    'Facebook' => 'فیس‌بوک',
    'Twitter' => 'توییتر',
);
$app_list_strings['eapm_list_import'] = array(
    'Google' => 'Google Contacts',
);
$app_list_strings['eapm_list_documents'] = array(
    'Google' => 'Google Drive',
);
$app_list_strings['token_status'] = array(
    1 => 'درخواست',
    2 => 'دسترسی',
    3 => 'نامعتبر',
);

$app_list_strings ['emailTemplates_type_list'] = array(
    '' => '',
    'campaign' => 'کمپین',
    'email' => 'ایمیل',
    'event' => 'رویداد',
);

$app_list_strings ['emailTemplates_type_list_campaigns'] = array(
    '' => '',
    'campaign' => 'کمپین',
);

$app_list_strings ['emailTemplates_type_list_no_workflow'] = array(
    '' => '',
    'campaign' => 'کمپین',
    'email' => 'ایمیل',
    'event' => 'رویداد',
    'system' => 'سیستم',
);

// knowledge base
$app_list_strings['moduleList']['AOK_KnowledgeBase'] = 'دانش بنیان';
$app_list_strings['moduleList']['AOK_Knowledge_Base_Categories'] = 'KB - دسته بندی ها';
$app_list_strings['aok_status_list']['Draft'] = 'پیش‌نویس';
$app_list_strings['aok_status_list']['Expired'] = 'منقضی شده';
$app_list_strings['aok_status_list']['In_Review'] = 'در حال بررسی';
//$app_list_strings['aok_status_list']['Published'] = 'Published';
$app_list_strings['aok_status_list']['published_private'] = 'خصوصی';
$app_list_strings['aok_status_list']['published_public'] = 'عمومی';

$app_list_strings['moduleList']['FP_events'] = 'رویدادها';
$app_list_strings['moduleList']['FP_Event_Locations'] = 'مکان‌ها';

//events
$app_list_strings['fp_event_invite_status_dom']['Invited'] = 'دعوت‌شده';
$app_list_strings['fp_event_invite_status_dom']['Not Invited'] = 'دعوت‌نشده';
$app_list_strings['fp_event_invite_status_dom']['Attended'] = 'شرکت‌کرده';
$app_list_strings['fp_event_invite_status_dom']['Not Attended'] = 'شرکت‌نکرده';
$app_list_strings['fp_event_status_dom']['Accepted'] = 'پذیرفته‌شده';
$app_list_strings['fp_event_status_dom']['Declined'] = 'رد شده';
$app_list_strings['fp_event_status_dom']['No Response'] = 'بدون پاسخ';

$app_strings['LBL_STATUS_EVENT'] = 'وضعیت دعوت';
$app_strings['LBL_ACCEPT_STATUS'] = 'وضعیت پذیرش';
$app_strings['LBL_LISTVIEW_OPTION_CURRENT'] = 'این صفحه را انتخاب کنید';
$app_strings['LBL_LISTVIEW_OPTION_ENTIRE'] = 'انتخاب همه';
$app_strings['LBL_LISTVIEW_NONE'] = 'عدم انتخاب همه';

$app_list_strings['moduleList']['AOP_Case_Events'] = 'رویدادهای خدمات';
$app_list_strings['moduleList']['AOP_Case_Updates'] = 'تغییرات خدمات';
$app_strings['LBL_AOP_EMAIL_REPLY_DELIMITER'] = '========== لطفا بالای این خدمت پاسخ دهید ==========';

//aop
$app_list_strings['case_state_default_key'] = 'Open';
$app_list_strings['case_state_dom'] =
    array(
        'Open' => 'باز',
        'Closed' => 'بسته',
    );
$app_list_strings['case_status_default_key'] = 'Open_New';
$app_list_strings['case_status_dom'] =
    array(
        'Open_New' => 'جدید',
        'Open_Assigned' => 'محول شده',
        'Closed_Closed' => 'بسته',
        'Open_Pending Input' => 'منتظر ورودی',
        'Closed_Rejected' => 'رد شده',
        'Closed_Duplicate' => 'تکراری',
    );
$app_list_strings['contact_portal_user_type_dom'] =
    array(
        'Single' => 'تک کاربره',
        'Account' => 'کاربر حساب',
    );
$app_list_strings['dom_email_distribution_for_auto_create'] = array(
    'AOPDefault' => 'پیشفرض سیستم',
    'singleUser' => 'تک کاربره',
    'roundRobin' => 'درخواست کتبی',
    'leastBusy' => 'کم مشغله',
    'random' => 'تصادفی',
);

//aor
$app_list_strings['moduleList']['AOR_Reports'] = 'گزارش‌ها';
$app_list_strings['moduleList']['AOR_Conditions'] = 'شرایط گزارش';
$app_list_strings['moduleList']['AOR_Charts'] = 'نمودارهای گزارش';
$app_list_strings['moduleList']['AOR_Fields'] = 'زمینه‌های گزارش';
$app_list_strings['moduleList']['AOR_Scheduled_Reports'] = 'گزارش‌های برنامه‌ریزی‌شده';
$app_list_strings['aor_operator_list']['Equal_To'] = 'برابر با';
$app_list_strings['aor_operator_list']['Not_Equal_To'] = 'مخالف';
$app_list_strings['aor_operator_list']['Greater_Than'] = 'بزرگ‌تر از';
$app_list_strings['aor_operator_list']['Less_Than'] = 'کوچک‌تر از';
$app_list_strings['aor_operator_list']['Greater_Than_or_Equal_To'] = 'بزرگ‌تر یا برابر با';
$app_list_strings['aor_operator_list']['Less_Than_or_Equal_To'] = 'کوچک‌تر یا برابر با';
$app_list_strings['aor_operator_list']['Contains'] = 'شامل';
$app_list_strings['aor_operator_list']['Starts_With'] = 'شروع می‌شود با';
$app_list_strings['aor_operator_list']['Ends_With'] = 'پایان می‌یابد با';
$app_list_strings['aor_format_options'][''] = '';
$app_list_strings['aor_format_options']['Y-m-d'] = 'Y-m-d';
$app_list_strings['aor_format_options']['m-d-Y'] = 'm-d-Y';
$app_list_strings['aor_format_options']['d-m-Y'] = 'd-m-Y';
$app_list_strings['aor_format_options']['Y/m/d'] = 'Y/m/d';
$app_list_strings['aor_format_options']['m/d/Y'] = 'm/d/Y';
$app_list_strings['aor_format_options']['d/m/Y'] = 'd/m/Y';
$app_list_strings['aor_format_options']['Y.m.d'] = 'Y.m.d';
$app_list_strings['aor_format_options']['m.d.Y'] = 'm.d.Y';
$app_list_strings['aor_format_options']['d.m.Y'] = 'd.m.Y';
$app_list_strings['aor_format_options']['Ymd'] = 'Ymd';
$app_list_strings['aor_format_options']['Y-m'] = 'Y-m';
$app_list_strings['aor_format_options']['Y'] = 'Y';
$app_list_strings['aor_condition_operator_list']['And'] = 'و';
$app_list_strings['aor_condition_operator_list']['OR'] = 'یا';
$app_list_strings['aor_condition_type_list']['Value'] = 'مقدار';
$app_list_strings['aor_condition_type_list']['Field'] = 'فیلد';
$app_list_strings['aor_condition_type_list']['Date'] = 'تاریخ';
$app_list_strings['aor_condition_type_list']['Multi'] = 'یکی از';
$app_list_strings['aor_condition_type_list']['Period'] = 'دوره';
$app_list_strings['aor_condition_type_list']['CurrentUserID'] = 'کاربر فعلی';
$app_list_strings['aor_date_type_list'][''] = '';
$app_list_strings['aor_date_type_list']['minute'] = 'دقیقه';
$app_list_strings['aor_date_type_list']['hour'] = 'ساعت';
$app_list_strings['aor_date_type_list']['day'] = 'روز';
$app_list_strings['aor_date_type_list']['week'] = 'هفته';
$app_list_strings['aor_date_type_list']['month'] = 'ماه';
$app_list_strings['aor_date_type_list']['business_hours'] = 'ساعت کاری';
$app_list_strings['aor_date_options']['now'] = 'اکنون';
$app_list_strings['aor_date_options']['field'] = 'این فیلد';
$app_list_strings['aor_date_operator']['now'] = '';
$app_list_strings['aor_date_operator']['plus'] = '+';
$app_list_strings['aor_date_operator']['minus'] = '-';
$app_list_strings['aor_sort_operator'][''] = '';
$app_list_strings['aor_sort_operator']['ASC'] = 'صعودی';
$app_list_strings['aor_sort_operator']['DESC'] = 'نزولی';
$app_list_strings['aor_function_list'][''] = '';
$app_list_strings['aor_function_list']['COUNT'] = 'تعداد';
$app_list_strings['aor_function_list']['MIN'] = 'کمترین';
$app_list_strings['aor_function_list']['MAX'] = 'بیشترین';
$app_list_strings['aor_function_list']['SUM'] = 'مجموع';
$app_list_strings['aor_function_list']['AVG'] = 'میانگین';
$app_list_strings['aor_total_options'][''] = '';
$app_list_strings['aor_total_options']['COUNT'] = 'تعداد';
$app_list_strings['aor_total_options']['SUM'] = 'مجموع';
$app_list_strings['aor_total_options']['AVG'] = 'میانگین';
$app_list_strings['aor_chart_types']['bar'] = 'نمودار میله‌ای';
$app_list_strings['aor_chart_types']['line'] = 'نمودار خطی';
$app_list_strings['aor_chart_types']['pie'] = 'نمودار دایره‌ای';
$app_list_strings['aor_chart_types']['radar'] = 'نمودار راداری';
$app_list_strings['aor_chart_types']['stacked_bar'] = 'میله‌ای ِ انباشه';
$app_list_strings['aor_chart_types']['grouped_bar'] = 'میله‌ای گروه‌بندی شده';
$app_list_strings['aor_scheduled_report_schedule_types']['monthly'] = 'ماهیانه';
$app_list_strings['aor_scheduled_report_schedule_types']['weekly'] = 'هفتگی';
$app_list_strings['aor_scheduled_report_schedule_types']['daily'] = 'روزانه';
$app_list_strings['aor_scheduled_reports_status_dom']['active'] = 'فعال';
$app_list_strings['aor_scheduled_reports_status_dom']['inactive'] = 'غیرفعال';
$app_list_strings['aor_email_type_list']['Email Address'] = 'ایمیل';
$app_list_strings['aor_email_type_list']['Specify User'] = 'کاربر';
$app_list_strings['aor_email_type_list']['Users'] = 'کاربرها';
$app_list_strings['aor_assign_options']['all'] = 'همه‌ کاربرها';
$app_list_strings['aor_assign_options']['role'] = 'همه کاربرها با این نقش';
$app_list_strings['aor_assign_options']['security_group'] = 'تمام کاربرها در گروه امنیتی';
$app_list_strings['date_time_period_list']['today'] = 'امروز';
$app_list_strings['date_time_period_list']['yesterday'] = 'دیروز';
$app_list_strings['date_time_period_list']['this_week'] = 'این هفته';
$app_list_strings['date_time_period_list']['last_week'] = 'هفته گذشته';
$app_list_strings['date_time_period_list']['last_month'] = 'ماه گذشته';
$app_list_strings['date_time_period_list']['this_month'] = 'این ماه';
$app_list_strings['date_time_period_list']['this_quarter'] = 'این فصل';
$app_list_strings['date_time_period_list']['last_quarter'] = 'سه ماهه گذشته';
$app_list_strings['date_time_period_list']['this_year'] = 'امسال';
$app_list_strings['date_time_period_list']['last_year'] = 'سال گذشته';
$app_strings['LBL_CRON_ON_THE_MONTHDAY'] = 'در';
$app_strings['LBL_CRON_ON_THE_WEEKDAY'] = 'در';
$app_strings['LBL_CRON_AT'] = 'در';
$app_strings['LBL_CRON_RAW'] = 'پیشرفته';
$app_strings['LBL_CRON_MIN'] = 'دقیقه';
$app_strings['LBL_CRON_HOUR'] = 'ساعت';
$app_strings['LBL_CRON_DAY'] = 'روز';
$app_strings['LBL_CRON_MONTH'] = 'ماه';
$app_strings['LBL_CRON_DOW'] = 'روزِ هفته';
$app_strings['LBL_CRON_DAILY'] = 'روزانه';
$app_strings['LBL_CRON_WEEKLY'] = 'هفتگی';
$app_strings['LBL_CRON_MONTHLY'] = 'ماهیانه';

//aos
$app_list_strings['moduleList']['AOS_Contracts'] = 'قراردادها';
$app_list_strings['moduleList']['AOS_Invoices'] = 'صورت‌حساب‌ها';
$app_list_strings['moduleList']['AOS_PDF_Templates'] = 'PDF - نمونه';
$app_list_strings['moduleList']['AOS_Product_Categories'] = 'محصول - دسته بندی ها';
$app_list_strings['moduleList']['AOS_Products'] = 'محصولات';
$app_list_strings['moduleList']['AOS_Products_Quotes'] = 'آیتم های خط';
$app_list_strings['moduleList']['AOS_Line_Item_Groups'] = 'گروه‌های موارد';
$app_list_strings['moduleList']['AOS_Quotes'] = 'پیش‌فاکتورها';
$app_list_strings['aos_quotes_type_dom'][''] = '';
$app_list_strings['aos_quotes_type_dom']['Analyst'] = 'تحلیل‌گر';
$app_list_strings['aos_quotes_type_dom']['Competitor'] = 'رقیب';
$app_list_strings['aos_quotes_type_dom']['Customer'] = 'مشتری';
$app_list_strings['aos_quotes_type_dom']['Integrator'] = 'تلفیق کننده';
$app_list_strings['aos_quotes_type_dom']['Investor'] = 'سرمایه‌گذار';
$app_list_strings['aos_quotes_type_dom']['Partner'] = 'شریک';
$app_list_strings['aos_quotes_type_dom']['Press'] = 'مطبوعات';
$app_list_strings['aos_quotes_type_dom']['Prospect'] = 'مشتری بالقوه';
$app_list_strings['aos_quotes_type_dom']['Reseller'] = 'نماینده‌ی فروش';
$app_list_strings['aos_quotes_type_dom']['Other'] = 'سایر';
$app_list_strings['template_ddown_c_list'][''] = '';
$app_list_strings['quote_stage_dom']['Draft'] = 'پیش‌نویس';
$app_list_strings['quote_stage_dom']['Negotiation'] = 'مذاکره';
$app_list_strings['quote_stage_dom']['Delivered'] = 'تحویل‌شده';
$app_list_strings['quote_stage_dom']['On Hold'] = 'در انتظار';
$app_list_strings['quote_stage_dom']['Confirmed'] = 'تأیید شده';
$app_list_strings['quote_stage_dom']['Closed Accepted'] = 'بسته و پذیرفته شده';
$app_list_strings['quote_stage_dom']['Closed Lost'] = 'بسته از دست‌رفته';
$app_list_strings['quote_stage_dom']['Closed Dead'] = 'بسته و از بین‌رفته';
$app_list_strings['quote_term_dom']['Net 15'] = 'نقدی 15 روزه';
$app_list_strings['quote_term_dom']['Net 30'] = 'نقدی 30 روزه';
$app_list_strings['quote_term_dom'][''] = '';
$app_list_strings['approval_status_dom']['Approved'] = 'تأیید شده';
$app_list_strings['approval_status_dom']['Not Approved'] = 'تأیید نشده';
$app_list_strings['approval_status_dom'][''] = '';
$app_list_strings['vat_list']['0.0'] = '0%';
$app_list_strings['vat_list']['5.0'] = '5%';
$app_list_strings['vat_list']['7.5'] = '7.5%';
$app_list_strings['vat_list']['17.5'] = '17.5%';
$app_list_strings['vat_list']['20.0'] = '20%';
$app_list_strings['discount_list']['Percentage'] = 'درصد';
$app_list_strings['discount_list']['Amount'] = 'مقدار';
$app_list_strings['aos_invoices_type_dom'][''] = '';
$app_list_strings['aos_invoices_type_dom']['Analyst'] = 'تحلیل‌گر';
$app_list_strings['aos_invoices_type_dom']['Competitor'] = 'رقیب';
$app_list_strings['aos_invoices_type_dom']['Customer'] = 'مشتری';
$app_list_strings['aos_invoices_type_dom']['Integrator'] = 'تلفیق کننده';
$app_list_strings['aos_invoices_type_dom']['Investor'] = 'سرمایه‌گذار';
$app_list_strings['aos_invoices_type_dom']['Partner'] = 'شریک';
$app_list_strings['aos_invoices_type_dom']['Press'] = 'مطبوعات';
$app_list_strings['aos_invoices_type_dom']['Prospect'] = 'مشتری بالقوه';
$app_list_strings['aos_invoices_type_dom']['Reseller'] = 'نماینده‌ی فروش';
$app_list_strings['aos_invoices_type_dom']['Other'] = 'سایر';
$app_list_strings['invoice_status_dom']['Paid'] = 'پرداخت شده';
$app_list_strings['invoice_status_dom']['Unpaid'] = 'پرداخت نشده';
$app_list_strings['invoice_status_dom']['Cancelled'] = 'لغو شده';
$app_list_strings['invoice_status_dom'][''] = '';
$app_list_strings['quote_invoice_status_dom']['Not Invoiced'] = 'فاکتور نشده';
$app_list_strings['quote_invoice_status_dom']['Invoiced'] = 'فاکتور شده';
$app_list_strings['product_code_dom']['XXXX'] = 'XXXX';
$app_list_strings['product_code_dom']['YYYY'] = 'YYYY';
$app_list_strings['product_category_dom']['Laptops'] = 'لپ‌تاپ';
$app_list_strings['product_category_dom']['Desktops'] = 'کامپیوتر رومیزی';
$app_list_strings['product_category_dom'][''] = '';
$app_list_strings['product_type_dom']['Good'] = 'کالا';
$app_list_strings['product_type_dom']['Service'] = 'خدمات';
$app_list_strings['product_quote_parent_type_dom']['AOS_Quotes'] = 'پیش‌فاکتورها';
$app_list_strings['product_quote_parent_type_dom']['AOS_Invoices'] = 'صورت‌حساب‌ها';
$app_list_strings['product_quote_parent_type_dom']['AOS_Contracts'] = 'قراردادها';
$app_list_strings['pdf_template_type_dom']['AOS_Quotes'] = 'پیش‌فاکتورها';
$app_list_strings['pdf_template_type_dom']['AOS_Invoices'] = 'صورت‌حساب‌ها';
$app_list_strings['pdf_template_type_dom']['AOS_Contracts'] = 'قراردادها';
$app_list_strings['pdf_template_type_dom']['Accounts'] = 'حساب‌ها';
$app_list_strings['pdf_template_type_dom']['Contacts'] = 'مخاطب‌ها';
$app_list_strings['pdf_template_type_dom']['Leads'] = 'سرنخ‌ها';
$app_list_strings['pdf_template_sample_dom'][''] = '';
$app_list_strings['contract_status_list']['Not Started'] = 'شروع نشده';
$app_list_strings['contract_status_list']['In Progress'] = 'در حال پردازش';
$app_list_strings['contract_status_list']['Signed'] = 'امضاء شده';
$app_list_strings['contract_type_list']['Type'] = 'نوع';
$app_strings['LBL_PRINT_AS_PDF'] = 'چاپ به صورت PDF';
$app_strings['LBL_SELECT_TEMPLATE'] = 'لطفا یک قالب انتخاب کنید';
$app_strings['LBL_NO_TEMPLATE'] = 'خطا\n
هیچ قالبی یافت نشد.\n
لطفاً به ماژول قالب PDF مراجعه نموده و یک قالب بسازید';

//aow
$app_list_strings['moduleList']['AOW_WorkFlow'] = 'گردش کار';
$app_list_strings['moduleList']['AOW_Conditions'] = 'شرايط گردش کار';
$app_list_strings['moduleList']['AOW_Processed'] = 'فرایند ممیزی';
$app_list_strings['moduleList']['AOW_Actions'] = 'اقدامات گردش کار';
$app_list_strings['aow_status_list']['Active'] = 'فعال';
$app_list_strings['aow_status_list']['Inactive'] = 'غیرفعال';
$app_list_strings['aow_operator_list']['Equal_To'] = 'برابر با';
$app_list_strings['aow_operator_list']['Not_Equal_To'] = 'مخالف';
$app_list_strings['aow_operator_list']['Greater_Than'] = 'بزرگ‌تر از';
$app_list_strings['aow_operator_list']['Less_Than'] = 'کوچک‌تر از';
$app_list_strings['aow_operator_list']['Greater_Than_or_Equal_To'] = 'بزرگ‌تر یا برابر با';
$app_list_strings['aow_operator_list']['Less_Than_or_Equal_To'] = 'کوچک‌تر یا برابر با';
$app_list_strings['aow_operator_list']['Contains'] = 'شامل';
$app_list_strings['aow_operator_list']['Starts_With'] = 'شروع می‌شود با';
$app_list_strings['aow_operator_list']['Ends_With'] = 'پایان می‌یابد با';
$app_list_strings['aow_operator_list']['is_null'] = 'Null است';
$app_list_strings['aow_process_status_list']['Complete'] = 'تکمیل';
$app_list_strings['aow_process_status_list']['Running'] = 'در حال اجرا';
$app_list_strings['aow_process_status_list']['Pending'] = 'در انتظار';
$app_list_strings['aow_process_status_list']['Failed'] = 'ناموفق';
$app_list_strings['aow_condition_operator_list']['And'] = 'و';
$app_list_strings['aow_condition_operator_list']['OR'] = 'یا';
$app_list_strings['aow_condition_type_list']['Value'] = 'مقدار';
$app_list_strings['aow_condition_type_list']['Field'] = 'فیلد';
$app_list_strings['aow_condition_type_list']['Any_Change'] = 'هرگونه تغییر';
$app_list_strings['aow_condition_type_list']['SecurityGroup'] = 'در گروه امنیتی';
$app_list_strings['aow_condition_type_list']['Date'] = 'تاریخ';
$app_list_strings['aow_condition_type_list']['Multi'] = 'یکی از';
$app_list_strings['aow_action_type_list']['Value'] = 'مقدار';
$app_list_strings['aow_action_type_list']['Field'] = 'فیلد';
$app_list_strings['aow_action_type_list']['Date'] = 'تاریخ';
$app_list_strings['aow_action_type_list']['Round_Robin'] = 'درخواست کتبی';
$app_list_strings['aow_action_type_list']['Least_Busy'] = 'کم مشغله‌ترین';
$app_list_strings['aow_action_type_list']['Random'] = 'تصادفی';
$app_list_strings['aow_rel_action_type_list']['Value'] = 'مقدار';
$app_list_strings['aow_rel_action_type_list']['Field'] = 'فیلد';
$app_list_strings['aow_date_type_list'][''] = '';
$app_list_strings['aow_date_type_list']['minute'] = 'دقیقه';
$app_list_strings['aow_date_type_list']['hour'] = 'ساعت';
$app_list_strings['aow_date_type_list']['day'] = 'روز';
$app_list_strings['aow_date_type_list']['week'] = 'هفته';
$app_list_strings['aow_date_type_list']['month'] = 'ماه';
$app_list_strings['aow_date_type_list']['year'] = 'سال ها';
$app_list_strings['aow_date_type_list']['business_hours'] = 'ساعات کاری';
$app_list_strings['aow_date_options']['now'] = 'اکنون';
$app_list_strings['aow_date_options']['today'] = 'امروز';
$app_list_strings['aow_date_options']['field'] = 'این فیلد';
$app_list_strings['aow_date_operator']['now'] = '';
$app_list_strings['aow_date_operator']['plus'] = '+';
$app_list_strings['aow_date_operator']['minus'] = '-';
$app_list_strings['aow_assign_options']['all'] = 'همه کاربرها';
$app_list_strings['aow_assign_options']['role'] = 'همه کاربرها با این نقش';
$app_list_strings['aow_assign_options']['security_group'] = 'تمام کاربرها در گروه امنیتی';
$app_list_strings['aow_email_type_list']['Email Address'] = 'ایمیل';
$app_list_strings['aow_email_type_list']['Record Email'] = 'ثبت نامه الکترونیک';
$app_list_strings['aow_email_type_list']['Related Field'] = 'فیلدهای مرتبط';
$app_list_strings['aow_email_type_list']['Specify User'] = 'کاربر';
$app_list_strings['aow_email_type_list']['Users'] = 'کاربرها';
$app_list_strings['aow_email_to_list']['to'] = 'گیرنده';
$app_list_strings['aow_email_to_list']['cc'] = 'رونوشت';
$app_list_strings['aow_email_to_list']['bcc'] = 'رونوشت مخفی';
$app_list_strings['aow_run_on_list']['All_Records'] = 'همه رکوردها';
$app_list_strings['aow_run_on_list']['New_Records'] = 'رکوردهای جدید';
$app_list_strings['aow_run_on_list']['Modified_Records'] = 'رکوردهای اصلاح‌شده';
$app_list_strings['aow_run_when_list']['Always'] = 'همیشه';
$app_list_strings['aow_run_when_list']['On_Save'] = 'تنها هنگام ذخیره';
$app_list_strings['aow_run_when_list']['In_Scheduler'] = 'تنها در برنامه زمان‌بندی';

//gant
$app_list_strings['moduleList']['AM_ProjectTemplates'] = 'پروژه ها - قالب ها';
$app_list_strings['moduleList']['AM_TaskTemplates'] = 'قالب‌های وظیفه پروژه';
$app_list_strings['relationship_type_list']['FS'] = 'از پایان تا شروع';
$app_list_strings['relationship_type_list']['SS'] = 'از شروع تا شروع';
$app_list_strings['duration_unit_dom']['Days'] = 'روز';
$app_list_strings['duration_unit_dom']['Hours'] = 'ساعت';
$app_strings['LBL_GANTT_BUTTON_LABEL'] = 'نمای Gantt';
$app_strings['LBL_DETAIL_BUTTON_LABEL'] = 'نمایش جزئیات';
$app_strings['LBL_CREATE_PROJECT'] = 'ایجاد پروژه';

//gmaps
$app_strings['LBL_MAP'] = 'نقشه';

$app_strings['LBL_JJWG_MAPS_LNG'] = 'طول جغرافیایی';
$app_strings['LBL_JJWG_MAPS_LAT'] = 'عرض جغرافیایی';
$app_strings['LBL_JJWG_MAPS_GEOCODE_STATUS'] = 'وضعیت Geocode';
$app_strings['LBL_JJWG_MAPS_ADDRESS'] = 'آدرس';

$app_list_strings['moduleList']['jjwg_Maps'] = 'نقشه‌ها';
$app_list_strings['moduleList']['jjwg_Markers'] = 'نقشه ها - نشانگرها';
$app_list_strings['moduleList']['jjwg_Areas'] = 'نقشه ها - مناطق';
$app_list_strings['moduleList']['jjwg_Address_Cache'] = 'نقشه ها - حافظه پنهان آدرس';

$app_list_strings['moduleList']['jjwp_Partners'] = 'JJWP Partners';

$app_list_strings['map_unit_type_list']['mi'] = 'مایل';
$app_list_strings['map_unit_type_list']['km'] = 'کیلومتر';

$app_list_strings['map_module_type_list']['Accounts'] = 'حساب ها';
$app_list_strings['map_module_type_list']['Contacts'] = 'مخاطب‌ها';
$app_list_strings['map_module_type_list']['Cases'] = 'خدمات';
$app_list_strings['map_module_type_list']['Leads'] = 'سرنخ‌ها';
$app_list_strings['map_module_type_list']['Meetings'] = 'جلسه‌ها';
$app_list_strings['map_module_type_list']['Opportunities'] = 'فرصت‌ها';
$app_list_strings['map_module_type_list']['Project'] = 'پروژه‌ها';
$app_list_strings['map_module_type_list']['Prospects'] = 'اهداف';

$app_list_strings['map_relate_type_list']['Accounts'] = 'حساب';
$app_list_strings['map_relate_type_list']['Contacts'] = 'مخاطب';
$app_list_strings['map_relate_type_list']['Cases'] = 'خدمات';
$app_list_strings['map_relate_type_list']['Leads'] = 'سرنخ';
$app_list_strings['map_relate_type_list']['Meetings'] = 'جلسه';
$app_list_strings['map_relate_type_list']['Opportunities'] = 'فرصت';
$app_list_strings['map_relate_type_list']['Project'] = 'پروژه';
$app_list_strings['map_relate_type_list']['Prospects'] = 'هدف';

$app_list_strings['marker_image_list']['accident'] = 'حادثه';
$app_list_strings['marker_image_list']['administration'] = 'مدیریت';
$app_list_strings['marker_image_list']['agriculture'] = 'کشاورزی';
$app_list_strings['marker_image_list']['aircraft_small'] = 'هواپیمای کوچک';
$app_list_strings['marker_image_list']['airplane_tourism'] = 'هواپیمای گردشگری';
$app_list_strings['marker_image_list']['airport'] = 'فرودگاه';
$app_list_strings['marker_image_list']['amphitheater'] = 'آمفی تئاتر';
$app_list_strings['marker_image_list']['apartment'] = 'آپارتمان';
$app_list_strings['marker_image_list']['aquarium'] = 'آکواریوم';
$app_list_strings['marker_image_list']['arch'] = 'قوس';
$app_list_strings['marker_image_list']['atm'] = 'دستگاه های خودپرداز';
$app_list_strings['marker_image_list']['audio'] = 'صوت';
$app_list_strings['marker_image_list']['bank'] = 'بانک';
$app_list_strings['marker_image_list']['bank_euro'] = 'بانک یورو';
$app_list_strings['marker_image_list']['bank_pound'] = 'بانک پوند';
$app_list_strings['marker_image_list']['bar'] = 'بار';
$app_list_strings['marker_image_list']['beach'] = 'ساحل';
$app_list_strings['marker_image_list']['beautiful'] = 'زیبا';
$app_list_strings['marker_image_list']['bicycle_parking'] = 'پارکینگ دوچرخه';
$app_list_strings['marker_image_list']['big_city'] = 'شهر بزرگ';
$app_list_strings['marker_image_list']['bridge'] = 'پل';
$app_list_strings['marker_image_list']['bridge_modern'] = 'پل مدرن';
$app_list_strings['marker_image_list']['bus'] = 'اتوبوس';
$app_list_strings['marker_image_list']['cable_car'] = 'خودروی کابلی';
$app_list_strings['marker_image_list']['car'] = 'خودرو';
$app_list_strings['marker_image_list']['car_rental'] = 'اجاره خودرو';
$app_list_strings['marker_image_list']['carrepair'] = 'تعمیر خودرو';
$app_list_strings['marker_image_list']['castle'] = 'قلعه';
$app_list_strings['marker_image_list']['cathedral'] = 'کلیسای جامع';
$app_list_strings['marker_image_list']['chapel'] = 'نمازخانه';
$app_list_strings['marker_image_list']['church'] = 'کلیسا';
$app_list_strings['marker_image_list']['city_square'] = 'میدان شهر';
$app_list_strings['marker_image_list']['cluster'] = 'خوشه';
$app_list_strings['marker_image_list']['cluster_2'] = 'خوشه 2';
$app_list_strings['marker_image_list']['cluster_3'] = 'خوشه 3';
$app_list_strings['marker_image_list']['cluster_4'] = 'خوشه 4';
$app_list_strings['marker_image_list']['cluster_5'] = 'خوشه 5';
$app_list_strings['marker_image_list']['coffee'] = 'قهوه';
$app_list_strings['marker_image_list']['community_centre'] = 'مرکز انجمن';
$app_list_strings['marker_image_list']['company'] = 'شرکت';
$app_list_strings['marker_image_list']['conference'] = 'کنفرانس';
$app_list_strings['marker_image_list']['construction'] = 'ساخت و ساز';
$app_list_strings['marker_image_list']['convenience'] = 'راحتی';
$app_list_strings['marker_image_list']['court'] = 'دادگاه';
$app_list_strings['marker_image_list']['cruise'] = 'کشتی مسافری';
$app_list_strings['marker_image_list']['currency_exchange'] = 'تبادل ارز';
$app_list_strings['marker_image_list']['customs'] = 'گمرک';
$app_list_strings['marker_image_list']['cycling'] = 'دوچرخه سواری';
$app_list_strings['marker_image_list']['dam'] = 'سد';
$app_list_strings['marker_image_list']['dentist'] = 'دندانپزشک';
$app_list_strings['marker_image_list']['deptartment_store'] = 'فروشگاه بزرگ';
$app_list_strings['marker_image_list']['disability'] = 'ناتوانی';
$app_list_strings['marker_image_list']['disabled_parking'] = 'پارکینگ معلولین';
$app_list_strings['marker_image_list']['doctor'] = 'دکتر';
$app_list_strings['marker_image_list']['dog_leash'] = 'قلاده سگ';
$app_list_strings['marker_image_list']['down'] = 'پایین';
$app_list_strings['marker_image_list']['down_left'] = 'پایین چپ';
$app_list_strings['marker_image_list']['down_right'] = 'پایین راست';
$app_list_strings['marker_image_list']['down_then_left'] = 'پایین بعد چپ';
$app_list_strings['marker_image_list']['down_then_right'] = 'پایین بعد راست';
$app_list_strings['marker_image_list']['drugs'] = 'مواد مخدر';
$app_list_strings['marker_image_list']['elevator'] = 'آسانسور';
$app_list_strings['marker_image_list']['embassy'] = 'سفارت';
$app_list_strings['marker_image_list']['expert'] = 'کارشناس';
$app_list_strings['marker_image_list']['factory'] = 'کارخانه';
$app_list_strings['marker_image_list']['falling_rocks'] = 'سنگ در حال سقوط';
$app_list_strings['marker_image_list']['fast_food'] = 'فست فود';
$app_list_strings['marker_image_list']['festival'] = 'جشنواره';
$app_list_strings['marker_image_list']['fjord'] = 'Fjord';
$app_list_strings['marker_image_list']['forest'] = 'جنگل';
$app_list_strings['marker_image_list']['fountain'] = 'فواره';
$app_list_strings['marker_image_list']['friday'] = 'جمعه';
$app_list_strings['marker_image_list']['garden'] = 'باغ';
$app_list_strings['marker_image_list']['gas_station'] = 'پمپ بنزین';
$app_list_strings['marker_image_list']['geyser'] = 'چشمه اب گرم';
$app_list_strings['marker_image_list']['gifts'] = 'هدایا';
$app_list_strings['marker_image_list']['gourmet'] = 'خوراک شناس';
$app_list_strings['marker_image_list']['grocery'] = 'خواربار فروشی';
$app_list_strings['marker_image_list']['hairsalon'] = 'آرایشگاه';
$app_list_strings['marker_image_list']['helicopter'] = 'هلیکوپتر';
$app_list_strings['marker_image_list']['highway'] = 'بزرگراه';
$app_list_strings['marker_image_list']['historical_quarter'] = 'سه ماهه تاریخی';
$app_list_strings['marker_image_list']['home'] = 'خانه';
$app_list_strings['marker_image_list']['hospital'] = 'بیمارستان';
$app_list_strings['marker_image_list']['hostel'] = 'خوابگاه';
$app_list_strings['marker_image_list']['hotel'] = 'هتل';
$app_list_strings['marker_image_list']['hotel_1_star'] = 'هتل 1 ستاره';
$app_list_strings['marker_image_list']['hotel_2_stars'] = 'هتل 2 ستاره';
$app_list_strings['marker_image_list']['hotel_3_stars'] = 'هتل 3 ستاره';
$app_list_strings['marker_image_list']['hotel_4_stars'] = 'هتل 4 ستاره';
$app_list_strings['marker_image_list']['hotel_5_stars'] = 'هتل 5 ستاره';
$app_list_strings['marker_image_list']['info'] = 'اطلاعات';
$app_list_strings['marker_image_list']['justice'] = 'عدالت';
$app_list_strings['marker_image_list']['lake'] = 'دریاچه';
$app_list_strings['marker_image_list']['laundromat'] = 'ماشین لباسشویی';
$app_list_strings['marker_image_list']['left'] = 'چپ';
$app_list_strings['marker_image_list']['left_then_down'] = 'چپ بعد پایین';
$app_list_strings['marker_image_list']['left_then_up'] = 'چپ بعد بالا';
$app_list_strings['marker_image_list']['library'] = 'کتابخانه';
$app_list_strings['marker_image_list']['lighthouse'] = 'فانوس دریایی';
$app_list_strings['marker_image_list']['liquor'] = 'مشروب';
$app_list_strings['marker_image_list']['lock'] = 'قفل';
$app_list_strings['marker_image_list']['main_road'] = 'جاده اصلی';
$app_list_strings['marker_image_list']['massage'] = 'ماساژ';
$app_list_strings['marker_image_list']['mobile_phone_tower'] = 'برج تلفن همراه';
$app_list_strings['marker_image_list']['modern_tower'] = 'برج مدرن';
$app_list_strings['marker_image_list']['monastery'] = 'صومعه';
$app_list_strings['marker_image_list']['monday'] = 'دوشنبه';
$app_list_strings['marker_image_list']['monument'] = 'بنای یادبود';
$app_list_strings['marker_image_list']['mosque'] = 'مسجد';
$app_list_strings['marker_image_list']['motorcycle'] = 'موتور سیکلت';
$app_list_strings['marker_image_list']['museum'] = 'موزه';
$app_list_strings['marker_image_list']['music_live'] = 'موسیقی زنده';
$app_list_strings['marker_image_list']['oil_pump_jack'] = 'محل استخراج نفت';
$app_list_strings['marker_image_list']['pagoda'] = 'بتکده';
$app_list_strings['marker_image_list']['palace'] = 'کاخ';
$app_list_strings['marker_image_list']['panoramic'] = 'پانوراما';
$app_list_strings['marker_image_list']['park'] = 'پارک';
$app_list_strings['marker_image_list']['park_and_ride'] = 'پارک سوار';
$app_list_strings['marker_image_list']['parking'] = 'پارکینگ';
$app_list_strings['marker_image_list']['photo'] = 'عکس';
$app_list_strings['marker_image_list']['picnic'] = 'پیک نیک';
$app_list_strings['marker_image_list']['places_unvisited'] = 'مکان های بازدید نشده';
$app_list_strings['marker_image_list']['places_visited'] = 'مکان های بازدید شده';
$app_list_strings['marker_image_list']['playground'] = 'زمین بازی';
$app_list_strings['marker_image_list']['police'] = 'پلیس';
$app_list_strings['marker_image_list']['port'] = 'درگاه';
$app_list_strings['marker_image_list']['postal'] = 'پستی';
$app_list_strings['marker_image_list']['power_line_pole'] = 'خط انتقال برق';
$app_list_strings['marker_image_list']['power_plant'] = 'نیروگاه';
$app_list_strings['marker_image_list']['power_substation'] = 'پست برق';
$app_list_strings['marker_image_list']['public_art'] = 'هنر عمومی';
$app_list_strings['marker_image_list']['rain'] = 'باران';
$app_list_strings['marker_image_list']['real_estate'] = 'مشاور املاک';
$app_list_strings['marker_image_list']['regroup'] = 'گروه‌ بندی مجدد';
$app_list_strings['marker_image_list']['resort'] = 'تفرجگاه';
$app_list_strings['marker_image_list']['restaurant'] = 'رستوران';
$app_list_strings['marker_image_list']['restaurant_african'] = 'رستوران آفریقایی';
$app_list_strings['marker_image_list']['restaurant_barbecue'] = 'رستوران باربیکیو';
$app_list_strings['marker_image_list']['restaurant_buffet'] = 'بوفه رستوران';
$app_list_strings['marker_image_list']['restaurant_chinese'] = 'رستوران چینی';
$app_list_strings['marker_image_list']['restaurant_fish'] = 'رستوران ماهی';
$app_list_strings['marker_image_list']['restaurant_fish_chips'] = 'رستوران فیش چیپس';
$app_list_strings['marker_image_list']['restaurant_gourmet'] = 'رستوران خوراک شناس';
$app_list_strings['marker_image_list']['restaurant_greek'] = 'رستوران یونانی';
$app_list_strings['marker_image_list']['restaurant_indian'] = 'رستوران هندی';
$app_list_strings['marker_image_list']['restaurant_italian'] = 'رستوران ایتالیایی';
$app_list_strings['marker_image_list']['restaurant_japanese'] = 'رستوران ژاپنی';
$app_list_strings['marker_image_list']['restaurant_kebab'] = 'رستوران کباب';
$app_list_strings['marker_image_list']['restaurant_korean'] = 'رستوران کره‌ای';
$app_list_strings['marker_image_list']['restaurant_mediterranean'] = 'رستوران مدیترانه‌ای';
$app_list_strings['marker_image_list']['restaurant_mexican'] = 'رستوران مکزیکی';
$app_list_strings['marker_image_list']['restaurant_romantic'] = 'رستوران رمانتیک';
$app_list_strings['marker_image_list']['restaurant_thai'] = 'رستوران تایلندی';
$app_list_strings['marker_image_list']['restaurant_turkish'] = 'رستوران ترکی';
$app_list_strings['marker_image_list']['right'] = 'سمت راست';
$app_list_strings['marker_image_list']['right_then_down'] = 'راست بعد پایین';
$app_list_strings['marker_image_list']['right_then_up'] = 'راست بعد بالا';
$app_list_strings['marker_image_list']['saturday'] = 'شنبه';
$app_list_strings['marker_image_list']['school'] = 'مدرسه';
$app_list_strings['marker_image_list']['shopping_mall'] = 'مرکز خرید';
$app_list_strings['marker_image_list']['shore'] = 'ساحل';
$app_list_strings['marker_image_list']['sight'] = 'منظره';
$app_list_strings['marker_image_list']['small_city'] = 'شهر کوچک';
$app_list_strings['marker_image_list']['snow'] = 'برف';
$app_list_strings['marker_image_list']['spaceport'] = 'پایگاه فضایی';
$app_list_strings['marker_image_list']['speed_100'] = 'سرعت 100';
$app_list_strings['marker_image_list']['speed_110'] = 'سرعت 110';
$app_list_strings['marker_image_list']['speed_120'] = 'سرعت 120';
$app_list_strings['marker_image_list']['speed_130'] = 'سرعت 130';
$app_list_strings['marker_image_list']['speed_20'] = 'سرعت 20';
$app_list_strings['marker_image_list']['speed_30'] = 'سرعت 30';
$app_list_strings['marker_image_list']['speed_40'] = 'سرعت 40';
$app_list_strings['marker_image_list']['speed_50'] = 'سرعت 50';
$app_list_strings['marker_image_list']['speed_60'] = 'سرعت 60';
$app_list_strings['marker_image_list']['speed_70'] = 'سرعت 70';
$app_list_strings['marker_image_list']['speed_80'] = 'سرعت 80';
$app_list_strings['marker_image_list']['speed_90'] = 'سرعت 90';
$app_list_strings['marker_image_list']['speed_hump'] = 'سرعت‌گیر';
$app_list_strings['marker_image_list']['stadium'] = 'استادیوم';
$app_list_strings['marker_image_list']['statue'] = 'مجسمه';
$app_list_strings['marker_image_list']['steam_train'] = 'قطار بخار';
$app_list_strings['marker_image_list']['stop'] = 'توقف';
$app_list_strings['marker_image_list']['stoplight'] = 'چراغ راهنمایی';
$app_list_strings['marker_image_list']['subway'] = 'مترو';
$app_list_strings['marker_image_list']['sun'] = 'یکشنبه';
$app_list_strings['marker_image_list']['sunday'] = 'یکشنبه';
$app_list_strings['marker_image_list']['supermarket'] = 'سوپر مارکت';
$app_list_strings['marker_image_list']['synagogue'] = 'کنیسه';
$app_list_strings['marker_image_list']['tapas'] = 'Tapas';
$app_list_strings['marker_image_list']['taxi'] = 'تاکسی';
$app_list_strings['marker_image_list']['taxiway'] = 'مسیر ویژه تاکسی';
$app_list_strings['marker_image_list']['teahouse'] = 'چایخانه';
$app_list_strings['marker_image_list']['telephone'] = 'تلفن';
$app_list_strings['marker_image_list']['temple_hindu'] = 'معبد هندو';
$app_list_strings['marker_image_list']['terrace'] = 'تراس';
$app_list_strings['marker_image_list']['text'] = 'متن';
$app_list_strings['marker_image_list']['theater'] = 'تئاتر';
$app_list_strings['marker_image_list']['theme_park'] = 'پارک';
$app_list_strings['marker_image_list']['thursday'] = 'پنج‌شنبه';
$app_list_strings['marker_image_list']['toilets'] = 'سرویس بهداشتی';
$app_list_strings['marker_image_list']['toll_station'] = 'ایستگاه عوارضی';
$app_list_strings['marker_image_list']['tower'] = 'برج';
$app_list_strings['marker_image_list']['traffic_enforcement_camera'] = 'دوربین‌ کنترل ترافیک';
$app_list_strings['marker_image_list']['train'] = 'قطار';
$app_list_strings['marker_image_list']['tram'] = 'تراموا';
$app_list_strings['marker_image_list']['truck'] = 'کامیون';
$app_list_strings['marker_image_list']['tuesday'] = 'سه‌شنبه';
$app_list_strings['marker_image_list']['tunnel'] = 'تونل';
$app_list_strings['marker_image_list']['turn_left'] = 'گردش به چپ';
$app_list_strings['marker_image_list']['turn_right'] = 'گردش به راست';
$app_list_strings['marker_image_list']['university'] = 'دانشگاه';
$app_list_strings['marker_image_list']['up'] = 'بالا';
$app_list_strings['marker_image_list']['up_left'] = 'بالا چپ';
$app_list_strings['marker_image_list']['up_right'] = 'بالا راست';
$app_list_strings['marker_image_list']['up_then_left'] = 'بالا بعد چپ';
$app_list_strings['marker_image_list']['up_then_right'] = 'بالا بعد راست';
$app_list_strings['marker_image_list']['vespa'] = 'Vespa';
$app_list_strings['marker_image_list']['video'] = 'ویدیو';
$app_list_strings['marker_image_list']['villa'] = 'ویلا';
$app_list_strings['marker_image_list']['water'] = 'آب';
$app_list_strings['marker_image_list']['waterfall'] = 'آبشار';
$app_list_strings['marker_image_list']['watermill'] = 'آسیاب آبی';
$app_list_strings['marker_image_list']['waterpark'] = 'پارک آبی';
$app_list_strings['marker_image_list']['watertower'] = 'تانکر آب';
$app_list_strings['marker_image_list']['wednesday'] = 'چهارشنبه';
$app_list_strings['marker_image_list']['wifi'] = 'WiFi';
$app_list_strings['marker_image_list']['wind_turbine'] = 'توربین بادی';
$app_list_strings['marker_image_list']['windmill'] = 'آسیاب بادی';
$app_list_strings['marker_image_list']['winery'] = 'کارخانه شراب سازی';
$app_list_strings['marker_image_list']['work_office'] = 'دفتر کار';
$app_list_strings['marker_image_list']['world_heritage_site'] = 'مکان مربوط به میراث جهانی';
$app_list_strings['marker_image_list']['zoo'] = 'باغ وحش';

//Reschedule
$app_list_strings['call_reschedule_dom'][''] = '';
$app_list_strings['call_reschedule_dom']['Out of Office'] = 'خارج از دفتر';
$app_list_strings['call_reschedule_dom']['In a Meeting'] = 'در جلسه';

$app_strings['LBL_RESCHEDULE_LABEL'] = 'برنامه‌ریزی مجدد';
$app_strings['LBL_RESCHEDULE_TITLE'] = 'لطفا اطلاعات برنامه‌ریزی مجدد را وارد کنید';
$app_strings['LBL_RESCHEDULE_DATE'] = 'تاریخ:';
$app_strings['LBL_RESCHEDULE_REASON'] = 'دلیل:';
$app_strings['LBL_RESCHEDULE_ERROR1'] = 'لطفاً یک تاریخ معتبرانتخاب کنید';
$app_strings['LBL_RESCHEDULE_ERROR2'] = 'لطفا یک دلیل انتخاب کنید';

$app_strings['LBL_RESCHEDULE_PANEL'] = 'برنا مه‌ریزی مجدد';
$app_strings['LBL_RESCHEDULE_HISTORY'] = 'تاریخچه تماس‌';
$app_strings['LBL_RESCHEDULE_COUNT'] = 'تماس‌ها';

//SecurityGroups
$app_list_strings['moduleList']['SecurityGroups'] = 'مدیریت مجموعه امنیتی';
$app_strings['LBL_SECURITYGROUP'] = 'گروه امنیتی';
$app_strings['LBL_ROLE'] = 'نقش';

$app_list_strings['moduleList']['OutboundEmailAccounts'] = 'حساب ایمیل خارجی';
$app_list_strings['moduleList']['ExternalOAuthConnection'] = 'اتصال OAuth خارجی';
$app_list_strings['moduleList']['ExternalOAuthProvider'] = 'ارائه دهنده OAuth خارجی';

//social
$app_strings['FACEBOOK_USER_C'] = 'فیس‌بوک';
$app_strings['TWITTER_USER_C'] = 'توییتر';
$app_strings['LBL_PANEL_SOCIAL_FEED'] = 'جزئیات فید شبکه‌های اجتماعی';

$app_strings['LBL_SUBPANEL_FILTER_LABEL'] = 'فیلتر';

$app_strings['LBL_COLLECTION_TYPE'] = 'نوع';

$app_strings['LBL_ADD_TAB'] = 'افزودن زبانه';
$app_strings['LBL_EDIT_TAB'] = 'ویرایش زبانه‌ها';
$app_strings['LBL_SUITE_DASHBOARD'] = 'داشبورد SUITECRM';
$app_strings['LBL_ENTER_DASHBOARD_NAME'] = 'نام پیشخوان را وارد کنید:';
$app_strings['LBL_NUMBER_OF_COLUMNS'] = 'تعداد ستون‌ها:';
$app_strings['LBL_DELETE_DASHBOARD1'] = 'آیا از حذف این پیشخوان مطمئن هستید';
$app_strings['LBL_DELETE_DASHBOARD2'] = '؟';
$app_strings['LBL_ADD_DASHBOARD_PAGE'] = 'افزودن یک صفحه پیشخوان';
$app_strings['LBL_DELETE_DASHBOARD_PAGE'] = 'حذف صفحه پیشخوان فعلی';
$app_strings['LBL_RENAME_DASHBOARD_PAGE'] = 'تغییر نام صفحه پیشخوان';
$app_strings['LBL_SUITE_DASHBOARD_ACTIONS'] = 'اقدامات';

$app_list_strings['collection_temp_list'] = array(
    'Tasks' => 'وظایف',
    'Meetings' => 'جلسه‌ها',
    'Calls' => 'تماس‌ها',
    'Notes' => 'یادداشت‌ها',
    'Emails' => 'ایمیل‌ها'
);

$app_list_strings['moduleList']['TemplateEditor'] = 'ویرایشگر قسمت الگو';
$app_strings['LBL_CONFIRM_CANCEL_INLINE_EDITING'] = "شما خارج از قسمتی که در حال ویرایش آن بودید، بدون ذخیره کلیک کرده اید. اگر تمایل داید که تغییر خود را از دست دهید، تأیید را کلیک کنید، یا اگر می خواهید به ویرایش ادامه دهید، آن را لغو کنید.";
$app_strings['LBL_LOADING_ERROR_INLINE_EDITING'] = "هنگام بارگیری فیلد خطایی روی داد. ممکن است زمان جلسه شما تمام شده باشد. لطفا برای رفع این مشکل دوباره وارد شوید";

$app_list_strings['moduleList']['AOBH_BusinessHours'] = 'ساعات کاری';
$app_list_strings['business_hours_list']['0'] = '12am';
$app_list_strings['business_hours_list']['1'] = '1am';
$app_list_strings['business_hours_list']['2'] = '2am';
$app_list_strings['business_hours_list']['3'] = '3am';
$app_list_strings['business_hours_list']['4'] = '4am';
$app_list_strings['business_hours_list']['5'] = '5am';
$app_list_strings['business_hours_list']['6'] = '6am';
$app_list_strings['business_hours_list']['7'] = '7am';
$app_list_strings['business_hours_list']['8'] = '8am';
$app_list_strings['business_hours_list']['9'] = '9am';
$app_list_strings['business_hours_list']['10'] = '10am';
$app_list_strings['business_hours_list']['11'] = '11am';
$app_list_strings['business_hours_list']['12'] = '12pm';
$app_list_strings['business_hours_list']['13'] = '1pm';
$app_list_strings['business_hours_list']['14'] = '2pm';
$app_list_strings['business_hours_list']['15'] = '3pm';
$app_list_strings['business_hours_list']['16'] = '4pm';
$app_list_strings['business_hours_list']['17'] = '5pm';
$app_list_strings['business_hours_list']['18'] = '6pm';
$app_list_strings['business_hours_list']['19'] = '7pm';
$app_list_strings['business_hours_list']['20'] = '8pm';
$app_list_strings['business_hours_list']['21'] = '9pm';
$app_list_strings['business_hours_list']['22'] = '10pm';
$app_list_strings['business_hours_list']['23'] = '11pm';
$app_list_strings['day_list']['Monday'] = 'دوشنبه';
$app_list_strings['day_list']['Tuesday'] = 'سه‌شنبه';
$app_list_strings['day_list']['Wednesday'] = 'چهارشنبه';
$app_list_strings['day_list']['Thursday'] = 'پنج‌شنبه';
$app_list_strings['day_list']['Friday'] = 'جمعه';
$app_list_strings['day_list']['Saturday'] = 'شنبه';
$app_list_strings['day_list']['Sunday'] = 'یکشنبه';
$app_list_strings['pdf_page_size_dom']['A4'] = 'A4';
$app_list_strings['pdf_page_size_dom']['Letter'] = 'Letter';
$app_list_strings['pdf_page_size_dom']['Legal'] = 'Legal';
$app_list_strings['pdf_orientation_dom']['Portrait'] = 'Portrait';
$app_list_strings['pdf_orientation_dom']['Landscape'] = 'Landscape';


$app_list_strings['moduleList']['SurveyResponses'] = 'پاسخ های نظرسنجی';
$app_list_strings['moduleList']['Surveys'] = 'نظرسنجی ها';
$app_list_strings['moduleList']['SurveyQuestionResponses'] = 'پاسخ به سوال نظرسنجی';
$app_list_strings['moduleList']['SurveyQuestions'] = 'سوالات نظرسنجی';
$app_list_strings['moduleList']['SurveyQuestionOptions'] = 'گزینه های سوال نظرسنجی';
$app_list_strings['survey_status_list']['Draft'] = 'پیش‌نویس';
$app_list_strings['survey_status_list']['Public'] = 'عمومی';
$app_list_strings['survey_status_list']['Closed'] = 'بسته';
$app_list_strings['surveys_question_type']['Text'] = 'متن';
$app_list_strings['surveys_question_type']['Textbox'] = 'Textbox';
$app_list_strings['surveys_question_type']['Checkbox'] = 'کادر انتخاب';
$app_list_strings['surveys_question_type']['Radio'] = 'رادیو';
$app_list_strings['surveys_question_type']['Dropdown'] = 'Dropdown';
$app_list_strings['surveys_question_type']['Multiselect'] = 'Multiselect';
$app_list_strings['surveys_question_type']['Matrix'] = 'Matrix';
$app_list_strings['surveys_question_type']['DateTime'] = 'DateTime';
$app_list_strings['surveys_question_type']['Date'] = 'تاریخ';
$app_list_strings['surveys_question_type']['Scale'] = 'مقیاس';
$app_list_strings['surveys_question_type']['Rating'] = 'امتیاز دهی';
$app_list_strings['surveys_matrix_options'][0] = 'راضی';
$app_list_strings['surveys_matrix_options'][1] = 'Neither Satisfied nor Dissatisfied';
$app_list_strings['surveys_matrix_options'][2] = 'ناراضی';

$app_strings['LBL_OPT_IN_PENDING_EMAIL_NOT_SENT'] = 'در انتظار تایید عضویت، تایید عضویت ارسال نشده است';
$app_strings['LBL_OPT_IN_PENDING_EMAIL_FAILED'] = 'تأیید انتخاب در ارسال ایمیل انجام نشد';
$app_strings['LBL_OPT_IN_PENDING_EMAIL_SENT'] = 'در انتظار تایید عضویت، تایید عضویت ارسال شد';
$app_strings['LBL_OPT_IN'] = 'عضو شد';
$app_strings['LBL_OPT_IN_CONFIRMED'] = 'شرکت تأیید شد';
$app_strings['LBL_OPT_IN_OPT_OUT'] = 'انصراف داده';
$app_strings['LBL_OPT_IN_INVALID'] = 'نامعتبر';

/** @see SugarEmailAddress */
$app_list_strings['email_settings_opt_in_dom'] = array(
    'not-opt-in' => 'غیرفعال شده',
    'opt-in' => 'عضویت',
    'confirmed-opt-in' => 'شرکت تأیید شد'
);

$app_list_strings['email_confirmed_opt_in_dom'] = array(
    'not-opt-in' => 'غیرفعال شده',
    'opt-in' => 'عضویت',
    'confirmed-opt-in' => 'شرکت تأیید شد'
);

$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL'] = 'The confirm opt in email has been added to the email queue for %s email address(es). ';
$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL_NOT_OPT_IN'] = 'ارسال ایمیل به آدرس(های) ایمیل %s امکان پذیر نیست، زیرا آنها غیرفعال شده اند. ';
$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL_MISSING_EMAIL_ADDRESS_ID'] = '%s آدرس ایمیل شناسه معتبری ندارد. ';

$app_strings['ERR_TWO_FACTOR_FAILED'] = 'احراز هویت دو مرحله ای انجام نشد';
$app_strings['ERR_TWO_FACTOR_CODE_SENT'] = 'کد احراز هویت دو مرحله ای ارسال شد.';
$app_strings['ERR_TWO_FACTOR_CODE_FAILED'] = 'کد احراز هویت دو مرحله ای ارسال نشد.';
$app_strings['LBL_THANKS_FOR_SUBMITTING'] = 'از شما برای ارسال تجربه خود متشکریم.';

    $app_strings['ERR_IP_CHANGE'] = 'جلسه شما به دلیل تغییرات قابل توجه در آدرس IP خاتمه یافت';
$app_strings['ERR_RETURN'] = 'بازگشت به خانه';


$app_list_strings['oauth2_grant_type_dom'] = array(
    'password' => 'اعطای رمز عبور',
    'client_credentials' => 'اعتبار مشتری',
    'implicit' => 'ضمنی',
    'authorization_code' => 'کد مجوز'
);

$app_list_strings['oauth2_duration_units'] = [
    'minute' => 'دقیقه',
    'hour' => 'ساعت',
    'day' => 'روز',
    'week' => 'هفته ها',
    'month' => 'ماه ها',
];

$app_list_strings['search_controllers'] = [
    'Search' => 'جستجو (جدید)',
    'UnifiedSearch' => 'جستجوی یکپارچه جهانی (legacy)'
];


$app_strings['LBL_DEFAULT_API_ERROR_TITLE'] = 'JSON API Error';
$app_strings['LBL_DEFAULT_API_ERROR_DETAIL'] = 'JSON API Error occurred.';
$app_strings['LBL_API_EXCEPTION_DETAIL'] = 'Api Version: 8';
$app_strings['LBL_BAD_REQUEST_EXCEPTION_DETAIL'] = 'لطفا مطمئن شوید که فیلدهای مورد نیاز را پر کرده اید';
$app_strings['LBL_EMPTY_BODY_EXCEPTION_DETAIL'] = 'Json API expects body of the request to be JSON';
$app_strings['LBL_INVALID_JSON_API_REQUEST_EXCEPTION_DETAIL'] = 'Unable to validate the Json Api Payload Request';
$app_strings['LBL_INVALID_JSON_API_RESPONSE_EXCEPTION_DETAIL'] = 'Unable to validate the Json Api Payload Response';
$app_strings['LBL_MODULE_NOT_FOUND_EXCEPTION_DETAIL'] = 'Json API cannot find resource';
$app_strings['LBL_NOT_ACCEPTABLE_EXCEPTION_DETAIL'] = 'Json API expects the "Accept" header to be application/vnd.api+json';
$app_strings['LBL_UNSUPPORTED_MEDIA_TYPE_EXCEPTION_DETAIL'] = 'Json API expects the "Content-Type" header to be application/vnd.api+json';

$app_strings['MSG_BROWSER_NOTIFICATIONS_ENABLED'] = 'اعلان‌های دسک‌تاپ اکنون برای این مرورگر وب فعال هستند.';
$app_strings['MSG_BROWSER_NOTIFICATIONS_DISABLED'] = 'اعلان‌های دسک‌تاپ برای این مرورگر وب غیرفعال است. از تنظیمات برگزیده مرورگر خود برای فعال کردن دوباره آنها استفاده کنید.';
$app_strings['MSG_BROWSER_NOTIFICATIONS_UNSUPPORTED'] = 'این مرورگر از اعلان های دسکتاپ پشتیبانی نمی کند.';

$app_strings['LBL_GOOGLE_SYNC_ERR'] = 'SuiteCRM Google Sync - ERROR';
$app_strings['LBL_THERE_WAS_AN_ERR'] = 'یک خطا وجود دارد: ';
$app_strings['LBL_CLICK_HERE'] = 'اینجا کلیک کنید';
$app_strings['LBL_TO_CONTINUE'] = ' ادامه.';
$app_strings['LBL_OPT_OUT'] = 'انصراف';
$app_strings['LBL_INVALID_EMAIL'] = 'نامعتبر';
$app_strings['LBL_PRIMARY'] = 'اصلی';
$app_strings['LBL_EMAIL_ADDRESS'] = 'آدرس ایمیل';

$app_strings['IMAP_HANDLER_ERROR'] = 'خطا: {error}; key was: "{key}".';
$app_strings['IMAP_HANDLER_SUCCESS'] = 'تایید: تنظیمات تست به "{key}" تغییر کرد';
$app_strings['IMAP_HANDLER_ERROR_INVALID_REQUEST'] = 'درخواست نامعتبر است، از مقدار "{var}" استفاده کنید.';
$app_strings['IMAP_HANDLER_ERROR_UNKNOWN_BY_KEY'] = 'خطای ناشناخته رخ داد، کلید "{key}" ذخیره نشد.';
$app_strings['IMAP_HANDLER_ERROR_NO_TEST_SET'] = 'تنظیمات تست وجود ندارد.';
$app_strings['IMAP_HANDLER_ERROR_NO_KEY'] = 'کلید پیدا نشد.';
$app_strings['IMAP_HANDLER_ERROR_KEY_SAVE'] = 'خطای ذخیره کلید.';
$app_strings['IMAP_HANDLER_ERROR_UNKNOWN'] = 'خطای ناشناخته';
$app_strings['LBL_SEARCH_TITLE']                   = 'جستجو';
$app_strings['LBL_SEARCH_TEXT_FIELD_TITLE_ATTR']   = 'معیارهای جستجوی ورودی';
$app_strings['LBL_SEARCH_SUBMIT_FIELD_TITLE_ATTR'] = 'جستجو';
$app_strings['LBL_SEARCH_SUBMIT_FIELD_VALUE']      = 'جستجو';
$app_strings['LBL_SEARCH_QUERY']                   = 'Search query: ';
$app_strings['LBL_SEARCH_RESULTS_PER_PAGE']        = 'نتایج در هر صفحه: ';
$app_strings['LBL_SEARCH_ENGINE']                  = 'موتور: ';
$app_strings['LBL_SEARCH_TOTAL'] = 'تمام نتایج ها: ';
$app_strings['LBL_SEARCH_PREV'] = 'قبلی';
$app_strings['LBL_SEARCH_NEXT'] = 'بعدی';
$app_strings['LBL_SEARCH_PAGE'] = 'صفحه ';
$app_strings['LBL_SEARCH_OF'] = ' از ';
$app_strings['LBL_INSIGHTS'] = 'Insights';
$app_strings['LBL_CHARTS'] = 'نمودارها';
$app_strings['LBL_CHART_NOT_FOUND'] = 'نمودار پیدا نشد';
$app_strings['LBL_NO_DATA'] = 'بدون داده';
$app_strings['LBL_ERROR_FETCHING_METADATA'] = 'هنگام واکشی فراداده خطایی روی داد';
$app_strings['LBL_TOTAL'] = 'مجموع';
$app_strings['LBL_ACTIONS'] = 'اقدامات';
    $app_strings['LBL_SELECT_SUBPANEL_BANNER'] = 'پنل های فرعی را برای مشاهده انتخاب کنید';
$app_strings['LBL_SELECT_ITEM'] = 'یک مورد را انتخاب کنید';
$app_strings['LBL_WIDGET_NOT_FOUND'] = 'ویجت پیدا نشد';
$app_strings['LBL_BAD_CONFIG'] = 'پیکربندی نادرست';
$app_strings['LBL_CONFIG_BAD_CONTEXT'] = 'پیکربندی نادرست: زمینه به درستی پیکربندی نشده است';
$app_strings['LBL_CONFIG_NO_CONFIG'] = 'پیکربندی نادرست: پیکربندی موجود نیست';
$app_strings['LBL_CONFIG_NO_STATISTICS_KEY'] = 'پیکربندی نادرست: کلید آمار گم شده است';
$app_strings['LBL_STATISTIC_ERROR'] = 'خطا در بارگیری آمار';
$app_strings['LBL_STATISTIC_ERROR_DESC'] = 'خطا در بارگیری آمار';
$app_strings['LBL_STATISTIC_ERROR_DESC_TOOLTIP'] = 'خطا در بارگیری آمار. لطفا با مدیر خود تماس بگیرید';
$app_strings['LBL_AVERAGE_CLOSED_WON_PER_YEAR'] = 'میانگین فرصت به دست آمده در سال';
$app_strings['LBL_OPPORTUNITIES_TOTAL'] = 'Total Opportunity Value';
$app_strings['LBL_CASE_TOTAL_DAYS_OPEN'] = 'مجموع روزهای باز';
$app_strings['LBL_DAYS_OPEN'] = 'روزهای باز';
$app_strings['LBL_DAYS_IN_SALE_STAGE'] = 'این فرصت در مرحله فروش بوده است';
$app_strings['LBL_STAT_DAYS'] = 'روز(ها)';
$app_strings['LBL_CLOSED_PER_YEAR'] = 'بسته شده در سال';
$app_strings['LBL_WAS_OPEN'] = 'این پرونده باز بود برای';
$app_strings['LBL_HAS_BEEN_OPEN'] = 'این پرونده باز شده است';
$app_strings['LBL_NUMBER_OF_CASES_PER_ACCOUNT'] = 'تعداد پرونده ها در هر حساب';
$app_strings['LBL_TOTAL_CASES_FOR_THIS_ACCOUNT'] = 'مجموع موارد این حساب: ';
$app_strings['LBL_NONE_OUTSTANDING'] = 'هیچ‌کدام';
$app_strings['LBL_VALIDATION_ERROR_REQUIRED'] = 'فیلد الزامی وجود ندارد: {{fields.field.label}}';
$app_strings['LBL_VALIDATION_ERROR_CURRENCY_FORMAT'] = "فرمت ارز نامعتبر است. انتظار می رود: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_INT_FORMAT'] = "قالب int نامعتبر است. انتظار می رود: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_FLOAT_FORMAT'] = "Invalid float format. Expected: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_DATE_FORMAT'] = "قالب تاریخ نامعتبر است. انتظار می رود: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_DATETIME_FORMAT'] = "قالب تاریخ نامعتبر است. انتظار می رود: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_EMAIL_FORMAT'] = "قالب ایمیل نامعتبر است. انتظار می رود: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_PHONE_FORMAT'] = "قالب تلفن نامعتبر است.";
$app_strings['LBL_VALIDATION_ERROR_MIN'] = "مقدار نامعتبر است. مقدار باید بزرگتر یا مساوی «{{context.min}} باشد.'";
$app_strings['LBL_VALIDATION_ERROR_MAX'] = "مقدار نامعتبر است. مقدار باید کوچکتر یا برابر با "{{context.max}}" باشد";
$app_strings['LBL_MULTIPLE_PRIMARY_EMAIL_VALIDATION_ERROR'] = "فقط یک آدرس ایمیل می تواند به عنوان ایمیل اصلی علامت گذاری شود";
$app_strings['LBL_DUPLICATE_EMAIL_VALIDATION_ERROR'] = "آدرس ایمیل تکراری مجاز نیست";
$app_strings['LBL_NO_PRIMARY_EMAIL_VALIDATION_ERROR'] = "یک آدرس ایمیل باید به عنوان ایمیل اصلی علامت گذاری شود";
$app_strings['LBL_VALIDATION_ERRORS'] = 'خطاهای اعتبارسنجی وجود دارد، قادر به انجام عملیات نیست.';
$app_strings['LBL_LOADING_IN_PROGRESS'] = 'محاسبه در حال حاضر در حال انجام است، لطفاً قبل از تلاش مجدد چند لحظه صبر کنید.';
$app_strings['LBL_TYPE_TO_SEARCH'] = 'برای جستجو تایپ کنید...';
$app_strings['LBL_SEARCHING'] = 'جستجو...';
$app_strings['LBL_NOT_FOUND'] = 'پیدا نشد.';
$app_strings['LBL_SEARCH_ERROR'] = 'خطای جستجو.';
$app_strings['LBL_FOUND'] = 'پیدا شد';
$app_strings['LBL_GET_RECORD_LIST_ERROR'] = 'هنگام بازیابی سوابق خطایی رخ داد';
$app_strings['LBL_NUMBER_OF_RECORDS'] = 'تعداد رکوردها';
$app_strings['LBL_FORWARD_SLASH'] = '/';
$app_strings['LBL_CASES_INSIGHT'] = ' {{fields.cases.value}} ( {{fields.default.value}} )';
$app_strings['LBL_INVOICES_INSIGHT'] = ' {{fields.invoices.value}} ( {{fields.default.value}} )';
$app_strings['LBL_CONTRACT_RENEWAL_TOOLTIP'] = 'تاریخ تمدید قرارداد بعدی';
$app_strings['LBL_INVOICES_OVERDUE_TOOLTIP'] = 'تعداد کل صورتحساب های معوق';
$app_strings['LBL_ACTIVITIES_NEXT_DATE_TOOLTIP'] = 'تاریخ تعامل بعدی';
$app_strings['LBL_CAMPAIGN_LAST_RECEIVED_TOOLTIP'] = 'تاریخ آخرین کمپین دریافتی';
$app_strings['LBL_OPEN_CASES_COUNT_TOOLTIP'] = 'تعداد کل پرونده های باز';
$app_strings['LBL_EVENTS_LAST_DATE_TOOLTIP'] = 'تاریخ آخرین رویداد';
$app_strings['LBL_HISTORY_LAST_DATE_TOOLTIP'] = 'تاریخ آخرین تعامل';
$app_strings['LBL_OPPORTUNITIES_TOTAL_SUM_TOOLTIP'] = 'همه مجموع فرصت ها';
$app_strings['LBL_QUOTES_EXPIRY_TOOLTIP'] = 'Date of the next Quote Expiration';
$app_strings['LBL_DEFAULT_TOTAL_TOOLTIP'] = 'تعداد کل رکوردها';
$app_strings['LBL_CONTRACT_RENEWAL'] = 'تاریخ تمدید';
$app_strings['LBL_INVOICES_OVERDUE'] = 'کل معوقه';
$app_strings['LBL_ACTIVITIES_NEXT_DATE'] = 'تاریخ فعالیت بعدی';
$app_strings['LBL_CAMPAIGN_LAST_RECEIVED'] = 'آخرین شرکت کننده';
$app_strings['LBL_OPEN_CASES_COUNT'] = 'پرونده های باز';
$app_strings['LBL_EVENTS_LAST_DATE'] = 'آخرین رویداد شرکت کننده';
$app_strings['LBL_HISTORY_LAST_DATE'] = 'آخرین نقطه تماس';
$app_strings['LBL_OPPORTUNITIES_TOTAL_SUM'] = 'ارزش کل';
$app_strings['LBL_QUOTES_EXPIRY'] = 'تاریخ انقضای بعدی';
$app_strings['LBL_DEFAULT_TOTAL'] = 'مجموع';
$app_strings['AOS_Contracts'] = 'قراردادها';
$app_strings['AOS_Quotes'] = 'پیش‌فاکتورها';
$app_strings['AOS_Invoices'] = 'فاکتورها';
$app_strings['LBL_PHOTO'] = 'عکس';
$app_strings['LBL_CASE_UPDATES'] = 'تغییرات خدمات';
$app_strings['LBL_CASE_UPDATE_SUBMITTED'] = 'به روز رسانی پرونده ارسال شد';
$app_strings['LBL_SUMMARY_DEFAULT'] = "{{fields.name.value}}";
$app_strings['LBL_SUMMARY_PERSON'] = "{{fields.salutation.value}} {{fields.first_name.value}} {{fields.last_name.value}}";
$app_strings['LBL_SUMMARY_DOCUMENT'] = "{{fields.document_name.value}}";
$app_strings['LBL_CREATE'] = 'ایجاد';
$app_strings['LBL_CLEAR_FILTER'] = 'پاک کردن فیلتر';
$app_strings['LBL_QUICK_FILTERS'] = 'فیلترهای سریع';
$app_strings['LBL_SAVED_FILTER_SAVED'] = 'فیلتر با موفقیت ذخیره شد';
$app_strings['LBL_FILTER_ID_NOT_DEFINED'] = 'شناسه فیلتر تعریف نشده است';
$app_strings['LBL_GENERIC_CONFIRMATION'] = 'آیا می خواهید به عملیات ادامه دهید؟';
$app_strings['LBL_SHOW_MORE'] = 'نمایش بیشتر';
$app_strings['LBL_SHOW_LESS'] = 'نمایش کمتر';
$app_strings['LBL_LOAD_MORE'] = 'بارگذاری بیشتر';
$app_strings['LBL_EMPTY'] = '-- خالی -- ';
$app_strings['LBL_OPERATOR'] = 'اپراتور';
$app_strings['LBL_START'] = 'شروع';
$app_strings['LBL_END'] = 'پايان';
$app_strings['LBL_LINE_ITEMS_FIELD_CONFIG'] = 'پیکربندی بد';


$app_strings['LBL_ACTION_SUCCESS'] = 'عملیات با موفقیت انجام شد';

$app_strings['LBL_YES'] = 'بله';
$app_strings['LBL_NO'] = 'خير';

$app_list_strings['sort_order'] = [];
$app_list_strings['sort_order']['asc'] = 'صعودی';
$app_list_strings['sort_order']['desc'] = 'نزولی';

// Labels used by subpanel unlink relationship process
$app_strings['LBL_LINK'] = 'لینک';
    $app_strings['LBL_UNLINK_RECORD'] = 'لغو پیوند رکورد';
$app_strings['LBL_EDIT_RECORD'] = 'ویرایش رکورد';
$app_strings['LBL_UNLINK_RELATIONSHIP_CONFIRM'] = 'آیا از لغو پیوند رکورد مطمئن هستید؟ فقط رابطه قطع خواهد شد. رکورد حذف نخواهد شد.';
$app_strings['LBL_UNLINK_RELATIONSHIP_SUCCESS'] = 'رکورد با موفقیت لغو شد.';
$app_strings['LBL_UNLINK_RELATIONSHIP_FAILED'] = 'هنگام لغو پیوند این رکورد خطایی روی داد.';
$app_strings['LBL_LINK_RELATIONSHIP_SUCCESS'] = 'رابطه با موفقیت متصل شد.';
$app_strings['LBL_LINK_RELATIONSHIP_FAILED'] = 'خطایی در پیوند دادن این رابطه وجود داشت.';
$app_strings['LBL_MODULE_NOT_FOUND'] = 'ماژول پیدا نشد.';
$app_strings['LBL_RECORD_NOT_FOUND'] = 'رکورد بارگزاری نشد';
$app_strings['LBL_RELATIONSHIP_LOAD_ERROR'] = 'رابطه بارگزاری نشد';
$app_strings['LBL_NOT_LINKED'] = 'لغو پیوند ممکن نیست. رکوردها مرتبط نیستند';
$app_strings['LBL_ACCESS_DENIED'] = 'دسترسی ممنوع شد';
$app_strings['LBL_ADD_RECORDS_TO_TARGET_LIST_SUCCESS'] = 'رکوردها با موفقیت به لیست مورد نظر اضافه شدند.';
$app_strings['LBL_ADD_RECORDS_TO_TARGET_LIST_FAILED'] = 'هنگام افزودن رکوردها به فهرست مورد نظر خطایی روی داد.';
$app_strings['LBL_ADD_CONTACTS_TO_TARGET_LIST_SUCCESS'] = 'مخاطبین با موفقیت به لیست مورد نظر اضافه شدند.';
$app_strings['LBL_ADD_CONTACTS_TO_TARGET_LIST_FAILED'] = 'هنگام افزودن مخاطبین به لیست مورد نظر خطایی روی داد.';
$app_strings['LBL_CHANGED_TO_TEXT'] = 'تغییر کرد به';
$app_strings['LBL_RECORD_CHANGED'] = 'رکورد به روز رسانی شد.';
$app_strings['LBL_CREATE'] = "ایجاد";
$app_strings['LBL_USE_ADVANCED_SEARCH'] = 'از جستجوی پیشرفته استفاده کنید.';
$app_strings['LBL_USE_BASIC_SEARCH'] = 'از جستجوی پایه استفاده کنید';
$app_strings['LBL_NO_MODULE_SELECTED'] = 'هیچ ماژولی انتخاب نشده است';
$app_strings['LBL_CLOSE_MENU'] = 'بستن منو';
$app_strings['LOGIN_INCORRECT'] = 'اطلاعات کاربری نادرست است, لطفا دوباره تلاش کنید.';
$app_strings['LOGIN_TOO_MANY_FAILED'] = ' تعداد زیادی تلاش برای ورود ناموفق، لطفاً بعداً دوباره امتحان کنید.';

// PDF Engines
$app_strings['LBL_LEGACY_MPDF_ENGINE'] = 'موتور MPDF قدیمی';
$app_strings['LBL_TCPDF_ENGINE'] = 'موتور TCPDF';


$app_strings['ERR_INVALID_FILE_NAME'] = 'نام فایل نامعتبر است:';
$app_strings['LBL_LOGGER_VALID_FILENAME_CHARACTERS'] = 'این فقط می تواند حروف الفبایی باشد, plus \'.\' , \'-\' and \'_\'';
$app_strings['LBL_LOGGER_INVALID_FILENAME'] = 'نام فایل وارد شده معتبر نیست.';

$app_strings['LBL_PASSWORD_SET_NEW_VALUE_TO_RESET'] = 'ساخت پسورد. مقدار پسورد جدید را وارد کنید.';
$app_strings['LBL_VALUE_SET_PLACEHOLDER'] = 'ساخت مقدار. مقدار جدید را برای لغو مقدار فعلی وارد کنید.';

$app_strings['ERR_IMAP_OAUTH_CONNECTION_ERROR'] = 'Not able to connect using OAuth login with Inbound Email server. For connection: ';
$app_strings['WARN_OAUTH_TOKEN_SESSION_EXPIRED'] = 'مدت IMAP OAuth شما منقضی شده است, لطفاً دوباره وارد شوید: ';

$app_strings['LBL_KEY'] = 'کلید';
$app_strings['LBL_VALUE'] = 'مقدار';
$app_strings['LBL_OPTIONAL'] = 'اختیاری';
$app_strings['LBL_OPTIONAL_CONNECTION_STRING'] = 'اختیاری. تنظیم کنید تا از یک رشته اتصال خاص استفاده کند';
$app_strings['LBL_OUTBOUND_ACCOUNT'] = 'حساب خروجی';
$app_strings['LBL_INBOUND_ACCOUNT'] = 'حساب ورودی';
$app_strings['LBL_SYSTEM_ACCOUNT'] = 'حساب سیستم';
$app_strings['LBL_FROM_SYSTEM'] = 'ارسال از سیستم';
$app_strings['LBL_SIGNATURE'] = 'امضا';
$app_strings['LBL_NEW_NOTIFICATION'] = "شما {{context.unread}} اعلان‌های جدیدی دارید";
$app_strings['LBL_NOTIFICATION_ITEM_DATE'] = 'به دلیل: {{fields.date_start.value}}';
$app_strings['LBL_NOTIFICATION_ITEM_DATE_ENTERED'] = 'اطلاع داده شد: {{fields.snooze.value}}';
$app_strings['LBL_QUICK_ACTIONS'] = 'عملیات سریع';
